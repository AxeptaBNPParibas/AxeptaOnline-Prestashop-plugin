/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */
// Appel automatique au chargement
$(document).ready(function() {
	initCheckCgv();
	checkPageShow();
});

// Vérifie les CGV
function initCheckCgv() {
	const $cgvCheckbox = $('input[name="conditions_to_approve[terms-and-conditions]"]');
	const $paymentContainer = $('.axepta2-payment-groups-container');
	const $paymentIcons = $paymentContainer.find('.payment-icon');
	const $warning = $('#axepta2-cgv-info'); // optionnel

	if ($cgvCheckbox.length === 0 || $paymentIcons.length === 0) {
		return;
	}

	function togglePaymentAvailability(disabled) {
		$paymentContainer.toggleClass('cgv-disabled', disabled);
		if ($warning.length) {
			$warning.toggle(disabled);
		}
	}

	togglePaymentAvailability(!$cgvCheckbox.is(':checked'));

	$cgvCheckbox.on('change', function() {
		togglePaymentAvailability(!$(this).is(':checked'));
	});
}

function checkPageShow() {
	$(window).on('pageshow', function (event) {
		if (event.originalEvent.persisted) {
			// Si la page est restaurée depuis le cache du navigateur, on recharge
			window.location.reload();
		}
	});
}
