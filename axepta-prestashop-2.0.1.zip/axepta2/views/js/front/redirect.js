/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */
$(document).ready(function() {
	initPaymentMethodSelection();
});

// Sélection et soumission du moyen de paiement
function initPaymentMethodSelection() {
	const $container = $('.axepta2-payment-groups-container');
	if ($container.length === 0) return;

	$container.on('click', '.payment-icon', function () {
		const paymentId = $(this).data('id');

		$container.find('.payment-icon').removeClass('selected');
		$(this).addClass('selected');

		if (!paymentId) {
			console.warn('Aucune data-id trouvée sur l’élément cliqué');
			return;
		}

		const $form = $('input[name="axepta2_payment_method_organization"]').closest('form');
		if ($form.length === 0) {
			console.error('Impossible de trouver le formulaire de paiement');
			return;
		}

		const $input = $form.find('input[name="axepta2_payment_method_id"]');
		if ($input.length === 0) {
			console.error('Le champ hidden axepta2_payment_method_id est introuvable');
			return;
		}

		$input.val(paymentId);

		const $loader = ensureAxeptaLoader();
		showAxeptaLoader($loader);

		$form.trigger('submit');
	});
}
