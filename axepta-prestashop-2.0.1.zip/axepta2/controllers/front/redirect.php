<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

use Axepta2\Entity\Axepta2configurationAccount;
use Axepta2\Entity\Axepta2transaction;
use Axepta2\Exception\Axepta2Exception;
use Axepta2\Exception\ConfigurationNotFoundException;
use Axepta2\Exception\NotMatchException;
use Axepta2\Exception\PaymentMethodIdMissingException;
use Axepta2\Exception\PaymentMethodNotAllowedException;
use Axepta2\Exception\PaymentMethodOrganizationMissingException;
use Axepta2\Exception\RedirectLinkException;
use Axepta2\Utils\Logger;
use Axepta2\Utils\Utils;
use AxeptaPaygate\Core\AxeptaPaygate;
use AxeptaPaygate\Core\OperationType;

class Axepta2RedirectModuleFrontController extends ModuleFrontController
{
    public function postProcess()
    {
        try {
            Logger::info('Redirect CALL');
            $configurationRepository = $this->get('axepta2.repository.configuration_account');
            $configuration = $configurationRepository->getCurrentConfiguration();

            if (!$configuration) {
                throw new ConfigurationNotFoundException();
            }

            $paymentMethodOrganization = Tools::getValue('axepta2_payment_method_organization');
            if ($paymentMethodOrganization === false) {
                throw new PaymentMethodOrganizationMissingException();
            }

            if ($configuration->getPaymentMethodOrganization() != $paymentMethodOrganization) {
                throw new NotMatchException();
            }

            $cart = $this->context->cart;
            $repositoryIC = $this->get('axepta2.repository.iso_country');

            $trigram = null;
            if ($configuration->getPaymentMethodOrganization() == Axepta2configurationAccount::PAYMENT_METHOD_ORGANIZATION_GROUPED) {
                $paymentMethodId = Tools::getValue('axepta2_payment_method_id');
                if ($paymentMethodId === false) {
                    throw new PaymentMethodIdMissingException();
                }

                if (!$configuration->hasConfigurationPaymentMethodId($paymentMethodId)) {
                    throw new PaymentMethodNotAllowedException();
                }

                $paymentMethodRepository = $this->get('axepta2.repository.payment_method');
                $paymentMethod = $paymentMethodRepository->find($paymentMethodId);
                $trigram = $paymentMethod->getTrigram();
            }

            $params = Utils::buildAxeptaParams(
                $trigram,
                OperationType::SIMPLE_PAYMENT,
                $cart,
                $configuration,
                $this->context,
                $repositoryIC
            );

            AxeptaPaygate::init($params['args']);
            $operation = AxeptaPaygate::buildOperation();
            $logs = $operation['params'];
            Axepta2transaction::anonymizeRecursive($logs);
            Logger::info(json_encode($logs));

            $request = $operation['request'];
            $response = $request->call();
            $json = json_decode($response, true);

            if (!isset($json['_links']['redirect']['href'])) {
                Logger::critical(print_r($json, true));

                throw new RedirectLinkException();
            }

            $urlRedirect = $json['_links']['redirect']['href'];
        } catch (Axepta2Exception $ce) {
            Logger::critical($ce->getMessage());
            $this->errors[] = $this->module->getTranslator()->trans($ce->getMessage(), [], 'Modules.Axepta2.Exception');
        } catch (Exception $e) {
            Logger::critical($e->getMessage());
            $this->errors[] = $this->module->getTranslator()->trans('An error occurred during the payment process. Please try again.', [], 'Modules.Axepta2.Exception');
        }

        if (!empty($this->errors)) {
            $this->redirectWithNotifications($this->context->link->getPageLink('order', true, null, ['step' => 3]));
        }

        Tools::redirect(isset($urlRedirect) ? $urlRedirect : 'index.php');
    }
}
