<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Repository;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Axepta2\Entity\Axepta2configurationAccount;
use Doctrine\ORM\EntityRepository;

class Axepta2configurationAccountRepository extends EntityRepository
{
    const ACTIVE_TRUE = 1;

    const ACTIVE_FALSE = 0;

    const MODE_VIEW_REDIRECT = 1;

    const MODE_VIEW_IFRAME = 2;

    public function updateConfigurationAccount(Axepta2configurationAccount $account): void
    {
        $this->_em->persist($account);
        $this->_em->flush();
    }

    public function getCurrentConfiguration($idShop = null)
    {
        if (null === $idShop) {
            if (\Shop::isFeatureActive() && \Shop::CONTEXT_ALL === \Shop::getContext()) {
                $idShop = 0;
            } else {
                $idShop = \Shop::getContextShopID();
            }
        }

        $cacheKey = 'axepta2_config_' . (int) $idShop;

        // Vérifie si c’est déjà en cache (en mémoire ou système PS)
        if (\Cache::isStored($cacheKey)) {
            return \Cache::retrieve($cacheKey);
        }

        $configuration = $this->createQueryBuilder('c')
            ->where('c.idShop IN (:ids)')
            ->setParameter('ids', [0, $idShop])
            ->orderBy('c.idShop', 'DESC') // Priorité à la config boutique
            ->setMaxResults(1)
            ->getQuery()
            ->getOneOrNullResult();

        // Mise en cache
        \Cache::store($cacheKey, $configuration);

        return $configuration;
    }

    public function findPaymentMethodsByAccount(Axepta2configurationAccount $account): array
    {
        $qb = $this->createQueryBuilder('pm')
            ->where('pm.configuration = :account')
            ->setParameter('account', $account);

        return $qb->getQuery()->getResult();
    }
}
