<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Utils;

if (!defined('_PS_VERSION_')) {
    exit;
}

class Logger
{
    const FOLDER = 'logs';

    const FILENAME = 'debug';

    const EMERGENCY = 1;

    const ALERT = 2;

    const CRITICAL = 3;

    const ERROR = 4;

    const WARN = 5;

    const NOTICE = 6;

    const INFO = 7;

    const DEBUG = 8;

    /**
     * @var array
     */
    protected static $levels = [
        self::EMERGENCY => 'EMERGENCY',
        self::ALERT => 'ALERT',
        self::CRITICAL => 'CRITICAL',
        self::ERROR => 'ERROR',
        self::WARN => 'WARNING',
        self::NOTICE => 'NOTICE',
        self::INFO => 'INFO',
        self::DEBUG => 'DEBUG',
    ];

    /**
     * @return int|false
     */
    public static function emergency(string $msg)
    {
        return self::log($msg, self::EMERGENCY);
    }

    /**
     * @return int|false
     */
    public static function alert(string $msg)
    {
        return self::log($msg, self::ALERT);
    }

    /**
     * @return int|false
     */
    public static function critical(string $msg)
    {
        return self::log($msg, self::CRITICAL);
    }

    /**
     * @return int|false
     */
    public static function error(string $msg)
    {
        return self::log($msg, self::ERROR);
    }

    /**
     * @return int|false
     */
    public static function warn(string $msg)
    {
        return self::log($msg, self::WARN);
    }

    /**
     * @return int|false
     */
    public static function notice(string $msg)
    {
        return self::log($msg, self::NOTICE);
    }

    /**
     * @return int|false
     */
    public static function info(string $msg)
    {
        return self::log($msg, self::INFO);
    }

    /**
     * @return int|false
     */
    public static function debug(string $msg)
    {
        return self::log($msg, self::DEBUG);
    }

    /**
     * @return int|false
     */
    private static function log(string $msg, int $levelDegree)
    {
        if (!isset(self::$levels[$levelDegree])) {
            return false;
        }

        $debug = debug_backtrace(2);

        return file_put_contents(
            self::getLogFilePath(),
            sprintf(
                '[%s][%s][%s::%s] : %s' . PHP_EOL,
                date('Y-m-d H:i:s'),
                self::$levels[$levelDegree],
                $debug[2]['class'],
                $debug[2]['function'],
                $msg
            ),
            FILE_APPEND | LOCK_EX
        );
    }

    public static function getLogFilePath(): string
    {
        return __DIR__ . '/../../' . self::FOLDER . '/' . self::FILENAME . '.log';
    }
}
