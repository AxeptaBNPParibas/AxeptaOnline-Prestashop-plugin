<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */
namespace Axepta2\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Table()
 *
 * @ORM\Entity(repositoryClass="Axepta2\Repository\Axepta2paymentMethodRepository")
 */
class Axepta2paymentMethod
{
    const CREDIT_CARD = 1;

    const PAYPAL = 2;

    const APPLE_PAY = 3;

    const AMEX = 4;

    /**
     * @ORM\Id
     *
     * @ORM\GeneratedValue(strategy="AUTO")
     *
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="integer")
     */
    private $groupId;

    /**
     * @ORM\Column(type="string", length=255)
     */
    private $name;

    /**
     * @ORM\Column(type="json", nullable=true)
     */
    private $config;  // Configuration dynamique pour cette méthode

    /**
     * @ORM\Column(type="string", length=3)
     */
    private $trigram;

    /**
     * @ORM\Column(type="datetime")
     */
    private $createdAt;

    /**
     * @ORM\Column(type="datetime")
     */
    private $updatedAt;

    /**
     * @ORM\Column(type="integer")
     */
    private $position;

    /**
     * @ORM\OneToMany(targetEntity="Axepta2\Entity\Axepta2configurationPaymentMethod", mappedBy="paymentMethod", fetch="EAGER")
     */
    private $configurationPaymentMethods;

    public function __construct()
    {
        $this->config = [];
        $this->createdAt = new \DateTime();
        $this->updatedAt = new \DateTime();
        $this->configurationPaymentMethods = new ArrayCollection();
        $this->position = 0;
    }

    // Getters and setters...
    public function getId(): int
    {
        return $this->id;
    }

    public function setId(int $id): self
    {
        $this->id = $id;

        return $this;
    }

    public function getGroupId(): int
    {
        return $this->groupId;
    }

    public function setGroupId(int $groupId): self
    {
        $this->groupId = $groupId;

        return $this;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function setName(string $name): self
    {
        $this->name = $name;

        return $this;
    }

    public function getConfig(): array
    {
        return $this->config;
    }

    public function setConfig(array $config): self
    {
        $this->config = $config;

        return $this;
    }

    public function getTrigram(): string
    {
        return $this->trigram;
    }

    public function setTrigram(string $trigram): self
    {
        $this->trigram = $trigram;

        return $this;
    }

    public function getCreatedAt(): \DateTime
    {
        return $this->createdAt;
    }

    public function setCreatedAt(\DateTime $createdAt): self
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    public function getUpdatedAt(): \DateTime
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt(\DateTime $updatedAt): self
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    public function getPosition(): int
    {
        return $this->position;
    }

    public function setPosition(int $position): self
    {
        $this->position = $position;

        return $this;
    }

    /**
     * @return Collection<int, Axepta2configurationPaymentMethod>
     */
    public function getConfigurationPaymentMethods(): Collection
    {
        return $this->configurationPaymentMethods;
    }

    public function addConfigurationPaymentMethod(Axepta2configurationPaymentMethod $configurationPaymentMethod): self
    {
        if (!$this->configurationPaymentMethods->contains($configurationPaymentMethod)) {
            $this->configurationPaymentMethods[] = $configurationPaymentMethod;
            $configurationPaymentMethod->setPaymentMethod($this);
        }

        return $this;
    }

    public function removeConfigurationPaymentMethod(Axepta2configurationPaymentMethod $configurationPaymentMethod): self
    {
        if ($this->configurationPaymentMethods->removeElement($configurationPaymentMethod)) {
            // set the owning side to null (unless already changed)
            if ($configurationPaymentMethod->getPaymentMethod() === $this) {
                $configurationPaymentMethod->setPaymentMethod(null);
            }
        }

        return $this;
    }

    public function toArray(): array
    {
        return [
            'id' => $this->getId(),
            'groupId' => $this->getGroupId(),
            'name' => $this->getName(),
            'config' => $this->getConfig(),
            'trigram' => $this->getTrigram(),
            'createdAt' => $this->getCreatedAt()->format('Y-m-d H:i:s'),
            'updatedAt' => $this->getUpdatedAt()->format('Y-m-d H:i:s'),
            'position' => $this->getPosition(),
            'configurationPaymentMethods' => array_map(function ($config) {
                return $config->toArray();
            }, $this->configurationPaymentMethods->toArray()),
        ];
    }
}
