<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Entity;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="Axepta2\Repository\Axepta2isoCountryRepository")
 */
class Axepta2isoCountry
{
    /**
     * @var int
     *
     * @ORM\Column(name="id_country", type="integer")
     *
     * @ORM\Id
     */
    private $idCountry;

    /**
     * @var string
     *
     * @ORM\Column(name="name", type="string", length=64)
     */
    private $name;

    /**
     * @var string
     *
     * @ORM\Column(name="iso_code_2", type="string", length=3)
     */
    private $isoCode2;

    /**
     * @var string
     *
     * @ORM\Column(name="iso_code_3", type="string", length=3)
     */
    private $isoCode3;

    /**
     * @var int
     *
     * @ORM\Column(name="num_code", type="integer")
     */
    private $numCode;

    /**
     * @var float
     *
     * @ORM\Column(name="latitude", type="float")
     */
    private $latitude;

    /**
     * @var float
     *
     * @ORM\Column(name="longitude", type="float")
     */
    private $longitude;

    public function getIdCountry(): int
    {
        return $this->idCountry;
    }

    public function setIdCountry(int $idCountry)
    {
        $this->idCountry = $idCountry;

        return $this;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function setName(string $name)
    {
        $this->name = $name;

        return $this;
    }

    public function getIsoCode2(): string
    {
        return $this->isoCode2;
    }

    public function setIsoCode2(string $isoCode2)
    {
        $this->isoCode2 = $isoCode2;

        return $this;
    }

    public function getIsoCode3(): string
    {
        return $this->isoCode3;
    }

    public function setIsoCode3(string $isoCode3)
    {
        $this->isoCode3 = $isoCode3;

        return $this;
    }

    public function getNumCode(): int
    {
        return $this->numCode;
    }

    public function setNumCode(int $numCode)
    {
        $this->numCode = $numCode;

        return $this;
    }

    public function getLatitude(): float
    {
        return $this->latitude;
    }

    public function setLatitude(float $latitude)
    {
        $this->latitude = $latitude;

        return $this;
    }

    public function getLongitude(): float
    {
        return $this->longitude;
    }

    public function setLongitude(float $longitude)
    {
        $this->longitude = $longitude;

        return $this;
    }

    public function toArray()
    {
        return [
            'id_country' => $this->getIdCountry(),
            'name' => $this->getName(),
            'iso_code_2' => $this->getIsoCode2(),
            'iso_code_3' => $this->getIsoCode3(),
            'num_code' => $this->getNumCode(),
            'latitude' => $this->getLatitude(),
            'longitude' => $this->getLongitude(),
        ];
    }
}
