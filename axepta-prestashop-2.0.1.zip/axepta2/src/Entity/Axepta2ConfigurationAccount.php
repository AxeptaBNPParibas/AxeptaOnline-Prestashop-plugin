<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Entity;

if (!defined('_PS_VERSION_')) {
    exit;
}

use AxeptaPaygate\Core\CaptureMode;
use AxeptaPaygate\Core\PaymentMode;
use AxeptaPaygate\Core\PaymentRenderingMode;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Table()
 *
 * @ORM\Entity(repositoryClass="Axepta2\Repository\Axepta2configurationAccountRepository")
 */
class Axepta2configurationAccount
{
    /* =====================
       Constantes
    ===================== */
    const MODE_DEMO = 0;

    const MODE_PRODUCTION = 1;

    const MODE_TEST = 2;

    const MODE_VIEW_REDIRECTION = 1;

    const MODE_VIEW_IFRAME = 2;

    const PAYMENT_METHOD_ORGANIZATION_GROUPED = 0;

    const PAYMENT_METHOD_ORGANIZATION_HPP = 1;

    const DISPLAY_METHOD_REDIRECT = 0;

    const DISPLAY_METHOD_IFRAME = 1;

    const CAPTURE_MODE_AUTO = 0;

    const CAPTURE_MODE_MANUAL = 1;

    const CAPTURE_MODE_DELAYED = 2;

    const FRICTION_LESS_VALUE = 30;

    const CIPHERING = 'AES-128-CTR';

    /* =====================
       Propriétés
    ===================== */
    /**
     * @ORM\Id
     *
     * @ORM\GeneratedValue(strategy="IDENTITY")
     *
     * @ORM\Column(name="id", type="integer", nullable=false, options={"unsigned"=true})
     */
    private $id;

    /** @ORM\Column(type="integer", unique=true) */
    private $idShop;

    /** @ORM\Column(name="mode", type="integer") */
    private $mode;

    /** @ORM\Column(name="public_key_test", type="string", length=255, nullable=true) */
    private $publicKeyTest;

    /** @ORM\Column(name="private_key_test", type="string", length=255, nullable=true) */
    private $privateKeyTest;

    /** @ORM\Column(name="public_key_prod", type="string", length=255, nullable=true) */
    private $publicKeyProd;

    /** @ORM\Column(name="private_key_prod", type="string", length=255, nullable=true) */
    private $privateKeyProd;

    /** @ORM\Column(name="active", type="boolean") */
    private $active;

    /** @ORM\Column(name="payment_method_organization", type="integer") */
    private $paymentMethodOrganization;

    /** @ORM\Column(name="display_method", type="integer") */
    private $displayMethod;

    /** @ORM\Column(name="capture_mode", type="integer") */
    private $captureMode;

    // Display options
    /** @ORM\Column(name="show_logo", type="boolean") */
    private $showLogo = false;

    /** @ORM\Column(name="logo_url", type="text", nullable=true) */
    private $logoUrl;

    /** @ORM\Column(name="view_cart_summary", type="boolean") */
    private $viewCartSummary = false;

    /** @ORM\Column(name="view_buyer_details", type="boolean") */
    private $viewBuyerDetails = false;

    /** @ORM\Column(name="show_billing_addr", type="boolean") */
    private $showBillingAddr = false;

    /** @ORM\Column(name="show_shipping_addr", type="boolean") */
    private $showShippingAddr = false;

    /** @ORM\Column(name="show_custom_title", type="boolean") */
    private $showCustomTitle = false;

    /** @ORM\Column(name="custom_title", type="text", nullable=true) */
    private $customTitle;

    /** @ORM\Column(name="show_custom_text", type="boolean") */
    private $showCustomText = false;

    /** @ORM\Column(name="custom_text", type="text", nullable=true) */
    private $customText;

    /** @ORM\Column(type="datetime") */
    private $createdAt;

    /** @ORM\Column(type="datetime") */
    private $updatedAt;

    /** @ORM\Column(name="enable_log", type="boolean") */
    private $enableLog = false;

    /** @ORM\Column(name="visa_specific_iso_exclusion", type="string", length=255, nullable=true) */
    private $visaSpecificIsoExclusion;

    /** @ORM\OneToMany(targetEntity="Axepta2\Entity\Axepta2configurationPaymentMethod", mappedBy="configuration", cascade={"persist", "remove"}, fetch="EAGER") */
    private $configurationPaymentMethods;

    /* =====================
       Constructeur
    ===================== */
    public function __construct()
    {
        $this->configurationPaymentMethods = new ArrayCollection();
        $this->createdAt = new \DateTime();
        $this->updatedAt = new \DateTime();
        $this->enableLog = false;
        $this->captureMode = self::CAPTURE_MODE_AUTO;
        $this->displayMethod = self::DISPLAY_METHOD_REDIRECT;
        $this->paymentMethodOrganization = self::PAYMENT_METHOD_ORGANIZATION_GROUPED;
        $this->mode = self::MODE_DEMO;
    }

    /* =====================
       Getters / Setters
    ===================== */

    public function getId()
    {
        return $this->id;
    }

    public function setId(int $id)
    {
        $this->id = $id;

        return $this;
    }

    public function getIdShop()
    {
        return $this->idShop;
    }

    public function setIdShop($idShop)
    {
        $this->idShop = $idShop;

        return $this;
    }

    public function getMode()
    {
        return $this->mode;
    }

    public function setMode($mode)
    {
        $this->mode = $mode;

        return $this;
    }

    public function getPublicKeyTest()
    {
        return $this->publicKeyTest;
    }

    public function setPublicKeyTest($publicKeyTest)
    {
        $this->publicKeyTest = $publicKeyTest;

        return $this;
    }

    public function getPrivateKeyTest()
    {
        return $this->privateKeyTest;
    }

    public function setPrivateKeyTest($privateKeyTest)
    {
        $this->privateKeyTest = $privateKeyTest;

        return $this;
    }

    public function getPublicKeyProd()
    {
        return $this->publicKeyProd;
    }

    public function setPublicKeyProd($publicKeyProd)
    {
        $this->publicKeyProd = $publicKeyProd;

        return $this;
    }

    public function getPrivateKeyProd()
    {
        return $this->privateKeyProd;
    }

    public function setPrivateKeyProd($privateKeyProd)
    {
        $this->privateKeyProd = $privateKeyProd;

        return $this;
    }

    public function getActive()
    {
        return $this->active;
    }

    public function setActive($active)
    {
        $this->active = $active;

        return $this;
    }

    public function getPaymentMethodOrganization()
    {
        return $this->paymentMethodOrganization;
    }

    public function setPaymentMethodOrganization($value)
    {
        $this->paymentMethodOrganization = $value;

        return $this;
    }

    public function getDisplayMethod()
    {
        return $this->displayMethod;
    }

    public function setDisplayMethod($value)
    {
        $this->displayMethod = $value;

        return $this;
    }

    public function getCaptureMode()
    {
        return $this->captureMode;
    }

    public function setCaptureMode($value)
    {
        $this->captureMode = $value;

        return $this;
    }

    public function getShowLogo()
    {
        return $this->showLogo;
    }

    public function setShowLogo($value)
    {
        $this->showLogo = $value;

        return $this;
    }

    public function getLogoUrl()
    {
        return $this->logoUrl;
    }

    public function setLogoUrl($value)
    {
        $this->logoUrl = $value;

        return $this;
    }

    public function getViewCartSummary()
    {
        return $this->viewCartSummary;
    }

    public function setViewCartSummary($value)
    {
        $this->viewCartSummary = $value;

        return $this;
    }

    public function getViewBuyerDetails()
    {
        return $this->viewBuyerDetails;
    }

    public function setViewBuyerDetails($value)
    {
        $this->viewBuyerDetails = $value;

        return $this;
    }

    public function getShowBillingAddr()
    {
        return $this->showBillingAddr;
    }

    public function setShowBillingAddr($value)
    {
        $this->showBillingAddr = $value;

        return $this;
    }

    public function getShowShippingAddr()
    {
        return $this->showShippingAddr;
    }

    public function setShowShippingAddr($value)
    {
        $this->showShippingAddr = $value;

        return $this;
    }

    public function getShowCustomTitle()
    {
        return $this->showCustomTitle;
    }

    public function setShowCustomTitle($value)
    {
        $this->showCustomTitle = $value;

        return $this;
    }

    public function getCustomTitle()
    {
        return $this->customTitle;
    }

    public function setCustomTitle($value)
    {
        $this->customTitle = $value;

        return $this;
    }

    public function getShowCustomText()
    {
        return $this->showCustomText;
    }

    public function setShowCustomText($value)
    {
        $this->showCustomText = $value;

        return $this;
    }

    public function getCustomText()
    {
        return $this->customText;
    }

    public function setCustomText($value)
    {
        $this->customText = $value;

        return $this;
    }

    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    public function setCreatedAt($value)
    {
        $this->createdAt = $value;

        return $this;
    }

    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt($value)
    {
        $this->updatedAt = $value;

        return $this;
    }

    public function getEnableLog()
    {
        return $this->enableLog;
    }

    public function setEnableLog($value)
    {
        $this->enableLog = $value;

        return $this;
    }

    public function getVisaSpecificIsoExclusion()
    {
        if (null === $this->visaSpecificIsoExclusion) {
            return [];
        }

        return explode(',', $this->visaSpecificIsoExclusion);
    }

    public function setVisaSpecificIsoExclusion($value)
    {
        $this->visaSpecificIsoExclusion = $value;

        return $this;
    }

    public function getConfigurationPaymentMethods()
    {
        return $this->configurationPaymentMethods;
    }

    public function addConfigurationPaymentMethod($paymentMethod)
    {
        if (!$this->configurationPaymentMethods->contains($paymentMethod)) {
            $this->configurationPaymentMethods[] = $paymentMethod;
            $paymentMethod->setConfiguration($this);
        }

        return $this;
    }

    public function removeConfigurationPaymentMethod($paymentMethod)
    {
        if ($this->configurationPaymentMethods->removeElement($paymentMethod)) {
            if ($paymentMethod->getConfiguration() === $this) {
                $paymentMethod->setConfiguration(null);
            }
        }

        return $this;
    }

    /* =====================
       Helpers
    ===================== */
    public function getPublicKey()
    {
        switch ($this->mode) {
            case self::MODE_TEST:
                return $this->getPublicKeyTest();

            case self::MODE_PRODUCTION:
                return $this->getPublicKeyProd();

            case self::MODE_DEMO:
            default:
                return \Configuration::getGlobalValue('AXEPTA2_DEMO_PUBLICKEY');
        }
    }

    public function getPrivateKey()
    {
        switch ($this->getMode()) {
            case self::MODE_TEST:
                return $this->getPrivateKeyTest();

            case self::MODE_PRODUCTION:
                return $this->getPrivateKeyProd();

            case self::MODE_DEMO:
            default:
                return \Configuration::getGlobalValue('AXEPTA2_DEMO_PRIVATEKEY');
        }
    }

    public function getPaymentMode()
    {
        switch ($this->getMode()) {
            case self::MODE_TEST:
                return PaymentMode::TEST;

            case self::MODE_PRODUCTION:
                return PaymentMode::PRODUCTION;

            case self::MODE_DEMO:
            default:
                return PaymentMode::DEMO;
        }
    }

    public function isDemoModeOn()
    {
        return $this->getMode() == self::MODE_DEMO;
    }

    public function getCaptureModeMap()
    {
        $map = [
            self::CAPTURE_MODE_AUTO => CaptureMode::AUTO,
            self::CAPTURE_MODE_MANUAL => CaptureMode::MANUAL,
            self::CAPTURE_MODE_DELAYED => CaptureMode::AUTO,
        ];

        return $map[$this->getCaptureMode()];
    }

    public function getModeMap()
    {
        $map = [
            self::MODE_DEMO => PaymentMode::DEMO,
            self::MODE_PRODUCTION => PaymentMode::PRODUCTION,
            self::MODE_TEST => PaymentMode::TEST,
        ];

        return $map[$this->getMode()];
    }

    public function getPaymentMethodOrganizationMap()
    {
        $map = [
            self::PAYMENT_METHOD_ORGANIZATION_GROUPED => PaymentRenderingMode::REDIRECT,
            self::PAYMENT_METHOD_ORGANIZATION_HPP => PaymentRenderingMode::HPP,
        ];

        return $map[$this->getPaymentMethodOrganization()];
    }

    public function hasConfigurationPaymentMethodId(int $paymentMethodId): bool
    {
        foreach ($this->configurationPaymentMethods as $configurationPaymentMethod) {
            if ($configurationPaymentMethod->getPaymentMethod()->getId() === $paymentMethodId && $configurationPaymentMethod->isActive()) {
                return true;
            }
        }

        return false;
    }

    /* =====================
       Convert to array
    ===================== */
    public function toArray()
    {
        return [
            'id' => $this->getId(),
            'id_shop' => $this->getIdShop(),
            'mode' => $this->getMode(),
            'public_key_prod' => $this->getPublicKeyProd(),
            'private_key_prod' => $this->getPrivateKeyProd(),
            'public_key_test' => $this->getPublicKeyTest(),
            'private_key_test' => $this->getPrivateKeyTest(),
            'active' => $this->getActive(),
            'payment_method_organization' => $this->getPaymentMethodOrganization(),
            'display_method' => $this->getDisplayMethod(),
            'capture_mode' => $this->getCaptureMode(),
            'show_logo' => $this->getShowLogo(),
            'logo_url' => $this->getLogoUrl(),
            'view_cart_summary' => $this->getViewCartSummary(),
            'view_buyer_details' => $this->getViewBuyerDetails(),
            'show_billing_addr' => $this->getShowBillingAddr(),
            'show_shipping_addr' => $this->getShowShippingAddr(),
            'show_custom_title' => $this->getShowCustomTitle(),
            'custom_title' => $this->getCustomTitle(),
            'show_custom_text' => $this->getShowCustomText(),
            'custom_text' => $this->getCustomText(),
            'enable_log' => $this->getEnableLog(),
            'visa_specific_iso_exclusion' => $this->getVisaSpecificIsoExclusion(),
            'created_at' => $this->getCreatedAt()->format('Y-m-d H:i:s'),
            'updated_at' => $this->getUpdatedAt()->format('Y-m-d H:i:s'),
            'configuration_payment_methods' => array_map(function ($pm) {
                return $pm->toArray();
            }, $this->configurationPaymentMethods->toArray()),
        ];
    }
}
