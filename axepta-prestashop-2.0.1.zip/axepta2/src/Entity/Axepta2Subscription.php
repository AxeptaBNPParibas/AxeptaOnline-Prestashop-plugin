<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Entity;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Table()
 *
 * @ORM\Entity(repositoryClass="Axepta2\Repository\Axepta2subscriptionRepository")
 */
class Axepta2subscription
{
    /**
     * @ORM\Id
     *
     * @ORM\Column(name="id_axepta2_subscription", type="integer")
     *
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /** @ORM\Column(name="product_id", type="integer") */
    private $productId;

    /** @ORM\Column(name="order_id", type="integer") */
    private $orderId;

    /** @ORM\Column(name="customer_id", type="integer") */
    private $customerId;

    /** @ORM\Column(name="axepta2_transaction_id", type="integer") */
    private $transactionId;

    /** @ORM\Column(name="amount_tax_excl", type="float") */
    private $amountTaxExcl;

    /** @ORM\Column(name="current_specific_price", type="decimal") */
    private $currentSpecificPrice;

    /** @ORM\Column(name="status", type="integer") */
    private $status;

    /** @ORM\Column(name="periodicity", type="string", length=10) */
    private $periodicity;

    /** @ORM\Column(name="occurence_interval", type="integer") */
    private $occurenceInterval;

    /** @ORM\Column(name="current_occurence", type="integer") */
    private $currentOccurence;

    /** @ORM\Column(name="last_schedule", type="datetime", nullable=true) */
    private $lastSchedule;

    /** @ORM\Column(name="next_schedule", type="datetime", nullable=true) */
    private $nextSchedule;

    /** @ORM\Column(name="scheme_reference_id", type="string", length=128) */
    private $schemeReferenceId;

    /** @ORM\Column(name="created_at", type="datetime") */
    private $createdAt;

    /** @ORM\Column(name="updated_at", type="datetime") */
    private $updatedAt;

    /** @ORM\Column(name="visible", type="boolean") */
    private $visible;

    // /** @ORM\Column(name="id_tax_rules_group", type="integer") */
    // private $idTaxRulesGroup;

    // /** @ORM\Column(name="id_axepta2_transaction", type="integer") */
    // private $idTransaction;

    // /** @ORM\Column(name="number_occurences", type="integer") */
    // private $numberOccurences;

    // /** @ORM\Column(name="current_occurence", type="integer", options={"default":0}) */
    // private $currentOccurence = 0;

    // /** @ORM\Column(name="id_cart_paused_currency", type="integer", options={"default":0}) */
    // private $idCartPausedCurrency = 0;

    public function __construct()
    {
        $this->status = 1;
        $this->createdAt = new \DateTime();
        $this->updatedAt = new \DateTime();
    }

    /* =======================
       Getters et Setters
       ======================= */

    public function getId()
    {
        return $this->id;
    }

    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    public function getProductId()
    {
        return $this->productId;
    }

    public function setProductId($productId)
    {
        $this->productId = $productId;

        return $this;
    }

    public function getOrderId()
    {
        return $this->orderId;
    }

    public function setOrderId($orderId)
    {
        $this->orderId = $orderId;

        return $this;
    }

    public function getCustomerId()
    {
        return $this->customerId;
    }

    public function setCustomerId($customerId)
    {
        $this->customerId = $customerId;

        return $this;
    }

    public function getTransactionId()
    {
        return $this->transactionId;
    }

    public function setTransactionId($transactionId)
    {
        $this->transactionId = $transactionId;

        return $this;
    }

    public function getAmountTaxExcl()
    {
        return $this->amountTaxExcl;
    }

    public function setAmountTaxExcl($amountTaxExclude)
    {
        $this->amountTaxExcl = $amountTaxExclude;

        return $this;
    }

    public function getCurrentSpecificPrice()
    {
        return $this->currentSpecificPrice;
    }

    public function setCurrentSpecificPrice($currentSpecificPrice)
    {
        $this->currentSpecificPrice = $currentSpecificPrice;

        return $this;
    }

    public function getStatus()
    {
        return $this->status;
    }

    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    public function getPeriodicity()
    {
        return $this->periodicity;
    }

    public function setPeriodicity($periodicity)
    {
        $this->periodicity = $periodicity;

        return $this;
    }

    public function getOccurenceInterval()
    {
        return $this->occurenceInterval;
    }

    public function setOccurenceInterval($occurenceInterval)
    {
        $this->occurenceInterval = $occurenceInterval;

        return $this;
    }

    public function getCurrentOccurence()
    {
        return $this->currentOccurence;
    }

    public function setCurrentOccurence($currentOccurence)
    {
        $this->currentOccurence = $currentOccurence;

        return $this;
    }

    public function getLastSchedule()
    {
        return $this->lastSchedule;
    }

    public function setLastSchedule($lastSchedule)
    {
        $this->lastSchedule = $lastSchedule;

        return $this;
    }

    public function getNextSchedule()
    {
        return $this->nextSchedule;
    }

    public function setNextSchedule($nextSchedule)
    {
        $this->nextSchedule = $nextSchedule;

        return $this;
    }

    public function getSchemeReferenceId()
    {
        return $this->schemeReferenceId;
    }

    public function setSchemeReferenceId($schemeReferenceId)
    {
        $this->schemeReferenceId = $schemeReferenceId;

        return $this;
    }

    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    public function getVisible()
    {
        return $this->visible;
    }

    public function setVisible($visible)
    {
        $this->visible = $visible;

        return $this;
    }

    /* =======================
       Conversion en tableau
       ======================= */
    public function toArray(): array
    {
        return [
            'id' => $this->getId(),
            'product_id' => $this->getProductId(),
            'order_id' => $this->getOrderId(),
            'customer_id' => $this->getCustomerId(),
            'transaction_id' => $this->getTransactionId(),
            'amount_tax_excl' => $this->getAmountTaxExcl(),
            'current_specific_price' => $this->getCurrentSpecificPrice(),
            'status' => $this->getStatus(),
            'periodicity' => $this->getPeriodicity(),
            'occurence_interval' => $this->getOccurenceInterval(),
            'current_occurence' => $this->getCurrentOccurence(),
            'last_schedule' => $this->getLastSchedule() ? $this->getLastSchedule()->format('Y-m-d H:i:s') : null,
            'next_schedule' => $this->getNextSchedule() ? $this->getNextSchedule()->format('Y-m-d H:i:s') : null,
            'scheme_reference_id' => $this->getSchemeReferenceId(),
            'created_at' => $this->getCreatedAt() ? $this->getCreatedAt()->format('Y-m-d H:i:s') : null,
            'updated_at' => $this->getUpdatedAt() ? $this->getUpdatedAt()->format('Y-m-d H:i:s') : null,
            'visible' => $this->getVisible(),
        ];
    }
}
