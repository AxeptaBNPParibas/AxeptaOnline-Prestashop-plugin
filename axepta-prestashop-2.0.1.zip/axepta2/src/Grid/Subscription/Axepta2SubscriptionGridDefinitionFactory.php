<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Grid\Subscription;

if (!defined('_PS_VERSION_')) {
    exit;
}

// Si la nouvelle classe existe, on l'utilise via un alias "DataColumn"
if (class_exists('PrestaShop\PrestaShop\Core\Grid\Column\Type\Common\DataColumn')) {
    class_alias(
        'PrestaShop\PrestaShop\Core\Grid\Column\Type\Common\DataColumn',
        'PrestaShop\PrestaShop\Core\Grid\Column\Type\DataColumn'
    );
}

use PrestaShop\PrestaShop\Core\Grid\Action\Row\RowActionCollection;
use PrestaShop\PrestaShop\Core\Grid\Action\Row\Type\LinkRowAction;
use PrestaShop\PrestaShop\Core\Grid\Column\ColumnCollection;
use PrestaShop\PrestaShop\Core\Grid\Column\Type\Common\ActionColumn;
use PrestaShop\PrestaShop\Core\Grid\Column\Type\Common\LinkColumn;
use PrestaShop\PrestaShop\Core\Grid\Column\Type\DataColumn;
use PrestaShop\PrestaShop\Core\Grid\Definition\Factory\AbstractGridDefinitionFactory;
use PrestaShop\PrestaShop\Core\Grid\Filter\Filter;
use PrestaShop\PrestaShop\Core\Grid\Filter\FilterCollection;
use PrestaShopBundle\Form\Admin\Type\DateRangeType;
use PrestaShopBundle\Form\Admin\Type\SearchAndResetType;
use Symfony\Component\Form\Extension\Core\Type\TextType;

final class Axepta2SubscriptionGridDefinitionFactory extends AbstractGridDefinitionFactory
{
    const GRID_ID = 'admin_axepta2_subscription';

    protected function getId()
    {
        return self::GRID_ID;
    }

    protected function getName()
    {
        return $this->trans('Subscriptions', [], 'Modules.Axepta2.Transaction');
    }

    protected function getColumns()
    {
        return (new ColumnCollection())
            ->add(
                (new DataColumn('id_axepta2_subscription'))
                ->setName($this->trans('ID', [], 'Modules.Axepta2.Subscription'))
                ->setOptions([
                    'field' => 'id_axepta2_subscription',
                ])
            )
            ->add(
                (new LinkColumn('product'))
                ->setName($this->trans('Product', [], 'Modules.Axepta2.Subscription'))
                ->setOptions([
                    'field' => 'name',
                    'route' => 'admin_product_form',
                    'route_param_name' => 'id',
                    'route_param_field' => 'product_id',
                ])
            )
            ->add(
                (new LinkColumn('reference'))
                ->setName($this->trans('Order', [], 'Modules.Axepta2.Subscription'))
                ->setOptions([
                    'field' => 'reference',
                    'route' => 'admin_orders_view',
                    'route_param_name' => 'orderId',
                    'route_param_field' => 'order_id',
                ])
            )
            ->add(
                (new LinkColumn('customer'))
                ->setName($this->trans('Customer', [], 'Modules.Axepta2.Subscription'))
                ->setOptions([
                    'field' => 'customer_fullname',
                    'route' => 'admin_customers_view',
                    'route_param_name' => 'customerId',
                    'route_param_field' => 'customer_id',
                ])
            )
            ->add(
                (new DataColumn('amount_tax_excl'))
                ->setName($this->trans('Amount Tax Exclude', [], 'Modules.Axepta2.Subscription'))
                ->setOptions([
                    'field' => 'amount_tax_excl',
                ])
            )
            ->add(
                (new DataColumn('status'))
                ->setName($this->trans('Status', [], 'Modules.Axepta2.Subscription'))
                ->setOptions([
                    'field' => 'status',
                ])
            )
            ->add(
                (new DataColumn('periodicity'))
                ->setName($this->trans('Periodicity', [], 'Modules.Axepta2.Subscription'))
                ->setOptions([
                    'field' => 'periodicity',
                ])
            )
            ->add(
                (new DataColumn('last_schedule'))
                ->setName($this->trans('Last Schedule', [], 'Modules.Axepta2.Subscription'))
                ->setOptions([
                    'field' => 'last_schedule',
                ])
            )
            ->add(
                (new DataColumn('next_schedule'))
                ->setName($this->trans('Next Schedule', [], 'Modules.Axepta2.Subscription'))
                ->setOptions([
                    'field' => 'next_schedule',
                ])
            )
            ->add(
                (new ActionColumn('actions'))
                ->setName('Actions')
                ->setOptions([
                    'actions' => null,
                ])
            )
            ->add(
                (new ActionColumn('search'))
                ->setName('')
                ->setOptions([
                    'actions' => $this->getRowActions(),
                ])
            )
        ;
    }

    /**
     * {@inheritdoc}
     *
     * Define filters and associate them with columns.
     * Note that you can add filters that are not associated with any column.
     */
    protected function getFilters()
    {
        return (new FilterCollection())
            ->add(
                (new Filter('id_axepta2_subscription', TextType::class))
                ->setTypeOptions([
                    'required' => false,
                ])
                ->setAssociatedColumn('id_axepta2_subscription')
            )
            ->add(
                (new Filter('last_schedule', DateRangeType::class))
                ->setTypeOptions([
                    'required' => false,
                ])
                ->setAssociatedColumn('last_schedule')
            )
            ->add(
                (new Filter('next_schedule', DateRangeType::class))
                ->setTypeOptions([
                    'required' => false,
                ])
                ->setAssociatedColumn('next_schedule')
            )
            ->add(
                (new Filter('search', SearchAndResetType::class))
                ->setTypeOptions([
                    'reset_route' => 'admin_common_reset_search_by_filter_id',
                    'reset_route_params' => [
                        'filterId' => self::GRID_ID,
                    ],
                    'redirect_route' => 'axepta2_admin_transaction_list',
                ])
                ->setAssociatedColumn('search')
            )
        ;
    }

    /**
     * Extracted row action definition into separate method.
     */
    private function getRowActions()
    {
        return (new RowActionCollection())
            ->add(
                (new LinkRowAction('enable'))
                    ->setName($this->trans('Enable', [], 'Admin.Actions'))
                    ->setOptions([
                        'route' => 'axepta2_admin_subscription_enable',
                        'route_param_name' => 'recordId',
                        'route_param_field' => 'id_axepta2_subscription',
                    ])
                    ->setIcon('check')
            )
            ->add(
                (new LinkRowAction('disable'))
                    ->setName($this->trans('Disable', [], 'Admin.Actions'))
                    ->setOptions([
                        'route' => 'axepta2_admin_subscription_disable',
                        'route_param_name' => 'recordId',
                        'route_param_field' => 'id_axepta2_subscription',
                    ])
                    ->setIcon('remove')
            )
            ->add(
                (new LinkRowAction('delete'))
                    ->setName($this->trans('Delete', [], 'Admin.Actions'))
                    ->setOptions([
                        'route' => 'axepta2_admin_subscription_delete',
                        'route_param_name' => 'recordId',
                        'route_param_field' => 'id_axepta2_subscription',
                    ])
                    ->setIcon('delete')
            );
    }
}
