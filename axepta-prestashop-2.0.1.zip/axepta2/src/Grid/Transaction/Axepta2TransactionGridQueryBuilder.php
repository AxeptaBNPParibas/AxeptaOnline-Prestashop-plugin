<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Grid\Transaction;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Query\QueryBuilder;
use PrestaShop\PrestaShop\Core\Grid\Query\AbstractDoctrineQueryBuilder;
use PrestaShop\PrestaShop\Core\Grid\Search\SearchCriteriaInterface;

final class Axepta2TransactionGridQueryBuilder extends AbstractDoctrineQueryBuilder
{
    private $contextShopId;

    public function __construct(Connection $connection, $dbPrefix, $contextShopId)
    {
        parent::__construct($connection, $dbPrefix);
        $this->contextShopId = $contextShopId;
    }

    public function getSearchQueryBuilder(SearchCriteriaInterface $searchCriteria): QueryBuilder
    {
        $qb = $this->getBaseQuery();

        $this->applyFilters($qb, $searchCriteria);

        // Sélection et pagination
        $select = [
            'rec.id_axepta2_transaction',
            'rec.trans_id',
            'rec.order_id',
            'o.reference',
            'rec.pay_id',
            'rec.response_code',
            'rec.description',
            'rec.amount',
            'rec.payment_mean_type',
            'rec.created_at',
            'rec.transaction_type',
            'rec.status',
            'rec.need_capture',
            'rec.currency',
        ];

        $qb->select(implode(',', $select))
           ->orderBy(
               $searchCriteria->getOrderBy(),
               $searchCriteria->getOrderWay()
           )
           ->setFirstResult($searchCriteria->getOffset() ?? 0)
           ->setMaxResults($searchCriteria->getLimit());

        return $qb;
    }

    public function getCountQueryBuilder(SearchCriteriaInterface $searchCriteria): QueryBuilder
    {
        $qb = $this->getBaseQuery();
        $this->applyFilters($qb, $searchCriteria);
        $qb->select('COUNT(rec.id_axepta2_transaction) AS total');

        return $qb;
    }

    private function getBaseQuery(): QueryBuilder
    {
        $qb = $this->connection
            ->createQueryBuilder()
            ->from($this->dbPrefix . 'axepta2transaction', 'rec')
            ->leftJoin(
                'rec',
                $this->dbPrefix . 'orders',
                'o',
                'rec.order_id = o.id_order'
            );

        // 🔹 Filtrer par boutique uniquement si on est dans une boutique spécifique
        if ($this->contextShopId !== \Shop::CONTEXT_ALL) {
            $qb
                ->andWhere('o.id_shop = :idShop')
                ->setParameter('idShop', $this->contextShopId);
        }

        return $qb;
    }

    private function applyFilters(QueryBuilder $qb, SearchCriteriaInterface $searchCriteria): void
    {
        $filters = $searchCriteria->getFilters();

        foreach ($filters as $filterName => $filterValue) {
            if ('active' === $filterName) {
                (bool) $filterValue
                    ? $qb->andWhere('rec.active = 1')
                    : $qb->andWhere('rec.active = 0');

                continue;
            }

            if ('created_at' === $filterName && $filterValue) {
                $qb->andWhere('rec.created_at BETWEEN :from AND :to')
                   ->setParameter('from', $filterValue['from'] . ' 00:00:00')
                   ->setParameter('to', $filterValue['to'] . ' 23:59:59');

                continue;
            }

            if ('demo_mode' === $filterName) {
                continue;
            }

            $qb->andWhere("$filterName LIKE :$filterName")
               ->setParameter($filterName, '%' . $filterValue . '%');
        }

        // Inlude or exclude demo transaction
        $inclOrExcl = array_key_exists('demo_mode', $searchCriteria->getFilters()) ? '=' : '!=';
        $qb->andWhere('rec.merchant_id ' . $inclOrExcl . ' :demo_merchant')
            ->setParameter('demo_merchant', \Configuration::get('AXEPTA2_DEMO_PUBLICKEY'));
    }
}
