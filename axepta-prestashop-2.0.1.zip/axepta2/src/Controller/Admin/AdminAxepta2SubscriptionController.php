<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Axepta2\Entity\Axepta2configurationAccount;
use Axepta2\Entity\Axepta2subscription;
use Axepta2\Filter\Axepta2subscriptionFilter;
use Axepta2\Repository\Axepta2configurationAccountRepository;
use Doctrine\ORM\EntityManagerInterface;
use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;

class AdminAxepta2subscriptionController extends FrameworkBundleAdminController
{
    public function listAction(Request $request): Response
    {
        $gridFactory = $this->get('axepta2.subscription.grid.factory');
        $filters = Axepta2subscriptionFilter::fromRequest($request);
        $grid = $gridFactory->getGrid($filters);

        /** @var Axepta2configurationAccountRepository $repository */
        $repository = $this->getDoctrine()->getRepository(Axepta2configurationAccount::class);
        $account = $repository->getCurrentConfiguration();

        return $this->render(
            '@Modules/axepta2/views/templates/admin/subscription/list.html.twig',
            [
                'enableSidebar' => true,
                'layoutTitle' => $this->trans('Subscriptions', 'Modules.Payxpert.Subscription'),
                'grid' => $this->presentGrid($grid),
                'isDemoMode' => $account ? $account->isDemoModeOn() : false,
            ]
        );
    }

    /**
     * Activer un abonnement
     */
    public function enableAction(int $recordId, EntityManagerInterface $em, Request $request): RedirectResponse
    {
        $subscription = $em->getRepository(Axepta2subscription::class)->find($recordId);

        if (!$subscription) {
            $this->addFlash('error', $this->trans('Subscription not found.', 'Modules.Axepta2.Admin'));

            return $this->redirectToRoute('admin_axepta2_subscription_index');
        }

        $subscription->setStatus(1);
        $subscription->setUpdatedAt(new \DateTime());

        $em->flush();

        $this->addFlash('success', $this->trans('Subscription enabled successfully.', 'Modules.Axepta2.Admin'));

        return $this->redirectToRoute('admin_axepta2_subscription_index');
    }

    /**
     * Désactiver un abonnement
     */
    public function disableAction(int $recordId, EntityManagerInterface $em, Request $request): RedirectResponse
    {
        $subscription = $em->getRepository(Axepta2subscription::class)->find($recordId);

        if (!$subscription) {
            $this->addFlash('error', $this->trans('Subscription not found.', 'Modules.Axepta2.Admin'));

            return $this->redirectToRoute('admin_axepta2_subscription_list');
        }

        $subscription->setStatus(0);
        $subscription->setUpdatedAt(new \DateTime());

        $em->flush();

        $this->addFlash('success', $this->trans('Subscription disabled successfully.', 'Modules.Axepta2.Admin'));

        return $this->redirectToRoute('admin_axepta2_subscription_list');
    }

    /**
     * Supprimer un abonnement
     */
    public function deleteAction(int $recordId, EntityManagerInterface $em, Request $request): RedirectResponse
    {
        $subscription = $em->getRepository(Axepta2subscription::class)->find($recordId);

        if (!$subscription) {
            $this->addFlash('error', $this->trans('Subscription not found.', 'Modules.Axepta2.Admin'));

            return $this->redirectToRoute('admin_axepta2_subscription_list');
        }

        $subscription->setVisible(0);
        $subscription->setUpdatedAt(new \DateTime());

        $em->flush();

        $this->addFlash('success', $this->trans('Subscription deleted successfully.', 'Modules.Axepta2.Admin'));

        return $this->redirectToRoute('admin_axepta2_subscription_list');
    }
}
