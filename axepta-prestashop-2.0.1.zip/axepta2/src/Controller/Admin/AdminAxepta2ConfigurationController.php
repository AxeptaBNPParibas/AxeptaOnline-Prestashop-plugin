<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Axepta2\Entity\Axepta2configurationAccount;
use Axepta2\Form\Support\SupportFormType;
use Axepta2\Repository\Axepta2configurationAccountRepository;
use Axepta2\Utils\Logger;
use Axepta2\Utils\Utils;
use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\JsonResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\ResponseHeaderBag;

class AdminAxepta2ConfigurationController extends FrameworkBundleAdminController
{
    public function index(Request $request): Response
    {
        $context = $this->get('prestashop.adapter.legacy.context')->getContext();
        $shopContext = \Shop::getContext();
        $multiShop = \Shop::isFeatureActive();

        // Vérifier si on est en mode "Groupe de boutiques"
        if ($multiShop && $shopContext === \Shop::CONTEXT_GROUP) {
            // Affiche un template d'information
            return $this->render(
                '@Modules/axepta2/views/templates/admin/configuration/group-mode-info.html.twig',
                [
                    'layoutTitle' => $this->trans('Account Configuration', 'Modules.Axepta2.Configuration'),
                ]
            );
        }

        $shopID = (!$multiShop || \Shop::CONTEXT_ALL === \Shop::getContext()) ? 0 : \Shop::getContextShopID();

        /** @var Axepta2configurationAccountRepository $repository */
        $repository = $this->getDoctrine()->getRepository(Axepta2configurationAccount::class);
        $account = $repository->getCurrentConfiguration($shopID);

        // On utilise getFormFor() pour déclencher automatiquement le DataProvider
        $formBuilder = $this->get('axepta2.configuration.form_type.form_builder');
        $form = $formBuilder->getFormFor($shopID);
        $form->handleRequest($request);

        // Soumission
        if ($form->isSubmitted() && $form->isValid()) {
            $formHandler = $this->get('axepta2.configuration.form_type.form_handler');
            $result = $formHandler->handleFor($shopID, $form);

            if ($result->isValid()) {
                $this->addFlash(
                    'success',
                    $this->trans('Configuration saved successfully', 'Modules.Axepta2.Configuration')
                );

                return $this->redirectToRoute('axepta2_admin_configuration');
            }

            // Ajoute une erreur globale au formulaire si le handler échoue
            $form->addError(new \Symfony\Component\Form\FormError(
                $this->trans('An error occurred while saving the configuration.', 'Modules.Axepta2.Configuration')
            ));
        }

        $configurationContext = 'all';
        if ($account) {
            $accountShopID = $account->getIdShop();
            if ($accountShopID === 0 && $shopID != 0) {
                $configurationContext = 'notspe';
            } elseif ($accountShopID === $shopID && $shopID != 0) {
                $configurationContext = 'spe';
            }
        }

        // Infos module
        /** @var \Axepta2 $moduleInstance */
        $moduleInstance = \Module::getInstanceByName('axepta2');
        $moduleLogoUrl = $context->shop->getBaseURL() . 'modules/axepta2/views/img/logo.png';
        $axepta2Helper = $this->get('axepta2.helper');
        $parameters = $moduleInstance->getModuleDebugInfo();

        $formFactory = $this->get('form.factory');
        $supportForm = $formFactory->create(SupportFormType::class);

        return $this->render(
            '@Modules/axepta2/views/templates/admin/configuration/form.html.twig',
            [
                'layoutTitle' => $this->trans('Account Configuration', 'Modules.Axepta2.Configuration'),
                'Axepta2ConfigurationForm' => $form->createView(),
                'module_logo_url' => $moduleLogoUrl,
                'module_version' => $moduleInstance ? $moduleInstance->version : 'unknown',
                'moduleDebugInfo' => $parameters,
                'update_available' => Utils::isUpdateAvailable(),
                'add' => !$account, // true si pas de compte trouvé
                'isDemoMode' => $axepta2Helper->isDemoModeOn(),
                'configurationContext' => $multiShop ? $configurationContext : false,
                'supportForm' => $supportForm->createView(),
            ]
        );
    }

    public function downloadAction()
    {
        $logFile = Logger::getLogFilePath();

        if (!file_exists($logFile)) {
            $this->addFlash('error', $this->trans('Log file not found.', 'Modules.Axepta2.Response'));

            return $this->redirectToRoute('axepta2_admin_configuration');
        }

        $response = new BinaryFileResponse($logFile);
        $response->setContentDisposition(
            ResponseHeaderBag::DISPOSITION_ATTACHMENT,
            'log_file_' . date('Y_m_d_His') . '.log'
        );

        return $response;
    }

    public function supportAction(Request $request)
    {
        if (!$request->isXmlHttpRequest()) {
            return new Response($this->trans('Invalid Request', 'Modules.Axepta2.Response'), Response::HTTP_BAD_REQUEST);
        }

        $formFactory = $this->get('form.factory');
        $form = $formFactory->create(SupportFormType::class);

        if ($request->isMethod('POST')) {
            $form->handleRequest($request);

            if (!$form->isSubmitted() || !$form->isValid()) {
                return new JsonResponse([
                    'error' => $this->trans('Please correct the errors in the form.', 'Modules.Axepta2.Response'),
                    'formErrors' => $this->getFormErrors($form),
                ], Response::HTTP_BAD_REQUEST);
            }

            $data = $form->getData();
            $shopName = \Configuration::get('PS_SHOP_NAME');

            /** @var Axepta2configurationAccountRepository $repository */
            $repository = $this->getDoctrine()->getRepository(Axepta2configurationAccount::class);

            /** @var Axepta2configurationAccount $account */
            $account = $repository->getCurrentConfiguration();

            $shops = \Shop::getShops(false, null, true);
            $shopUrls = [];
            foreach ($shops as $idShop => $shopNameItem) {
                $shop = new \Shop($idShop);
                $shopUrls[] = '- ' . $shop->getBaseURL(true);
            }

            $templateVars = [
                '{name}' => $data['name'],
                '{email}' => $data['email'],
                '{description}' => $data['description'],
                '{shop_name}' => $shopName,
                '{mid}' => $account->getPublicKeyProd(),
                '{shop_urls}' => implode('<br>', $shopUrls), // pour HTML
                '{shop_urls_txt}' => implode("\n", $shopUrls), // pour TXT
            ];

            $module = \Module::getInstanceByName('axepta2');

            /** @var \Axepta2 $module */
            $moduleInfo = $module->getModuleDebugInfo();
            $moduleInfo = array_map(function ($value) {
                return $value === true ? 'yes' : ($value === false ? 'no' : $value);
            }, $moduleInfo);

            $templateVars = array_merge($templateVars, $moduleInfo);
            $context = $this->get('prestashop.adapter.legacy.context')->getContext();
            $language = $context->language;

            $to = \Configuration::get('AXEPTA2_SUPPORT_EMAIL');
            $subject = 'Demande SAV du marchand : ' . $shopName;

            $mailSent = \Mail::Send(
                (int) $language->id,
                'ask_for_support_mail',
                $subject,
                $templateVars,
                $to,
                null,
                $data['email'],
                $data['name'],
                null,
                null,
                _PS_MODULE_DIR_ . 'axepta2/mails/'
            );

            if (!$mailSent) {
                Logger::info('Support request submition failed');

                return new JsonResponse([
                    'error' => $this->trans('Failed to send the support request email. You can activate the DEBUG Mode and try again to know more about the error or check the PrestaShop LOGs', 'Modules.Axepta2.Response'),
                ], Response::HTTP_BAD_REQUEST);
            }

            Logger::info('Support request submitted');

            return new JsonResponse(['success' => $this->trans('Your support request has been submitted successfully.', 'Modules.Axepta2.Response')]);
        }

        return new JsonResponse($this->trans('Invalid Request', 'Modules.Axepta2.Response'), Response::HTTP_BAD_REQUEST);
    }

    /**
     * Helper function to extract form errors.
     */
    private function getFormErrors($form)
    {
        $errors = [];
        foreach ($form->getErrors(true) as $error) {
            $errors[$error->getOrigin()->getName()] = $error->getMessage();
        }

        return $errors;
    }
}
