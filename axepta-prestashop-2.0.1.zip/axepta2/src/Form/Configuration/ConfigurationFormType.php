<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Form\Configuration;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Axepta2\Entity\Axepta2configurationAccount;
use Axepta2\Validator\ApiKeyConstraint;
use PrestaShopBundle\Form\Admin\Type\SwitchType;
use PrestaShopBundle\Form\Admin\Type\TranslatableType;
use PrestaShopBundle\Form\Admin\Type\TranslatorAwareType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;
use Symfony\Component\Form\Extension\Core\Type\HiddenType;
use Symfony\Component\Form\Extension\Core\Type\PasswordType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\UrlType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\FormEvent;
use Symfony\Component\Form\FormEvents;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Validator\Constraints\NotBlank;

class ConfigurationFormType extends TranslatorAwareType
{
    public function __construct($translator, array $locales)
    {
        parent::__construct($translator, $locales);
    }

    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $add = empty($options['data']);

        $builder
            ->add('mode', ChoiceType::class, [
                'required' => true,
                'multiple' => false,
                'choices' => $this->formatDataChoicesList(
                    [
                        [
                            'id' => 0,
                            'name' => 'Demo',
                        ],
                        [
                            'id' => 2,
                            'name' => 'Test',
                        ],
                        [
                            'id' => 1,
                            'name' => 'Production',
                        ],
                    ]
                ),
                'label' => 'Mode',
                'attr' => [
                    'data-demo-help' => $this->trans(
                        'Money is not collected in Demo Mode.',
                        'Modules.Axepta2.Account'
                    ),
                ],
            ])
            ->add('public_key_test', TextType::class, [
                'required' => true,
                'label' => $this->trans('Merchant ID', 'Modules.Axepta2.Account'),
            ])
            ->add('private_key_test', PasswordType::class, [
                'required' => $add ? true : false,
                'label' => $this->trans('API Key', 'Modules.Axepta2.Account'),
                'attr' => $add ? [] : ['placeholder' => '********'],
            ])
            ->add('public_key_prod', TextType::class, [
                'required' => true,
                'label' => $this->trans('Merchant ID', 'Modules.Axepta2.Account'),
            ])
            ->add('private_key_prod', PasswordType::class, [
                'required' => $add ? true : false,
                'label' => $this->trans('API Key', 'Modules.Axepta2.Account'),
                'attr' => $add ? [] : ['placeholder' => '********'],
            ])
            ->add('active', SwitchType::class, [
                'label' => $this->trans('Active', 'Modules.Axepta2.Account'),
            ])
            ->add('save', SubmitType::class, [
                'label' => $this->trans('Save', 'Admin.Actions'),
            ])
        ;

        if (!$add) {
            $builder
                // Payment Configuration
                ->add('payment_method_organization', ChoiceType::class, [
                    'label' => $this->trans('Organization of Payment methods', 'Modules.Axepta2.Account'),
                    'choices' => $this->formatDataChoicesList(
                        [
                            [
                                'id' => Axepta2configurationAccount::PAYMENT_METHOD_ORGANIZATION_GROUPED,
                                'name' => $this->trans('Choice of payment method on the merchant site', 'Modules.Axepta2.Configuration'),
                            ],
                            [
                                'id' => Axepta2configurationAccount::PAYMENT_METHOD_ORGANIZATION_HPP,
                                'name' => $this->trans('Choice of payment method on the Axepta BNP Paribas page', 'Modules.Axepta2.Configuration'),
                            ],
                        ]
                    ),
                ])
                ->add('display_method', ChoiceType::class, [
                    'label' => $this->trans('Display method', 'Modules.Axepta2.Account'),
                    'choices' => $this->formatDataChoicesList(
                        [
                            [
                                'id' => Axepta2configurationAccount::DISPLAY_METHOD_REDIRECT,
                                'name' => $this->trans('Redirect', 'Modules.Axepta2.Configuration'),
                            ],
                            // #45246 : incoming feature
                            // [
                            //     'id' => Axepta2configurationAccount::DISPLAY_METHOD_IFRAME,
                            //     'name' => $this->trans('IFrame', 'Modules.Axepta2.Configuration'),
                            // ],
                        ]
                    ),
                ])
                ->add('capture_mode', ChoiceType::class, [
                    'label' => $this->trans('Capture mode', 'Modules.Axepta2.Account'),
                    'choices' => $this->formatDataChoicesList(
                        [
                            [
                                'id' => Axepta2configurationAccount::CAPTURE_MODE_AUTO,
                                'name' => $this->trans('Automatic', 'Modules.Axepta2.Configuration'),
                            ],
                            [
                                'id' => Axepta2configurationAccount::CAPTURE_MODE_MANUAL,
                                'name' => $this->trans('Manual', 'Modules.Axepta2.Configuration'),
                            ],
                            // [
                            //     'id' => Axepta2configurationAccount::CAPTURE_MODE_DELAYED,
                            //     'name' => $this->trans('Delayed', 'Modules.Axepta2.Configuration')
                            // ],
                        ]
                    ),
                ])
                // Payment Methods
                ->add('payment_methods', PaymentMethodType::class)
                // Personalization
                ->add('show_logo', SwitchType::class, [
                    'label' => $this->trans('Show logo on payment page', 'Modules.Axepta2.Account'),
                ])
                ->add('logo_url', UrlType::class, [
                    'label' => $this->trans('Logo URL', 'Modules.Axepta2.Account'),
                    'required' => false,
                    'help' => $this->trans('Recommanded 200x100px', 'Modules.Axepta2.Account'),
                ])
                ->add('view_cart_summary', SwitchType::class, [
                    'label' => $this->trans('View cart summary', 'Modules.Axepta2.Account'),
                ])
                ->add('view_buyer_details', SwitchType::class, [
                    'label' => $this->trans('View buyer details', 'Modules.Axepta2.Account'),
                ])
                ->add('show_billing_addr', SwitchType::class, [
                    'label' => $this->trans('Show billing address', 'Modules.Axepta2.Account'),
                ])
                ->add('show_shipping_addr', SwitchType::class, [
                    'label' => $this->trans('Show shipping address', 'Modules.Axepta2.Account'),
                ])
                ->add('show_custom_title', SwitchType::class, [
                    'label' => $this->trans('Show a custom title', 'Modules.Axepta2.Account'),
                ])
                ->add('custom_title', TextType::class, [
                    'label' => $this->trans('Custom title', 'Modules.Axepta2.Account'),
                    'required' => false,
                    'attr' => [
                        'placeholder' => $this->trans('Custom title', 'Modules.Axepta2.Account'),
                    ],
                ])
                ->add('show_custom_text', SwitchType::class, [
                    'label' => $this->trans('Show a custom text', 'Modules.Axepta2.Account'),
                ])
                ->add('custom_text', TextareaType::class, [
                    'label' => $this->trans('Custom text', 'Modules.Axepta2.Account'),
                    'required' => false,
                    'attr' => [
                        'placeholder' => $this->trans('Custom text', 'Modules.Axepta2.Account'),
                    ],
                ])
                ->add('front_label', TranslatableType::class, [
                    'type' => TextType::class,
                    'label' => $this->trans('Front label', 'Modules.Axepta2.Account'),
                    'required' => true,
                    'locales' => $this->locales,
                ])
                ->add('enable_log', SwitchType::class, [
                    'label' => $this->trans('LOGs', 'Modules.Axepta2.Account'),
                    'help' => $this->trans('Log recordings', 'Modules.Axepta2.Account'),
                ])
                ->add('visa_specific_iso_exclusion', TextType::class, [
                    'label' => $this->trans('ISO code to ignore', 'Modules.Axepta2.Account'),
                    'help' => $this->trans('List of ISO codes separated by comma to not send to Visa payment gateways (Edit this field only if you have created specific zones for your carriers).', 'Modules.Axepta2.Account') . ' (AD, AL, AT, BY, BE, BA, BG, HR, CY, CZ, DK, EE, FI, FR, GE, DE, GR, HU, IS, IE, IT, KZ, KW, LV, LI, LT, LU, MT, MD, MC, ME, NL, NO, PL, PT, RO, RU, RS, SK, SI, ES, SE, CH, TR, UA, GB, VA)',
                    'required' => false,
                ])
            ;
        }

        $builder->add('id', HiddenType::class);

        // Ajouter un listener pour modifier les contraintes selon la valeur de "mode"
        $builder->addEventListener(FormEvents::PRE_SUBMIT, function (FormEvent $event) use ($add) {
            $data = $event->getData();
            $form = $event->getForm();

            if (!isset($data['mode'])) {
                return;
            }

            switch ($data['mode']) {
                case Axepta2configurationAccount::MODE_TEST:
                    $form->add('public_key_test', TextType::class, [
                        'required' => true,
                        'constraints' => [new NotBlank()],
                    ]);
                    if ($add) {
                        $form->add('private_key_test', PasswordType::class, [
                            'required' => true,
                            'constraints' => [new NotBlank()],
                        ]);
                    }

                    break;

                case Axepta2configurationAccount::MODE_PRODUCTION:
                    $form->add('public_key_prod', TextType::class, [
                        'required' => true,
                        'constraints' => [new NotBlank()],
                    ]);
                    if ($add) {
                        $form->add('private_key_prod', PasswordType::class, [
                            'required' => true,
                            'constraints' => [new NotBlank()],
                        ]);
                    }

                    break;

                case Axepta2configurationAccount::MODE_DEMO:
                default:
                    // Pas de contraintes supplémentaires
                    break;
            }

            // show_logo
            if (!empty($data['show_logo']) && $data['show_logo'] == 1) {
                $form->add('logo_url', UrlType::class, [
                    'label' => 'Logo URL',
                    'constraints' => [new NotBlank()],
                ]);
            }

            // show_custom_title
            if (!empty($data['show_custom_title']) && $data['show_custom_title'] == 1) {
                $form->add('custom_title', TextType::class, [
                    'label' => 'Custom title',
                    'constraints' => [new NotBlank()],
                ]);
            }

            // show_custom_text
            if (!empty($data['show_custom_text']) && $data['show_custom_text'] == 1) {
                $form->add('custom_text', TextareaType::class, [
                    'label' => 'Custom text',
                    'constraints' => [new NotBlank()],
                ]);
            }
        });
    }

    public function configureOptions(OptionsResolver $resolver)
    {
        $resolver->setDefaults([
            'translation_domain' => 'Modules.Axepta2.Account',
            'allow_extra_fields' => true,
            'csrf_protection' => true,
            'csrf_field_name' => '_token',
            'csrf_token_id' => 'axepta2_configuration',
            'constraints' => [
                new ApiKeyConstraint(),
            ],
        ]);
    }
}
