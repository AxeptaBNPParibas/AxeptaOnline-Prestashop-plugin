<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Form\Configuration;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Axepta2\Repository\Axepta2PaymentMethodRepository;
use PrestaShopBundle\Form\Admin\Type\SwitchType;
use PrestaShopBundle\Form\Admin\Type\TranslatorAwareType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class PaymentMethodType extends TranslatorAwareType
{
    private $paymentMethodRepository;

    public function __construct($translator, array $locales, Axepta2PaymentMethodRepository $paymentMethodRepository)
    {
        parent::__construct($translator, $locales);

        $this->paymentMethodRepository = $paymentMethodRepository;
    }

    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $paymentMethods = $this->paymentMethodRepository->findAllOrdered();

        foreach ($paymentMethods as $paymentMethod) {
            $config = $paymentMethod->getConfig();

            $rowAttr = ['data-logo' => $config['logo_img']];

            if ($paymentMethod->getGroupId() && !isset($config['is_group_leader'])) {
                $rowAttr['data-parent'] = $paymentMethod->getGroupId();
                $rowAttr['class'] = 'sub-payment';
            }

            if (isset($config['payment_methods'])) {
                $logos = [];
                foreach ($config['payment_methods'] as $pm) {
                    $logos[] = $pm['logo'];
                }
                $rowAttr['data-logo'] = implode(',', $logos); // devient une string
            }

            $builder->add('payment_method_' . $paymentMethod->getId(), SwitchType::class, [
                // Translation is initialy made in Installer
                'label' => $this->trans($paymentMethod->getName(), 'Modules.Axepta2.Account'),
                'required' => true,
                'choice_label' => false,
                'row_attr' => $rowAttr,
            ]);
        }
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => null, // On gère manuellement les données
        ]);
    }
}
