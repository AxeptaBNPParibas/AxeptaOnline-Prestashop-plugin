<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Form\Configuration;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Axepta2\Entity\Axepta2configurationAccount;
use Axepta2\Entity\Axepta2configurationPaymentMethod;
use Axepta2\Repository\Axepta2configurationAccountRepository;
use Axepta2\Repository\Axepta2paymentMethodRepository;
use PrestaShop\PrestaShop\Core\Form\IdentifiableObject\DataHandler\FormDataHandlerInterface;

if (!defined('_PS_VERSION_')) {
    exit;
}

final class ConfigurationFormDataHandler implements FormDataHandlerInterface
{
    private $configurationAccountRepository;

    private $paymentMethodRepository;

    public function __construct(
        Axepta2configurationAccountRepository $configurationAccountRepository,
        Axepta2paymentMethodRepository $paymentMethodRepository
    ) {
        $this->configurationAccountRepository = $configurationAccountRepository;
        $this->paymentMethodRepository = $paymentMethodRepository;
    }

    public function create(array $data)
    {
    }

    /**
     * Update an existing configuration account.
     */
    public function update($shopID, array $data)
    {
        $record = $this->configurationAccountRepository->getCurrentConfiguration($shopID);
        $update = true;

        $data['shop_id'] = $shopID;

        if (!is_object($record)) {
            // Create
            $update = false;
            $record = new Axepta2configurationAccount();
        }

        $this->fillData($record, $data, $update);

        $this->configurationAccountRepository->updateConfigurationAccount($record);

        \Cache::clean('axepta2_config_' . (int) $shopID);

        return $record->getId();
    }

    private function fillData(&$record, $data, $update)
    {
        $record->setMode($data['mode']);
        $record->setActive($data['active']);

        switch ($data['mode']) {
            default:
            case Axepta2configurationAccount::MODE_DEMO:
                break;

            case Axepta2configurationAccount::MODE_PRODUCTION:
                $record->setPublicKeyProd($data['public_key_prod']);
                if ($update === false || ($update === true && $data['private_key_prod'] != '')) {
                    $record->setPrivateKeyProd($data['private_key_prod']);
                }

                break;

            case Axepta2configurationAccount::MODE_TEST:
                $record->setPublicKeyTest($data['public_key_test']);
                if ($update === false || ($update === true && $data['private_key_test'] != '')) {
                    $record->setPrivateKeyTest($data['private_key_test']);
                }

                break;
        }

        if ($update) {
            $record->setPaymentMethodOrganization($data['payment_method_organization']);
            $record->setCaptureMode($data['capture_mode']);
            $record->setEnableLog($data['enable_log']);
            $record->setVisaSpecificIsoExclusion($data['visa_specific_iso_exclusion']);
            $record->setDisplayMethod($data['display_method']);
            $record->setShowLogo($data['show_logo']);
            if ($record->getShowLogo()) {
                $record->setLogoUrl($data['logo_url']);
            }
            $record->setViewCartSummary($data['view_cart_summary']);
            $record->setViewBuyerDetails($data['view_buyer_details']);
            $record->setShowBillingAddr($data['show_billing_addr']);
            $record->setShowShippingAddr($data['show_shipping_addr']);
            $record->setShowCustomTitle($data['show_custom_title']);
            if ($record->getShowCustomTitle()) {
                $record->setCustomTitle($data['custom_title']);
            }
            $record->setShowCustomText($data['show_custom_text']);
            if ($record->getShowCustomText()) {
                $record->setCustomText($data['custom_text']);
            }
            $record->setDisplayMethod($data['display_method']);
            $record->setUpdatedAt(new \DateTime());

            // Update configurationPaymentMethods
            foreach ($data['payment_methods'] as $paymentMethodKey => $isEnabled) {
                $paymentMethodId = (int) str_replace('payment_method_', '', $paymentMethodKey);

                // Look for the payment method
                $existingPaymentMethod = $record->getConfigurationPaymentMethods()
                    ->filter(function ($paymentMethod) use ($paymentMethodId) {
                        return $paymentMethod->getPaymentMethod()->getId() === $paymentMethodId;
                    })
                    ->first();

                // If it exists, update its status
                if ($existingPaymentMethod) {
                    $existingPaymentMethod->setActive($isEnabled == 1);
                } else {
                    // Otherwise, create a new payment method
                    // Find the PaymentMethod entity by its ID
                    $paymentMethodEntity = $this->paymentMethodRepository->find($paymentMethodId);

                    if ($paymentMethodEntity) {
                        $newPaymentMethod = new Axepta2configurationPaymentMethod();
                        $newPaymentMethod->setPaymentMethod($paymentMethodEntity);
                        $newPaymentMethod->setActive($isEnabled == 1);
                        $newPaymentMethod->setConfiguration($record);
                        $record->addConfigurationPaymentMethod($newPaymentMethod);
                    }
                }
            }

            foreach (\Language::getLanguages() as $lang) {
                $langId = $lang['id_lang'];
                $value = $data['front_label'][$langId];
                \Configuration::updateValue(
                    'AXEPTA2_FRONT_LABEL_' . $record->getId(),
                    [$langId => $value],
                    false,
                    null,
                    $data['shop_id']
                );
            }
        } else {
            $record->setIdShop($data['shop_id']);
            $record->setLogoUrl(_PS_BASE_URL_ . _PS_IMG_ . \Configuration::get('PS_LOGO'));

            // Get payment methods
            $paymentMethods = $this->paymentMethodRepository->findAll();

            foreach ($paymentMethods as $paymentMethod) {
                $configurationPaymentMethod = new Axepta2configurationPaymentMethod();
                $configurationPaymentMethod->setConfiguration($record);
                $configurationPaymentMethod->setPaymentMethod($paymentMethod);
                $configurationPaymentMethod->setActive(false);

                $record->addConfigurationPaymentMethod($configurationPaymentMethod);
            }
        }
    }

    public function allowedOptions($key)
    {
        $options = explode(';', $key);
        array_pop($options);

        return $options;
    }
}
