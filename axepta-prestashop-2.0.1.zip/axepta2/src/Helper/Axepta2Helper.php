<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Helper;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Axepta2\Repository\Axepta2configurationAccountRepository;

class Axepta2Helper
{
    private $Axepta2configurationAccountRepository;

    private $demoModeCache = [];

    public function __construct(Axepta2configurationAccountRepository $Axepta2configurationAccountRepository)
    {
        $this->Axepta2configurationAccountRepository = $Axepta2configurationAccountRepository;
    }

    /**
     * Vérifie si le compte actuel est en mode DEMO
     */
    public function isDemoModeOn(int $idShop = 0): bool
    {
        if (!isset($this->demoModeCache[$idShop])) {
            $accountConfig = $this->Axepta2configurationAccountRepository->getCurrentConfiguration($idShop);
            $this->demoModeCache[$idShop] = $accountConfig !== null
                && $accountConfig->isDemoModeOn();
        }

        return $this->demoModeCache[$idShop];
    }
}
