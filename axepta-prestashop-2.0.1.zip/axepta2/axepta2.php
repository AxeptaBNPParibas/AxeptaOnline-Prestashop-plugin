<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */
use Axepta2\Entity\Axepta2ConfigurationAccount;
use Axepta2\Entity\Axepta2Transaction;
use Axepta2\Repository\Axepta2transactionRepository;
use Axepta2\Utils\Installer;
use Axepta2\Utils\Logger;
use Axepta2\Utils\Utils;
use AxeptaPaygate\Exception\ApiCallException;
use PrestaShop\PrestaShop\Core\Payment\PaymentOption;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__ . '/vendor/autoload.php';

require_once __DIR__ . '/vendor/axepta-paygate/lib/init.php';

class Axepta2 extends PaymentModule
{
    /** @var string[] */
    public $hooks = [
        'actionAdminControllerSetMedia',
        'actionModuleInstallAfter',
        'actionFrontControllerSetMedia',
        'displayAdminOrder',
        'displayPaymentByBinaries',
        'paymentOptions',
        // 'paymentReturn',
    ];

    public function __construct()
    {
        $this->name = 'axepta2';
        $this->tab = 'payments_gateways';
        $this->version = '2.0.0';
        $this->author = 'We+';
        $this->need_instance = 0;

        // Set $this->bootstrap to true if your module is compliant with bootstrap (PrestaShop 1.6)
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = 'Axepta BNP Paribas 2.0';
        $this->description = $this->trans('Accept online and mobile payments on a secure page with BNP Paribas Axepta official module');
        $this->confirmUninstall = $this->trans('Are you sure you want to uninstall this module ?');

        $this->ps_versions_compliancy = ['min' => '1.7.8', 'max' => _PS_VERSION_];
    }

    public function getModuleTabs()
    {
        return [
            // Main menu
            [
                'class_name' => 'AdminAxepta2MenuController',
                'parent_class_name' => 'IMPROVE',
                'name' => [
                    'en' => 'Axepta BNP Paribas 2.0',
                ],
                'visible' => true,
                'icon' => 'apps',
                'route_name' => 'axepta2_admin_menu',
            ],
            // Sub-menu configuration
            [
                'class_name' => 'AdminAxepta2ConfigurationController',
                'parent_class_name' => 'AdminAxepta2MenuController',
                'name' => [
                    'en' => 'Configuration',
                ],
                'visible' => true,
                'icon' => 'settings',
                'route_name' => 'axepta2_admin_configuration',
            ],
            // Sub-menu transaction
            [
                'class_name' => 'AdminAxepta2TransactionController',
                'parent_class_name' => 'AdminAxepta2MenuController',
                'name' => [
                    'en' => 'Transactions',
                ],
                'visible' => true,
                'icon' => 'files',
                'route_name' => 'axepta2_admin_transaction_list',
            ],
            // Sub-menu subscription
            [
                'class_name' => 'AdminAxepta2SubscriptionController',
                'parent_class_name' => 'AdminAxepta2MenuController',
                'name' => [
                    'en' => 'Subscription',
                    'fr' => 'Abonnement',
                ],
                'visible' => true,
                'icon' => 'files',
                'route_name' => 'axepta2_admin_subscription_list',
            ],
        ];
    }

    public function install()
    {
        Logger::info('Launch');

        try {
            if (!parent::install()) {
                return false;
            }

            $installer = new Installer(
                $this,
                $this->get('prestashop.core.admin.tab.repository')
            );

            $installer->run();
        } catch (Exception $e) {
            Logger::critical($e->getMessage());
            $this->_errors[] = $e->getMessage();
            $this->uninstall();

            return false;
        }

        Logger::info('Installation complete');

        return true;
    }

    public function uninstall()
    {
        try {
            $installer = new Installer(
                $this,
                $this->get('prestashop.core.admin.tab.repository')
            );
            $installer->uninstall();
        } catch (Exception $e) {
            Logger::critical('erreur : ' . $e->getMessage());
            $this->_errors[] = $e->getMessage();

            return false;
        }

        return parent::uninstall();
    }

    public function enable($force_all = false)
    {
        $moduleTabs = \Tab::getCollectionFromModule($this->name);
        foreach ($moduleTabs as $moduleTab) {
            $moduleTab->active = true;
            $moduleTab->update();
        }

        return parent::enable();
    }

    public function disable($force_all = false)
    {
        $moduleTabs = \Tab::getCollectionFromModule($this->name);
        foreach ($moduleTabs as $moduleTab) {
            $moduleTab->active = false;
            $moduleTab->update();
        }

        return parent::disable();
    }

    public function getContent()
    {
        return Tools::redirectAdmin($this->context->link->getAdminLink('AdminAxepta2ConfigurationController'));
    }

    public function getModuleDebugInfo()
    {
        $moduleName = $this->name;
        $themePath = _PS_THEME_DIR_ . 'modules/' . $moduleName . '/';
        $overridePath = _PS_OVERRIDE_DIR_ . 'modules/' . $moduleName . '/';

        $isKeyValid = false;
        $axepta2ConfigurationAccountRepository = $this->get('axepta2.repository.configuration_account');
        $account = $axepta2ConfigurationAccountRepository->getCurrentConfiguration();

        if ($account) {
            try {
                Utils::getAccessToken(
                    $account->getPublicKey(),
                    $account->getPrivateKey(),
                    $account->getPaymentMode()
                );
                $isKeyValid = true;
            } catch (ApiCallException $ace) {
                // !Do nothing
            }
        }

        return [
            '{php_version}' => PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION . '.' . PHP_RELEASE_VERSION,
            '{cms_name}' => 'PrestaShop',
            '{cms_version}' => _PS_VERSION_,
            '{module_version}' => $this->version,
            '{is_overridden_in_override}' => is_dir($overridePath),
            '{is_overridden_in_theme}' => is_dir($themePath),
            '{is_php_version_ok}' => version_compare(PHP_MAJOR_VERSION . '.' . PHP_MINOR_VERSION . '.' . PHP_RELEASE_VERSION, '7.2', '>='),
            '{is_module_version_ok}' => !Utils::isUpdateAvailable(), // TODO
            '{is_cms_version_ok}' => version_compare(_PS_VERSION_, '1.7.8', '>='),
            '{is_key_valid}' => $isKeyValid,
        ];
    }

    public function hookActionAdminControllerSetMedia($params)
    {
        $this->context->controller->addJS($this->_path . 'views/js/back-all.js');

        if ('AdminOrders' === $this->context->controller->php_self) {
            $this->context->controller->addCSS($this->_path . 'views/css/admin/order.css');
        }

        // DEMO Mode CSS
        $this->context->controller->addCSS($this->_path . 'views/css/_partials/demo-banner.css');
    }

    public function hookActionModuleInstallAfter($params)
    {
        if ($params['module']->name === $this->name) {
            Tools::clearAllCache();
        }
    }

    public function hookActionFrontControllerSetMedia($params)
    {
        $axepta2ConfigurationAccountRepository = $this->get('axepta2.repository.configuration_account');

        /** @var Axepta2ConfigurationAccount $account */
        $account = $axepta2ConfigurationAccountRepository->getCurrentConfiguration();

        if (is_null($account)) {
            return;
        }

        Media::addJsDef([
            'redirect_loader_text' => $this->trans('Redirecting to payment page...', [], 'Modules.Axepta2.Loader'),
            'iframe_generating_payment_err_msg' => $this->trans('An error occured while generating the payment.', [], 'Modules.Axepta2.Iframe'),
            'iframe_unexpected_response_err_msg' => $this->trans('Unexpected response from server.', [], 'Modules.Axepta2.Iframe'),
        ]);

        // GLOBAL
        $this->context->controller->registerJavascript(
            'module-axepta2-front-all-js',
            'modules/axepta2/views/js/front-all.js'
        );

        $this->context->controller->registerStylesheet(
            'module-axepta2-front-all-css',
            'modules/axepta2/views/css/front-all.css'
        );

        // DEMO Mode
        $this->context->controller->registerStylesheet(
            'module-axepta2-demo-banner-css',
            'modules/axepta2/views/css/_partials/demo-banner.css'
        );

        // CHECKOUT
        if (('order' == $this->context->controller->php_self) || ('order-opc' == $this->context->controller->php_self)) {
            $this->context->controller->registerJavascript(
                'module-axepta2-checkout-js',
                'modules/axepta2/views/js/front/checkout.js'
            );

            $this->context->controller->registerStylesheet(
                'module-axepta2-checkout-css',
                'modules/axepta2/views/css/front/checkout.css'
            );

            if ($account->getDisplayMethod() == Axepta2ConfigurationAccount::DISPLAY_METHOD_IFRAME) {
                // IFRAME
                $this->context->controller->registerJavascript(
                    'module-axepta2-iframe-js',
                    'modules/axepta2/views/js/front/iframe.js'
                );

                $this->context->controller->registerStylesheet(
                    'module-axepta2-iframe-css',
                    'modules/axepta2/views/css/front/iframe.css'
                );

                Media::addJsDef([
                    'ajaxUrl' => $this->context->link->getModuleLink('axepta2', 'ajax', [], true),
                ]);
            }

            if ($account->getDisplayMethod() == Axepta2ConfigurationAccount::DISPLAY_METHOD_REDIRECT) {
                // REDIRECT
                $this->context->controller->registerJavascript(
                    'module-axepta2-redirect-js',
                    'modules/axepta2/views/js/front/redirect.js'
                );
            }
        }

        $axepta2Helper = $this->getContainer()->get('axepta2.helper');
        $this->context->smarty->assign('isDemoMode', $axepta2Helper->isDemoModeOn());
    }

    public function hookDisplayAdminOrder($params)
    {
        $order = new Order((int) $params['id_order']);

        if ($order->module != $this->name) {
            return;
        }

        /** @var Axepta2TransactionRepository */
        $transactionRepository = $this->get('axepta2.repository.transaction');
        $transactions = $transactionRepository->findBy(['orderId' => $order->id]);

        $orderTransactionsFormatted = Utils::getOrderTransactionsFormatted($transactions);
        $orderSlips = $order->getOrderSlipsCollection()->getResults();
        $orderSlips = array_filter($orderSlips, function ($orderSlip) use ($orderTransactionsFormatted) {
            return !in_array($orderSlip->id, $orderTransactionsFormatted['order_slip_used']);
        });

        // Set CAPTURE admin URL for each transaction
        $transactions = array_map(function ($transaction) {
            return array_merge(
                $transaction->toArray(),
                [
                    'capture_url' => $this->get('router')->generate(
                        'axepta2_admin_transaction_capture',
                        ['transactionId' => $transaction->getId()],
                        UrlGeneratorInterface::ABSOLUTE_URL
                    ),
                ]
            );
        }, $transactions);

        if (!empty($orderTransactionsFormatted['refundable']) && !empty($orderSlips)) {
            $orderSlipChoices = [];
            $comp_precision = $this->context->getComputingPrecision();

            foreach ($orderSlips as $orderSlip) {
                $orderSlip = (array) $orderSlip;
                $orderSlipAmountRefundable = $orderSlip['amount'];

                if (isset($orderTransactionsFormatted['order_slip_used'][$orderSlip['id']])) {
                    $orderSlipAmountRefundable -= $orderTransactionsFormatted['order_slip_used'][$orderSlip['id']];
                }

                if ($orderSlipAmountRefundable <= 0) {
                    continue;
                }

                $orderSlipChoices[] = [
                    'id' => $orderSlip['id'],
                    'name' => '#' . $orderSlip['id'] . ' | ' . $this->l('Amount') . ': ' . number_format($orderSlipAmountRefundable, $comp_precision),
                ];
            }
            $transactionChoices = [];
            foreach ($orderTransactionsFormatted['refundable'] as $transaction) {
                $transactionChoices[] = [
                    'id' => $transaction['transId'],
                    'name' => '#' . $transaction['transId'] . ' | ' . number_format($transaction['amount'], $comp_precision) . ' ' . $transaction['currency'],
                ];
            }

            $this->context->smarty->assign([
                'orderSlipChoices' => $orderSlipChoices,
                'transactionChoices' => $transactionChoices,
                'refundUrl' => $this->get('router')->generate('axepta2_admin_transaction_refund'),
            ]);

            $refundForm = $this->display(__FILE__, 'views/templates/hook/display_admin_order/refund_form.tpl');
        }

        $this->context->smarty->assign([
            'transaction_refund_form' => isset($refundForm) ? $refundForm : null,
            'transactions' => $transactions,
            'formatted_transactions' => $orderTransactionsFormatted,
            'logo_path' => Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/BNP/logo.png'),
            'moduleDir' => _MODULE_DIR_ . $this->name . '/',
            'code_success' => Axepta2Transaction::SUCCESS_CODE,
            'currentUrl' => $this->context->link->getAdminLink('AdminOrders', true, ['id_order' => $order->id]),
            'reversalUrl' => $this->get('router')->generate('axepta2_admin_transaction_reversal'),
        ]);

        return $this->display(__FILE__, 'views/templates/hook/display_admin_order/order_transactions.tpl');
    }

    public function hookDisplayPaymentByBinaries()
    {
        return $this->fetch('module:axepta2/views/templates/hook/display_payment_by_binaries/iframe.tpl');
    }

    public function hookPaymentOptions($params)
    {
        try {
            $paymentOptions = [];

            $axepta2ConfigurationAccountRepository = $this->get('axepta2.repository.configuration_account');

            /** @var Axepta2ConfigurationAccount|null $account */
            $account = $axepta2ConfigurationAccountRepository->getCurrentConfiguration();

            if (!$account) {
                Logger::critical('No account found');

                return $paymentOptions;
            }

            $configurationPaymentMethods = $account->getConfigurationPaymentMethods();

            if (empty($configurationPaymentMethods)) {
                Logger::info('No configuration payment methods');

                return $paymentOptions;
            }

            $paymentMethods = [];
            $paymentOption = new PaymentOption();
            $paymentOption->setModuleName($this->name);
            $paymentOption->setLogo($this->_path . 'logo.gif');
            $paymentOption->setCallToActionText(\Configuration::get(
                'AXEPTA2_FRONT_LABEL_' . $account->getId(),
                $this->context->language->id,
                null,
                $this->context->shop->id,
                $this->trans('Secure payment with', [], 'Modules.Axepta2.Checkout')
            ));
            $paymentOption->setAction($this->context->link->getModuleLink($this->name, 'redirect', [], true));

            // GROUPED
            if ($account->getPaymentMethodOrganization() == Axepta2ConfigurationAccount::PAYMENT_METHOD_ORGANIZATION_GROUPED) {
                $paymentOption->setBinary(true);

                $paymentOption->setInputs([
                    'payment_method_organization' => [
                        'name' => 'axepta2_payment_method_organization',
                        'type' => 'hidden',
                        'value' => Axepta2ConfigurationAccount::PAYMENT_METHOD_ORGANIZATION_GROUPED,
                    ],
                    'payment_method_id' => [
                        'name' => 'axepta2_payment_method_id',
                        'type' => 'hidden',
                        'value' => 0,
                    ],
                ]);

                foreach ($configurationPaymentMethods as $configurationPaymentMethod) {
                    if (!$configurationPaymentMethod->isActive()) {
                        continue;
                    }

                    $paymentMethod = $configurationPaymentMethod->getPaymentMethod();
                    $paymentMethodConfig = $paymentMethod->getConfig();

                    // Check if paymentMethod is compatible with the currency || the country || the FO
                    // if (
                    //     !Utils::isPaymentMethodAvailableForCurrency($cart->id_currency, $paymentMethodConfig)
                    //     || !Utils::isPaymentMethodAvailableForCountry($cart->id_address_invoice, $paymentMethodConfig)
                    //     || !Utils::isPaymentMethodAvailableForFrontOffice($paymentMethodConfig)
                    //     || !Utils::isPaymentMethodAvailableForBackOffice($paymentMethodConfig)
                    // ) {
                    //     continue;
                    // }

                    if (isset($paymentMethodConfig['payment_methods'])) {
                        foreach ($paymentMethodConfig['payment_methods'] as $pm) {
                            $trigram = $paymentMethod->getTrigram();
                            if ($trigram == 'cvm' && 'FR' != $this->context->country->iso_code) {
                                $trigram = 'vim';

                                if ($pm['name'] == 'CB') {
                                    continue;
                                }
                            }
                            $paymentMethods[$paymentMethod->getGroupId()][] = [
                                'logo' => Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/PM/' . $pm['logo']),
                                'name' => $pm['name'],
                                'id' => $paymentMethod->getId(),
                                'trigram' => $trigram,
                                'position' => $paymentMethod->getPosition(),
                            ];
                        }
                    } else {
                        $paymentMethods[$paymentMethod->getGroupId()][] = [
                            'logo' => Media::getMediaPath(_PS_MODULE_DIR_ . $this->name . '/views/img/PM/' . $paymentMethodConfig['logo_img']),
                            'name' => $paymentMethod->getName(),
                            'id' => $paymentMethod->getId(),
                            'trigram' => $paymentMethod->getTrigram(),
                            'position' => $paymentMethod->getPosition(),
                        ];
                    }
                }

                if (empty($paymentMethods)) {
                    Logger::info('No active payment methods');

                    return $paymentOptions;
                }

                // Trier les sous-tableaux par la clé 'position'
                foreach ($paymentMethods as &$methods) {
                    usort($methods, function ($a, $b) {
                        return $a['position'] <=> $b['position'];
                    });
                }
                unset($methods); // bonne pratique pour éviter les effets de référence

                $this->context->smarty->assign([
                    'paymentMethods' => $paymentMethods,
                ]);

                $paymentOption->setAdditionalInformation($this->context->smarty->fetch($this->local_path . 'views/templates/hook/payment_options/hosted.tpl'));

                // IFRAME
                if ($account->getDisplayMethod() == Axepta2ConfigurationAccount::DISPLAY_METHOD_IFRAME) {
                    $this->context->smarty->assign([
                        'use_iframe' => true,
                    ]);
                }
            }

            // HPP
            if ($account->getPaymentMethodOrganization() == Axepta2ConfigurationAccount::PAYMENT_METHOD_ORGANIZATION_HPP) {
                $paymentOption->setInputs([
                    'payment_method_organization' => [
                        'name' => 'axepta2_payment_method_organization',
                        'type' => 'hidden',
                        'value' => Axepta2ConfigurationAccount::PAYMENT_METHOD_ORGANIZATION_HPP,
                    ],
                ]);
            }

            $paymentOptions[] = $paymentOption;
        } catch (Throwable $e) {
            Logger::critical($e->getMessage());
        }

        return $paymentOptions;
    }

    public function isUsingNewTranslationSystem()
    {
        return true;
    }
}
