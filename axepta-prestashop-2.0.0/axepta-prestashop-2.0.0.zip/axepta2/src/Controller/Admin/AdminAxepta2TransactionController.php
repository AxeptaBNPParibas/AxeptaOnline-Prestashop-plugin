<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Controller\Admin;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Axepta2\Entity\Axepta2configurationAccount;
use Axepta2\Entity\Axepta2transaction;
use Axepta2\Exception\Axepta2Exception;
use Axepta2\Exception\ConfigurationNotFoundException;
use Axepta2\Filter\Axepta2transactionFilter;
use Axepta2\Repository\Axepta2configurationAccountRepository;
use Axepta2\Utils\Logger;
use Axepta2\Utils\Utils;
use AxeptaPaygate\Core\AxeptaPaygate;
use AxeptaPaygate\Core\OperationType;
use PrestaShopBundle\Controller\Admin\FrameworkBundleAdminController;
use Symfony\Component\HttpFoundation\RedirectResponse;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Generator\UrlGeneratorInterface;

class AdminAxepta2transactionController extends FrameworkBundleAdminController
{
    public function listAction(Request $request): Response
    {
        /** @var Axepta2configurationAccountRepository $repository */
        $repository = $this->getDoctrine()->getRepository(Axepta2configurationAccount::class);

        /** @var Axepta2configurationAccount|null $account */
        $account = $repository->getCurrentConfiguration();

        $gridFactory = $this->get('axepta2.transaction.grid.factory');
        $filters = Axepta2transactionFilter::fromRequest($request);

        if ($account && $account->isDemoModeOn()) {
            $filters->addFilter([
                'demo_mode' => true,
            ]);
        }
        $grid = $gridFactory->getGrid($filters);

        return $this->render(
            '@Modules/axepta2/views/templates/admin/transaction/list.html.twig',
            [
                'enableSidebar' => true,
                'layoutTitle' => $this->trans('Transactions', 'Modules.Payxpert.Transaction'),
                'grid' => $this->presentGrid($grid),
                'isDemoMode' => !is_null($account) ? $account->isDemoModeOn() : false,
            ]
        );
    }

    /**
     * Capture une transaction via Axepta Paygate
     *
     * @param Request $request
     * @param string $transactionId
     *
     * @return RedirectResponse
     */
    public function captureAction(Request $request, string $transactionId)
    {
        $redirectUrl = $this->generateUrl('axepta2_admin_transaction_list');

        $transactionRepository = $this->get('axepta2.repository.transaction');

        /** @var Axepta2transaction|null $transaction */
        $transaction = $transactionRepository->find($transactionId);

        if (!$transaction) {
            $this->addFlash('error', $this->trans('Transaction not found', 'Modules.Axepta2.Transaction'));

            return $this->redirect($redirectUrl);
        }

        // Redirect to the Admin Order page when capture is initiated from there
        if ($request->request->get('redirect_to_admin_order')) {
            $redirectUrl = $this->get('router')->generate(
                'admin_orders_view',
                ['orderId' => $transaction->getOrderId()],
                UrlGeneratorInterface::ABSOLUTE_URL
            );
        }

        if ($transaction->getResponseCode() !== Axepta2transaction::SUCCESS_CODE) {
            $this->addFlash('error', $this->trans('Only successful transactions can be captured', 'Modules.Axepta2.Transaction'));

            return $this->redirect($redirectUrl);
        }

        try {
            // Récupérer la configuration liée
            $configurationRepository = $this->get('axepta2.repository.configuration_account');
            $configuration = $configurationRepository->find($transaction->getIdConfigurationAccount());

            if (!$configuration) {
                throw new ConfigurationNotFoundException();
            }

            $order = new \Order($transaction->getOrderId());
            $cart = new \Cart($order->id_cart);
            $repositoryIC = $this->get('axepta2.repository.iso_country');

            $params = Utils::buildAxeptaParams(
                $transaction->getTrigram() ?? Utils::getTrigramPerMeanType($transaction->getPaymentMeanType()),
                OperationType::CAPTURE_PAYMENT,
                $cart,
                $configuration,
                $this->getContext(),
                $repositoryIC
            );

            $params['args']['paymentId'] = $transaction->getPayId();

            // Envoi de la requête
            AxeptaPaygate::init($params['args']);
            $operation = AxeptaPaygate::buildOperation();
            $paramToLog = $operation['params'];
            Axepta2transaction::anonymizeRecursive($paramToLog);
            Logger::info(json_encode($paramToLog));

            $requestApi = $operation['request'];
            $response = $requestApi->call();
            $responseArray = json_decode($response, true);

            // Create capture Transaction
            $captureTransaction = clone $transaction;

            // Réinitialiser ou modifier les champs spécifiques
            $captureTransaction->setId(null);
            $captureTransaction->setTransId(Utils::generateTransactionReference($order->reference));
            $captureTransaction->setStatus('CAPTURED');
            $captureTransaction->setTransactionType(OperationType::CAPTURE_PAYMENT);
            $captureTransaction->setResponseCode($responseArray['responseCode']);
            $captureTransaction->setDescription('Capture of transaction ' . $transaction->getTransId());
            $captureTransaction->setCreatedAt(new \DateTime());
            $captureTransaction->setUpdatedAt(new \DateTime());
            $captureTransaction->setTransactionReferralId($transaction->getTransId());
            $captureTransaction->setNeedCapture(false);

            $em = $this->get('doctrine.orm.entity_manager');
            $em->persist($captureTransaction);
            $em->flush();

            if ($responseArray['responseCode'] != Axepta2transaction::SUCCESS_CODE) {
                throw new Axepta2Exception(sprintf('[%s][%s] %s', $responseArray['responseCode'], $responseArray['status'], $responseArray['responseDescription']));
            }

            // Mettre à jour la transaction
            $transaction->setNeedCapture(false);
            $transaction->setUpdatedAt(new \DateTime());

            $em->persist($transaction);
            $em->flush();

            $orderStatus = Utils::getOrderStatus($configuration, true, false);
            $history = new \OrderHistory();
            $history->id_order = $order->id;
            $context = $this->get('prestashop.adapter.legacy.context')->getContext();
            $history->id_employee = (int) $context->employee->id;
            $history->changeIdOrderState($orderStatus, $order->id, true);
            $history->addWithemail();

            $this->addFlash('success', $this->trans('Transaction captured successfully', 'Modules.Axepta2.Transaction'));
        } catch (\Exception $e) {
            Logger::critical($e->getMessage());
            $this->addFlash('error', $this->trans('Error capturing transaction: %message%', 'Modules.Axepta2.Transaction', ['%message%' => $e->getMessage()]));
        }

        return $this->redirect($redirectUrl);
    }

    public function refundAction(Request $request)
    {
        try {
            $redirectUrl = $this->generateUrl('axepta2_admin_transaction_list');
            $transactionRepository = $this->get('axepta2.repository.transaction');
            $entityManager = $this->get('doctrine.orm.entity_manager');

            $transactionId = $request->request->get('transaction_id');
            $orderSlipId = $request->request->get('order_slip_id');

            /** @var Axepta2transaction|null $transaction */
            $transaction = $transactionRepository->findOneByTransId($transactionId);

            if (!$transaction) {
                $this->addFlash('error', $this->trans('Transaction not found', 'Modules.Axepta2.Transaction'));

                return $this->redirect($redirectUrl);
            }

            $orderSlip = new \OrderSlip($orderSlipId);
            if (!\Validate::isLoadedObject($orderSlip)) {
                throw new \Exception($this->trans('Order Slip not found.', 'Modules.Axepta2.Transaction'));
            }

            // Redirect to the Admin Order page when capture is initiated from there
            if ($request->request->get('redirect_to_admin_order')) {
                $redirectUrl = $this->get('router')->generate(
                    'admin_orders_view',
                    ['orderId' => $transaction->getOrderId()],
                    UrlGeneratorInterface::ABSOLUTE_URL
                );
            }

            // Vérifie si la transaction est remboursable
            if ($transaction->getStatus() == Axepta2transaction::STATUS_REFUNDED
                || $transaction->getStatus() === Axepta2transaction::STATUS_REVERSED
                || $transaction->getNeedCapture() // capture pending
                || $transaction->getResponseCode() != Axepta2transaction::SUCCESS_CODE
            ) {
                $this->addFlash('error', $this->trans('This transaction cannot be refunded', 'Modules.Axepta2.Transaction'));

                return $this->redirect($redirectUrl);
            }

            // Initialise Axepta Paygate pour effectuer le remboursement
            $configurationRepository = $this->get('axepta2.repository.configuration_account');
            $configuration = $configurationRepository->getCurrentConfiguration();

            $orderSlipAmount = (int) \Tools::ps_round($orderSlip->amount * 100, 0, PS_ROUND_UP);
            $transactionAmount = (int) \Tools::ps_round($transaction->getAmount() * 100);
            $transactionsLinked = $transactionRepository->findBy([
                'transactionReferralId' => $transaction->getTransId(),
                'status' => 'REFUNDED',
                'responseCode' => Axepta2transaction::SUCCESS_CODE,
            ]);

            $amountAlreadyRefunded = 0;
            if ($transactionsLinked) {
                $amountAlreadyRefunded = array_sum(array_map(function ($t) {
                    return (int) ($t->getAmount() * 100);
                }, $transactionsLinked));
            }
            $refundableAmount = $transactionAmount - $amountAlreadyRefunded;
            $amountToRefund = min($orderSlipAmount, $refundableAmount);

            $order = new \Order($transaction->getOrderId());
            $cart = new \Cart($order->id_cart);
            $transId = Utils::generateTransactionReference($order->reference);

            $repositoryIC = $this->get('axepta2.repository.iso_country');
            $context = $this->get('prestashop.adapter.legacy.context')->getContext();

            $params = Utils::buildAxeptaParams(
                $transaction->getTrigram() ?? Utils::getTrigramPerMeanType($transaction->getPaymentMeanType()),
                OperationType::PAYMENT_REFUND,
                $cart,
                $configuration,
                $context,
                $repositoryIC
            );

            $params['args']['paymentId'] = $transaction->getPayId();
            $params['args']['amount.value'] = (int) $amountToRefund;

            AxeptaPaygate::init($params['args']);

            $operation = AxeptaPaygate::buildOperation();
            $paramToLog = $operation['params'];
            Axepta2transaction::anonymizeRecursive($paramToLog);
            Logger::info(json_encode($paramToLog));

            $requestCall = $operation['request'];
            $response = $requestCall->call();
            $responseArray = json_decode($response, true);

            // Crée une nouvelle transaction REFUND
            $refundTransaction = clone $transaction;
            $refundTransaction->setId(null); // nouvel ID auto-incrémenté
            $refundTransaction->setTransId($transId);
            $refundTransaction->setXid($responseArray['xId']);
            $refundTransaction->setAmount((float) ($amountToRefund / 100));
            $refundTransaction->setTransactionType(OperationType::PAYMENT_REFUND);
            $refundTransaction->setStatus(Axepta2transaction::STATUS_REFUNDED);
            $refundTransaction->setResponseCode($responseArray['responseCode']);
            $refundTransaction->setDescription($responseArray['responseDescription']);
            $refundTransaction->setCreatedAt(new \DateTime());
            $refundTransaction->setUpdatedAt(new \DateTime());
            $refundTransaction->setTransactionReferralId($transaction->getTransId());
            $refundTransaction->setOrderSlipId($orderSlipId);

            $entityManager->persist($refundTransaction);
            $entityManager->flush();

            if (($responseArray['responseCode'] ?? null) != Axepta2transaction::SUCCESS_CODE) {
                $this->addFlash('error', $this->trans(
                    sprintf('[%s] %s', $responseArray['responseCode'] ?? 'ERR', $responseArray['responseDescription'] ?? ''),
                    'Modules.Axepta2.Transaction'
                ));

                return $this->redirect($redirectUrl);
            }

            // TODO : better and what if multiple transaction
            $history = new \OrderHistory();
            $history->id_order = $order->id;
            $history->id_employee = (int) $context->employee->id;
            $history->changeIdOrderState(_PS_OS_REFUND_, $order->id, true);
            $history->addWithemail();

            $this->addFlash('success', $this->trans('Transaction successfully refunded', 'Modules.Axepta2.Transaction'));

            return $this->redirect($redirectUrl);
        } catch (\Exception $e) {
            $this->addFlash('error', $e->getMessage());

            return $this->redirect($redirectUrl);
        }
    }

    public function reversalAction(Request $request): Response
    {
        $redirectUrl = $this->generateUrl('axepta2_admin_transaction_list');
        $transactionRepository = $this->get('axepta2.repository.transaction');

        $transactionId = $request->request->get('transaction_id');
        if (!$transactionId) {
            $this->addFlash('error', $this->trans('Missing transaction ID.', 'Modules.Axepta2.Transaction'));

            return $this->redirect($redirectUrl);
        }

        /** @var Axepta2transaction|null $transaction */
        $transaction = $transactionRepository->find($transactionId);
        if (!$transaction) {
            $this->addFlash('error', $this->trans('Transaction not found.', 'Modules.Axepta2.Transaction'));

            return $this->redirect($redirectUrl);
        }

        if ($request->request->get('redirect_to_admin_order')) {
            $redirectUrl = $this->generateUrl(
                'admin_orders_view',
                ['orderId' => $transaction->getOrderId()],
                UrlGeneratorInterface::ABSOLUTE_URL
            );
        }

        // Vérifier si la transaction est annulable
        if (!$transaction->getNeedCapture() || $transaction->getStatus() != Axepta2transaction::STATUS_AUTHORIZED) {
            $this->addFlash('error', $this->trans('This transaction cannot be reversed.', 'Modules.Axepta2.Transaction'));

            return $this->redirect($redirectUrl);
        }

        try {
            // Initialise Axepta Paygate pour effectuer le remboursement
            $configurationRepository = $this->get('axepta2.repository.configuration_account');
            $configuration = $configurationRepository->getCurrentConfiguration();

            // Init Axepta Paygate pour Reversal
            $order = new \Order($transaction->getOrderId());
            $cart = new \Cart($order->id_cart);
            $transId = Utils::generateTransactionReference($order->reference);
            $repositoryIC = $this->get('axepta2.repository.iso_country');
            $context = $this->get('prestashop.adapter.legacy.context')->getContext();

            $params = Utils::buildAxeptaParams(
                $transaction->getTrigram() ?? Utils::getTrigramPerMeanType($transaction->getPaymentMeanType()),
                OperationType::PAYMENT_REVERSAL,
                $cart,
                $configuration,
                $context,
                $repositoryIC
            );

            $params['args']['paymentId'] = $transaction->getPayId();

            // Envoi de la requête
            AxeptaPaygate::init($params['args']);
            $operation = AxeptaPaygate::buildOperation();
            $paramToLog = $operation['params'];
            Axepta2transaction::anonymizeRecursive($paramToLog);
            Logger::info(json_encode($paramToLog));

            $requestApi = $operation['request'];
            $response = $requestApi->call();
            $responseArray = json_decode($response, true);

            // Gestion d'erreur côté Axepta
            if ($responseArray['responseCode'] != Axepta2transaction::SUCCESS_CODE) {
                throw new Axepta2Exception(sprintf('[%s][%s] %s', $responseArray['responseCode'], $responseArray['status'], $responseArray['responseDescription']));
            }

            // Créer la nouvelle transaction de reversal
            $reversal = clone $transaction;
            $reversal->setId(null);
            $reversal->setTransId($transId);
            $reversal->setXid($responseArray['xId']);
            $reversal->setTransactionReferralId($transaction->getTransId());
            $reversal->setAmount(null);
            $reversal->setTransactionType(OperationType::PAYMENT_REVERSAL);
            $reversal->setStatus(Axepta2transaction::STATUS_REVERSED);
            $reversal->setResponseCode($responseArray['responseCode']);
            $reversal->setDescription($responseArray['responseDescription']);
            $reversal->setCreatedAt(new \DateTime());
            $reversal->setUpdatedAt(new \DateTime());

            $transaction->setNeedCapture(false);

            // Sauvegarde
            $em = $this->get('doctrine.orm.entity_manager');
            $em->persist($transaction);
            $em->persist($reversal);
            $em->flush();

            // TODO : better and what if multiple transaction
            $history = new \OrderHistory();
            $history->id_order = $order->id;
            $history->id_employee = (int) $context->employee->id;
            $history->changeIdOrderState(_PS_OS_CANCELED_, $order->id, true);
            $history->addWithemail();

            $this->addFlash('success', $this->trans('The transaction has been successfully reversed.', 'Modules.Axepta2.Transaction'));
        } catch (Axepta2Exception $e) {
            Logger::critical($e->getMessage());
            $this->addFlash('error', sprintf('%s: %s', $this->trans('Axepta error', 'Modules.Axepta2.Transaction'), $e->getMessage()));
        } catch (\Exception $e) {
            Logger::critical($e->getMessage());
            $this->addFlash('error', sprintf('%s: %s', $this->trans('Unexpected error', 'Modules.Axepta2.Transaction'), $e->getMessage()));
        }

        return $this->redirect($redirectUrl);
    }
}
