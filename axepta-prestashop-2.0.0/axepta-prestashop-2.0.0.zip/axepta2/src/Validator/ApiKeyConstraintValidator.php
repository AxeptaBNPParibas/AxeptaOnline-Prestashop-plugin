<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Validator;

if (!defined('_PS_VERSION_')) {
    exit;
}

require_once __DIR__ . '/../../vendor/axepta-paygate/lib/init.php';

use Axepta2\Entity\Axepta2ConfigurationAccount;
use Axepta2\Repository\Axepta2ConfigurationAccountRepository;
use Axepta2\Utils\Logger;
use Axepta2\Utils\Utils;
use AxeptaPaygate\Core\PaymentMode;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\Validator\Constraint;
use Symfony\Component\Validator\ConstraintValidator;
use Symfony\Component\Validator\Exception\UnexpectedTypeException;

class ApiKeyConstraintValidator extends ConstraintValidator
{
    private $repository;

    public function __construct(EntityManagerInterface $em)
    {
        /** @var Axepta2ConfigurationAccountRepository $repository */
        $repository = $em->getRepository(Axepta2ConfigurationAccount::class);
        $this->repository = $repository;
    }

    public function validate($value, Constraint $constraint)
    {
        if (!$constraint instanceof ApiKeyConstraint) {
            throw new UnexpectedTypeException($constraint, ApiKeyConstraint::class);
        }

        if (!is_array($value) || !isset($value['mode'])) {
            throw new \UnexpectedValueException('Expected array with mode.');
        }

        try {
            list($publicKey, $privateKey, $paymentMode) = $this->resolveKeysAndMode($value);
            Utils::getAccessToken($publicKey, $privateKey, $paymentMode);
        } catch (\Throwable $e) {
            Logger::critical($e->getMessage());
            $this->context
                ->buildViolation($constraint->message)
                ->setTranslationDomain('Modules.Axepta2.Validator')
                ->addViolation();
        }
    }

    /**
     * @param array $value
     *
     * @return array [$publicKey, $privateKey, $paymentMode]
     */
    private function resolveKeysAndMode(array $value): array
    {
        switch ($value['mode']) {
            case Axepta2ConfigurationAccount::MODE_PRODUCTION:
                $account = $this->repository->getCurrentConfiguration();

                $publicKey = $value['public_key_prod'] ?? $account->getPublicKeyProd();
                $privateKey = $value['private_key_prod'] ?? $account->getPrivateKeyProd();

                $this->assertKeysExist([
                    'public_key_prod' => $publicKey,
                    'private_key_prod' => $privateKey,
                ], ['public_key_prod', 'private_key_prod']);

                return [$publicKey, $privateKey, PaymentMode::PRODUCTION];

            case Axepta2ConfigurationAccount::MODE_TEST:
                $account = $this->repository->getCurrentConfiguration();

                $publicKey = $value['public_key_test'] ?? $account->getPublicKeyTest();
                $privateKey = $value['private_key_test'] ?? $account->getPrivateKeyTest();

                $this->assertKeysExist([
                    'public_key_test' => $publicKey,
                    'private_key_test' => $privateKey,
                ], ['public_key_test', 'private_key_test']);

                return [$publicKey, $privateKey, PaymentMode::TEST];

            case Axepta2ConfigurationAccount::MODE_DEMO:
                $publicKey = \Configuration::getGlobalValue('AXEPTA2_DEMO_PUBLICKEY') ?: 'TODO';
                $privateKey = \Configuration::getGlobalValue('AXEPTA2_DEMO_PRIVATEKEY') ?: 'TODO';

                return [$publicKey, $privateKey, PaymentMode::DEMO];

            default:
                throw new \UnexpectedValueException(sprintf('Unknown mode: %s', $value['mode']));
        }
    }

    private function assertKeysExist(array $value, array $requiredKeys): void
    {
        foreach ($requiredKeys as $key) {
            if (!isset($value[$key]) || (is_string($value[$key]) && $value[$key] === '')) {
                throw new \UnexpectedValueException(sprintf('Missing required key: %s', $key));
            }
        }
    }
}
