<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Utils;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Axepta2\Exception\CurlException;
use Configuration;
use PrestaShopBundle\Entity\Repository\TabRepository;
use PrestaShopBundle\Install\SqlLoader;

/**
 * Class Installer.
 */
class Installer
{
    private $module;

    /** @var TabRepository */
    private $tabRepository;

    /**
     * Installer constructor.
     */
    public function __construct($module, TabRepository $tabRepository)
    {
        $this->module = $module;
        $this->tabRepository = $tabRepository;
    }

    /**
     * @return void
     *
     * @throws \PrestaShopDatabaseException
     * @throws \PrestaShopException
     * @throws \Exception
     */
    public function run()
    {
        $this->checkTechnicalRequirements();
        $this->initConfigurationVars();
        $this->installSpecificTranslations();
        $this->installTabs();
        $this->installDb();
        $this->registerHooks();
        $this->installOrderState();
    }

    /**
     * @return void
     */
    private function checkTechnicalRequirements()
    {
        // @formatter:off
        if (false == extension_loaded('curl')) {
            throw new CurlException();
        }
        // @formatter:on

        Logger::info('OK');
    }

    /**
     * @return void
     */
    private function initConfigurationVars()
    {
        \Configuration::updateGlobalValue('AXEPTA2_DEMO_PUBLICKEY', 'BNP_AXE_STD_DEMO');
        \Configuration::updateGlobalValue('AXEPTA2_DEMO_PRIVATEKEY', 'a831e0b6-1342-4449-b030-1126dc1afc4d');
        \Configuration::updateGlobalValue('AXEPTA2_SUPPORT_EMAIL', 'assistance.ecommerce@bnpparibas.com');

        Logger::info('OK');
    }

    private function installSpecificTranslations()
    {
        $this->module->getTranslator()->trans('Card', [], 'Modules.Axepta2.Account');

        Logger::info('OK');
    }

    public function installTabs()
    {
        $moduleTabs = $this->module->getModuleTabs();

        foreach ($moduleTabs as $moduleTab) {
            if ($this->tabRepository->findOneIdByClassName($moduleTab['class_name'])) {
                Logger::info($moduleTab['class_name'] . ' already installed');

                continue;
            }

            $tab = new \Tab();
            $tab->active = true;
            $tab->class_name = $moduleTab['class_name'];
            $tab->id_parent = (int) \Tab::getIdFromClassName($moduleTab['parent_class_name']);
            $tab->module = $this->module->name;

            $tab->name = [];
            foreach (\Language::getLanguages(false) as $lang) {
                $isoCode = $lang['iso_code'];
                $tabName = $moduleTab['name'][$isoCode] = isset($moduleTab['name'][$isoCode]) ? $moduleTab['name'][$isoCode] : $moduleTab['name']['en'];
                $tab->name[$lang['id_lang']] = $tabName;
            }

            if (!$tab->add()) {
                throw new \Exception($this->module->getTranslator()->trans('Cannot add menu : %menu%', ['%menu%' => $moduleTab['class_name']], 'Modules.PayXpert.Installer'));
            }
            Logger::info($moduleTab['class_name'] . ' OK');
        }

        Logger::info('OK');
    }

    /**
     * @return void
     */
    public function uninstall()
    {
        // Delete Configuration Vars
        \Configuration::deleteByName('AXEPTA2_DEMO_PUBLICKEY');
        \Configuration::deleteByName('AXEPTA2_DEMO_PRIVATEKEY');
        \Configuration::deleteByName('AXEPTA2_SUPPORT_EMAIL');

        // Delete Tabs
        $moduleTabs = \Tab::getCollectionFromModule($this->module->name);
        foreach ($moduleTabs as $moduleTab) {
            $moduleTab->delete();
        }

        // Dev only
        \Db::getInstance()->execute('DROP TABLE IF EXISTS ' . _DB_PREFIX_ . 'axepta2payment_method_lang');
        \Db::getInstance()->execute('DROP TABLE IF EXISTS ' . _DB_PREFIX_ . 'axepta2configuration_payment_method');
        \Db::getInstance()->execute('DROP TABLE IF EXISTS ' . _DB_PREFIX_ . 'axepta2payment_method');
        \Db::getInstance()->execute('DROP TABLE IF EXISTS ' . _DB_PREFIX_ . 'axepta2configuration_account_paygate');
        \Db::getInstance()->execute('DROP TABLE IF EXISTS ' . _DB_PREFIX_ . 'axepta2configuration_account');
        \Db::getInstance()->execute('DROP TABLE IF EXISTS ' . _DB_PREFIX_ . 'axepta2customer_payment_recurring');
        \Db::getInstance()->execute('DROP TABLE IF EXISTS ' . _DB_PREFIX_ . 'axepta2customer_recurring_payment_card');
        \Db::getInstance()->execute('DROP TABLE IF EXISTS ' . _DB_PREFIX_ . 'axepta2customer_oneclick_payment_card');
        \Db::getInstance()->execute('DROP TABLE IF EXISTS ' . _DB_PREFIX_ . 'axepta2iso_country');
        \Db::getInstance()->execute('DROP TABLE IF EXISTS ' . _DB_PREFIX_ . 'axepta2order_reference');
        \Db::getInstance()->execute('DROP TABLE IF EXISTS ' . _DB_PREFIX_ . 'axepta2payment_recurring');
        \Db::getInstance()->execute('DROP TABLE IF EXISTS ' . _DB_PREFIX_ . 'axepta2transaction');
        \Db::getInstance()->execute('DROP TABLE IF EXISTS ' . _DB_PREFIX_ . 'axepta2subscription');

        Logger::info('OK');
    }

    public function registerHooks()
    {
        $hooks = $this->module->hooks;

        foreach ($hooks as $hook) {
            if (!$this->module->registerHook($hook)) {
                throw new \Exception($hook);
            }
            Logger::info($hook);
        }

        Logger::info('OK');
    }

    /**
     * @return void
     */
    public function installDb()
    {
        $sqlLoader = new SqlLoader();
        $sqlLoader->setMetaData([
            '_DB_PREFIX_' => _DB_PREFIX_,
        ]);
        $result = $sqlLoader->parseFile($this->module->getLocalPath() . 'sql/install.sql');

        if (!$result) {
            Logger::critical(print_r($sqlLoader->getErrors(), true));

            throw new \Exception('Error occured while installing Database');
        }
        Logger::info('OK');
    }

    public function installOrderState()
    {
        $orderStates = [
            // Production
            [
                'unremovable' => true,
                'name' => [
                    \LanguageCore::getIdByIso('en') => 'Axepta - Waiting for manual capture',
                    \LanguageCore::getIdByIso('fr') => 'Axepta - En attente de capture manuelle',
                ],
                'color' => '#3498db',
                'send_email' => false,
                'invoice' => false,
                'logable' => true,
                'shipped' => false,
                'paid' => false,
                'hidden' => false,
                'delivery' => false,
                'deleted' => false,
                'module_name' => $this->module->name,
                'configurationValue' => 'OS_AXEPTA2_WAITING_MANUAL_CAPTURE',
            ],
            [
                'unremovable' => true,
                'name' => [
                    \LanguageCore::getIdByIso('en') => 'Axepta - Payment incomplete',
                    \LanguageCore::getIdByIso('fr') => 'Axepta - Paiement incomplet',
                ],
                'color' => '#f39c12',
                'send_email' => false,
                'invoice' => false,
                'logable' => true,
                'shipped' => false,
                'paid' => false,
                'hidden' => false,
                'delivery' => false,
                'deleted' => false,
                'module_name' => $this->module->name,
                'configurationValue' => 'OS_AXEPTA2_PAYMENT_INCOMPLETE',
            ],
            [
                'unremovable' => true,
                'name' => [
                    \LanguageCore::getIdByIso('en') => 'Axepta - Payment error',
                    \LanguageCore::getIdByIso('fr') => 'Axepta - Erreur de paiement',
                ],
                'color' => '#e74c3c',
                'send_email' => false,
                'invoice' => false,
                'logable' => true,
                'shipped' => false,
                'paid' => false,
                'hidden' => false,
                'delivery' => false,
                'deleted' => false,
                'module_name' => $this->module->name,
                'configurationValue' => 'OS_AXEPTA2_PAYMENT_ERROR',
            ],
            [
                'unremovable' => true,
                'name' => [
                    \LanguageCore::getIdByIso('en') => 'Axepta - Payment in multiple installments',
                    \LanguageCore::getIdByIso('fr') => 'Axepta - Paiement en plusieurs fois',
                ],
                'color' => '#9b59b6',
                'send_email' => false,
                'invoice' => true,
                'logable' => false,
                'shipped' => false,
                'paid' => false,
                'hidden' => false,
                'delivery' => false,
                'deleted' => false,
                'module_name' => $this->module->name,
                'configurationValue' => 'OS_AXEPTA2_PAYMENT_INSTALLMENTS',
            ],
            // Demo
            [
                'unremovable' => true,
                'name' => [
                    \LanguageCore::getIdByIso('en') => 'DEMO - Axepta - Payment accepted',
                    \LanguageCore::getIdByIso('fr') => 'DEMO - Axepta - Paiement accepté',
                ],
                'color' => '#2ecc71',
                'send_email' => false,
                'invoice' => true,
                'logable' => true,
                'shipped' => false,
                'paid' => true,
                'hidden' => false,
                'delivery' => false,
                'deleted' => false,
                'module_name' => $this->module->name,
                'configurationValue' => 'OS_AXEPTA2_PAYMENT_ACCEPTED_DEMO',
            ],
            [
                'unremovable' => true,
                'name' => [
                    \LanguageCore::getIdByIso('en') => 'DEMO - Axepta - Waiting for manual capture',
                    \LanguageCore::getIdByIso('fr') => 'DEMO - Axepta - En attente de capture manuelle',
                ],
                'color' => '#3498db',
                'send_email' => false,
                'invoice' => false,
                'logable' => true,
                'shipped' => false,
                'paid' => false,
                'hidden' => false,
                'delivery' => false,
                'deleted' => false,
                'module_name' => $this->module->name,
                'configurationValue' => 'OS_AXEPTA2_WAITING_MANUAL_CAPTURE_DEMO',
            ],
            [
                'unremovable' => true,
                'name' => [
                    \LanguageCore::getIdByIso('en') => 'DEMO - Axepta - Payment error',
                    \LanguageCore::getIdByIso('fr') => 'DEMO - Axepta - Erreur de paiement',
                ],
                'color' => '#e74c3c',
                'send_email' => false,
                'invoice' => false,
                'logable' => true,
                'shipped' => false,
                'paid' => false,
                'hidden' => false,
                'delivery' => false,
                'deleted' => false,
                'module_name' => $this->module->name,
                'configurationValue' => 'OS_AXEPTA2_PAYMENT_ERROR_DEMO',
            ],
            [
                'unremovable' => true,
                'name' => [
                    \LanguageCore::getIdByIso('en') => 'DEMO - Axepta - Payment incomplete',
                    \LanguageCore::getIdByIso('fr') => 'DEMO - Axepta - Paiement incomplet',
                ],
                'color' => '#f39c12',
                'send_email' => false,
                'invoice' => false,
                'logable' => true,
                'shipped' => false,
                'paid' => false,
                'hidden' => false,
                'delivery' => false,
                'deleted' => false,
                'module_name' => $this->module->name,
                'configurationValue' => 'OS_AXEPTA2_PAYMENT_INCOMPLETE_DEMO',
            ],
            // Test
            [
                'unremovable' => true,
                'name' => [
                    \LanguageCore::getIdByIso('en') => 'TEST - Axepta - Payment accepted',
                    \LanguageCore::getIdByIso('fr') => 'TEST - Axepta - Paiement accepté',
                ],
                'color' => '#2ecc71',
                'send_email' => false,
                'invoice' => false,
                'logable' => true,
                'shipped' => false,
                'paid' => true,
                'hidden' => false,
                'delivery' => false,
                'deleted' => false,
                'module_name' => $this->module->name,
                'configurationValue' => 'OS_AXEPTA2_PAYMENT_ACCEPTED_TEST',
            ],
            [
                'unremovable' => true,
                'name' => [
                    \LanguageCore::getIdByIso('en') => 'TEST - Axepta - Waiting for manual capture',
                    \LanguageCore::getIdByIso('fr') => 'TEST - Axepta - En attente de capture manuelle',
                ],
                'color' => '#3498db',
                'send_email' => false,
                'invoice' => false,
                'logable' => true,
                'shipped' => false,
                'paid' => false,
                'hidden' => false,
                'delivery' => false,
                'deleted' => false,
                'module_name' => $this->module->name,
                'configurationValue' => 'OS_AXEPTA2_WAITING_MANUAL_CAPTURE_TEST',
            ],
            [
                'unremovable' => true,
                'name' => [
                    \LanguageCore::getIdByIso('en') => 'TEST - Axepta - Payment error',
                    \LanguageCore::getIdByIso('fr') => 'TEST - Axepta - Erreur de paiement',
                ],
                'color' => '#e74c3c',
                'send_email' => false,
                'invoice' => false,
                'logable' => true,
                'shipped' => false,
                'paid' => false,
                'hidden' => false,
                'delivery' => false,
                'deleted' => false,
                'module_name' => $this->module->name,
                'configurationValue' => 'OS_AXEPTA2_PAYMENT_ERROR_TEST',
            ],
            [
                'unremovable' => true,
                'name' => [
                    \LanguageCore::getIdByIso('en') => 'TEST - Axepta - Payment incomplete',
                    \LanguageCore::getIdByIso('fr') => 'TEST - Axepta - Paiement incomplet',
                ],
                'color' => '#f39c12',
                'send_email' => false,
                'invoice' => false,
                'logable' => true,
                'shipped' => false,
                'paid' => false,
                'hidden' => false,
                'delivery' => false,
                'deleted' => false,
                'module_name' => $this->module->name,
                'configurationValue' => 'OS_AXEPTA2_PAYMENT_INCOMPLETE_TEST',
            ],
        ];

        foreach ($orderStates as $stateData) {
            $moduleName = $this->module->name;

            $dbQuery = new \DbQuery();
            $dbQuery->select('osl.name')
                ->from('order_state', 'os')
                ->leftJoin('order_state_lang', 'osl', 'os.id_order_state = osl.id_order_state')
                ->where('os.module_name = "' . pSQL($moduleName) . '"')
            ;
            $payxpertOrderStates = \Db::getInstance()->executeS($dbQuery);

            if (
                $payxpertOrderStates
                && array_intersect(
                    array_values($stateData['name']),
                    array_column($payxpertOrderStates, 'name')
                )
            ) {
                continue;
            }

            $orderState = new \OrderState();
            $orderState->hydrate($stateData);
            if (!$orderState->add()) {
                throw new \Exception($this->module->getTranslator()->trans('Error when trying to add OrderState : %orderstate%', ['%orderstate%' => reset($stateData['name'])], 'Modules.PayXpert.Installer'));
            }

            copy(_PS_MODULE_DIR_ . $this->module->name . '/logo.png', _PS_IMG_DIR_ . 'os/' . (int) $orderState->id . '.png');
            \Configuration::updateGlobalValue($stateData['configurationValue'], $orderState->id);
        }

        Logger::info('OK');
    }
}
