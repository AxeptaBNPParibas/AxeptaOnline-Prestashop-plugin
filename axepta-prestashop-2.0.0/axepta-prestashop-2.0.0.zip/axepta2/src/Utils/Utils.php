<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Utils;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Axepta2\Entity\Axepta2configurationAccount;
use Axepta2\Entity\Axepta2transaction;
use Axepta2\Repository\Axepta2isoCountryRepository;
use AxeptaPaygate\Core\AxeptaPaygate;
use AxeptaPaygate\Core\OperationType;
use Psr\Cache\CacheItemInterface;
use Symfony\Component\Cache\Adapter\FilesystemAdapter;

class Utils
{
    private static $cache;

    private static function getCache(): FilesystemAdapter
    {
        if (!self::$cache) {
            self::$cache = new FilesystemAdapter('axepta2', 0, _PS_ROOT_DIR_ . '/var/cache');
        }

        return self::$cache;
    }

    public static function getAccessToken(string $publicKey, string $privateKey, string $mode): string
    {
        if (empty($publicKey)) {
            throw new \Exception('Axepta2 public key is missing.');
        }

        $cacheKey = 'access_token_' . md5($publicKey);
        $cache = self::getCache();

        /** @var CacheItemInterface $item */
        $item = $cache->getItem($cacheKey);

        if (!$item->isHit()) {
            $data = AxeptaPaygate::getAccessToken($publicKey, $privateKey, $mode);

            if (!isset($data['access_token'])) {
                throw new \Exception('Axepta2: failed to retrieve access token.');
            }

            $ttl = isset($data['expires_in']) ? (int) $data['expires_in'] - 60 : 600;
            $item->set($data)->expiresAfter($ttl);
            $cache->save($item);
        } else {
            $data = $item->get();
        }

        return $data['access_token'];
    }

    public static function isUpdateAvailable()
    {
        return false; // #45263
    }

    /**
     * Retourne le statut de commande PrestaShop selon le mode Axepta2, succès du paiement et besoin de capture
     *
     * @param Axepta2configurationAccount $configuration
     * @param bool $success
     * @param bool $needCapture
     *
     * @return int
     */
    public static function getOrderStatus(Axepta2configurationAccount $configuration, bool $success, bool $needCapture)
    {
        // Mapping [mode][needCapture/success]
        $statusMap = [
            Axepta2configurationAccount::MODE_DEMO => [
                true => (int) \Configuration::get('OS_AXEPTA2_WAITING_MANUAL_CAPTURE_DEMO'),
                false => (int) \Configuration::get('OS_AXEPTA2_PAYMENT_ACCEPTED_DEMO'),
                'error' => (int) \Configuration::get('OS_AXEPTA2_PAYMENT_ERROR_DEMO'),
            ],
            Axepta2configurationAccount::MODE_TEST => [
                true => (int) \Configuration::get('OS_AXEPTA2_WAITING_MANUAL_CAPTURE_TEST'),
                false => (int) \Configuration::get('OS_AXEPTA2_PAYMENT_ACCEPTED_TEST'),
                'error' => (int) \Configuration::get('OS_AXEPTA2_PAYMENT_ERROR_TEST'),
            ],
            'default' => [ // Production
                true => (int) \Configuration::get('OS_AXEPTA2_WAITING_MANUAL_CAPTURE'),
                false => (int) \Configuration::get('PS_OS_PAYMENT'),
                'error' => (int) \Configuration::get('OS_AXEPTA2_PAYMENT_ERROR'),
            ],
        ];

        // Déterminer le mode courant
        $mode = $configuration->getMode();
        if (!in_array($mode, [Axepta2configurationAccount::MODE_DEMO, Axepta2configurationAccount::MODE_TEST], true)) {
            $mode = 'default';
        }

        // Retourner le statut correspondant
        return $success ? $statusMap[$mode][$needCapture ? true : false] : $statusMap[$mode]['error'];
    }

    /**
     * Génère les paramètres pour AxeptaPaygate::init()
     *
     * @param string|null $trigram
     * @param string $operationType
     * @param \Cart|null $cart
     * @param Axepta2configurationAccount $configuration
     * @param \Context|null $context
     * @param Axepta2isoCountryRepository $isoCountryRepository
     *
     * @return array
     */
    public static function buildAxeptaParams($trigram, $operationType, $cart, $configuration, $context, $isoCountryRepository): array
    {
        $customer = new \Customer((int) $cart->id_customer);
        $currency = new \Currency((int) $cart->id_currency);

        $addrDelivery = new \Address((int) $cart->id_address_delivery);
        $addrInvoice = new \Address((int) $cart->id_address_invoice);

        $isoCountryInvoice = $isoCountryRepository->find($addrInvoice->id_country);
        $isoCountryDelivery = $isoCountryRepository->find($addrDelivery->id_country);

        $invoicePhone = !empty($addrInvoice->phone) ? $addrInvoice->phone : $addrInvoice->phone_mobile;
        $deliveryPhone = !empty($addrDelivery->phone) ? $addrDelivery->phone : $addrDelivery->phone_mobile;

        $renderPaymentRendering = !in_array($operationType, [OperationType::PAYMENT_REFUND, OperationType::PAYMENT_REVERSAL, OperationType::CAPTURE_PAYMENT]);

        list($prefilledConfiguration, $missingKeys) = AxeptaPaygate::getRequiredConfigurationKeys(
            $trigram,
            $operationType,
            $renderPaymentRendering ? $configuration->getPaymentMethodOrganizationMap() : null
        );

        $token = self::getAccessToken(
            $configuration->getPublicKey(),
            $configuration->getPrivateKey(),
            $configuration->getModeMap()
        );

        $orderReference = \OrderCore::generateReference();

        // Mandatory params
        $params = [
            'trigram' => $trigram,
            'operationType' => $operationType,
        ];

        if ($renderPaymentRendering) {
            $params['paymentRenderingMode'] = $configuration->getPaymentMethodOrganizationMap();
        }

        foreach ($missingKeys as $missingKey) {
            switch ($missingKey) {
                // === Montant et devise ===
                case 'amount.value':
                    $params[$missingKey] = (int) \Tools::ps_round($cart->getOrderTotal() * 100);

                    break;

                case 'amount.currency':
                    $params[$missingKey] = $currency->iso_code;

                    break;

                case 'api_access_token':
                    $params[$missingKey] = $token;

                    break;

                    // === Billing ===
                case 'billingAddress.city':
                    $params[$missingKey] = $addrInvoice->city;

                    break;

                case 'billingAddress.country':
                    $params[$missingKey] = $isoCountryInvoice->getIsoCode3();

                    break;

                case 'billingAddress.postalCode':
                    $params[$missingKey] = $addrInvoice->postcode;

                    break;

                case 'billingAddress.streetName':
                    $params[$missingKey] = $addrInvoice->address1;

                    break;

                case 'billingAddress.streetNumber':
                    $params[$missingKey] = $addrInvoice->address2 ?: '';

                    break;

                case 'billing.contactInfo.email':
                    $params[$missingKey] = $customer->email;

                    break;

                case 'billing.contactInfo.phone':
                    $params[$missingKey] = $invoicePhone;

                    break;

                    // === Cart / Order info ===
                case 'cartId':
                    $params[$missingKey] = $cart->id;

                    break;

                case 'captureMethod':
                    $params[$missingKey] = $configuration->getCaptureModeMap();

                    break;

                case 'customerInfo.firstName':
                    $params[$missingKey] = $customer->firstname;

                    break;

                case 'customerInfo.lastName':
                    $params[$missingKey] = $customer->lastname;

                    break;

                case 'customerInfo.customerId':
                    $params[$missingKey] = (string) $customer->id;

                    break;

                case 'externalIntegrationId':
                    $params[$missingKey] = self::getModuleVersionTag('axepta2');

                    break;

                case 'language':
                    $params[$missingKey] = $context->language->iso_code;

                    break;

                case 'operationType':
                    $params[$missingKey] = $operationType;

                    break;

                case 'orderId':
                    $params[$missingKey] = $cart->id;

                    break;

                case 'orderReference':
                    $params[$missingKey] = $orderReference;

                    break;

                    // === Mode et affichage ===
                case 'paymentMode':
                    $params[$missingKey] = $configuration->getModeMap();

                    break;

                    // === Shipping ===
                case 'shipping.address.city':
                    $params[$missingKey] = $addrDelivery->city;

                    break;

                case 'shipping.address.country':
                    $params[$missingKey] = $isoCountryDelivery->getIsoCode3();

                    break;

                case 'shipping.address.postalCode':
                    $params[$missingKey] = $addrDelivery->postcode;

                    break;

                case 'shipping.address.streetName':
                    $params[$missingKey] = $addrDelivery->address1;

                    break;

                case 'shipping.address.streetNumber':
                    $params[$missingKey] = $addrDelivery->address2 ?: '';

                    break;

                case 'shipping.consumer.firstName':
                    $params[$missingKey] = $customer->firstname;

                    break;

                case 'shipping.consumer.lastName':
                    $params[$missingKey] = $customer->lastname;

                    break;

                case 'shipping.contactInfo.email':
                    $params[$missingKey] = $customer->email;

                    break;

                case 'shipping.contactInfo.phone':
                    $params[$missingKey] = $deliveryPhone;

                    break;

                    // === Infos boutique ===
                case 'shopName':
                case 'statementDescriptor':
                    $params[$missingKey] = \Configuration::get('PS_SHOP_NAME');

                    break;

                    // === URLs et identifiants ===
                case 'transId':
                    $params[$missingKey] = self::generateTransactionReference($orderReference);

                    break;

                case 'urlCancel':
                    $params[$missingKey] = $context->link->getPageLink('order', true, null, ['step' => 3]);

                    break;

                case 'urlWebhook':
                    $params[$missingKey] = $context->link->getModuleLink('axepta2', 'webhook', [], true);

                    break;

                case 'urlReturn':
                    $params[$missingKey] = $context->link->getModuleLink('axepta2', 'validation', [], true);

                    break;

                default:
                    // En cas de champ non mappé, on le laisse vide pour debug
                    $params[$missingKey] = null;

                    break;
            }
        }

        // === Custom fields ===
        // CustomField1 : Amount and currency of the transaction
        $smarty = null;
        $params['customFields.customField1'] = \Tools::displayPriceSmarty(['price' => $params['amount.value'] / 100], $smarty);

        // CustomField2 : Order’s number
        $params['customFields.customField2'] = $params['orderReference'] ?? null;

        // CustomField3 : Merchant LOGO (recommanded 200x100px)
        if ($configuration->getShowLogo()) {
            $params['customFields.customField3'] = $configuration->getLogoUrl();
        }

        // CustomField4 : Order’s description
        if ($configuration->getViewCartSummary()) {
            $cartProducts = $cart->getProducts();
            $tempCustomField4 = [];
            $cartQuantity = 0;
            foreach ($cartProducts as $cartProduct) {
                $cartQuantity += $cartProduct['cart_quantity'];
                $tempCustomField4[] = $cartProduct['cart_quantity'] . ' x ' . $cartProduct['name'];
            }
            $customField4 = $context->getTranslator()->trans('Total number of items : %d || %s', [$cartQuantity, implode('|', $tempCustomField4)], 'Modules.Axepta2.CustomFields');
            $params['customFields.customField4'] = $customField4;
        }

        // CustomField5 : Buyer’s information
        if ($configuration->getViewBuyerDetails()) {
            $params['customFields.customField5'] = implode('|', [
                strtoupper($customer->lastname) . ' ' . $customer->firstname,
                $customer->email,
            ]);
        }

        // CustomField6 : Shipping information
        if ($configuration->getShowShippingAddr()) {
            $params['customFields.customField6'] = implode('|', [
                $addrDelivery->lastname . ' ' . $addrDelivery->firstname,
                $addrDelivery->address1,
                $addrDelivery->postcode . ' ' . $addrDelivery->city,
            ]);
        }

        // CustomField7 : Billing information
        if ($configuration->getShowBillingAddr()) {
            $params['customFields.customField7'] = implode('|', [
                $addrInvoice->lastname . ' ' . $addrInvoice->firstname,
                $addrInvoice->address1,
                $addrInvoice->postcode . ' ' . $addrInvoice->city,
            ]);
        }

        // CustomField8 : Name of a new field added by the merchant
        if ($configuration->getShowCustomTitle()) {
            $params['customFields.customField8'] = $configuration->getCustomTitle();
        }

        // CustomField9 : Value of a new field added by the merchant
        if ($configuration->getShowCustomText()) {
            $params['customFields.customField9'] = $configuration->getCustomText();
        }

        if ($configuration->getDisplayMethod() == Axepta2configurationAccount::DISPLAY_METHOD_IFRAME) {
            $params['customFields.customField14'] = 'iframe';
        }

        return [
            'args' => $params,
            'addr_invoice' => $addrInvoice,
            'addr_delivery' => $addrDelivery,
            'customer' => $customer,
            'currency' => $currency,
            'token' => $token,
            'isoCountryInvoice' => $isoCountryInvoice,
        ];
    }

    public static function generateTransactionReference($orderReference)
    {
        return 'TR' . $orderReference . '_' . \Tools::passwdGen(4);
    }

    /**
     * Retourne les transactions d'une commande formatées par statut (refundable, capturable, etc.)
     *
     * @param Axepta2transaction[] $transactions
     *
     * @return array
     */
    public static function getOrderTransactionsFormatted(array $transactions): array
    {
        $orderSlipUsed = [];
        $refundable = [];
        $refunded = [];
        $cancelable = [];
        $canceled = [];
        $captured = [];

        foreach ($transactions as $transaction) {
            if ($transaction->getResponseCode() !== Axepta2transaction::SUCCESS_CODE) {
                continue;
            }

            $transId = $transaction->getTransId();
            $transReferralId = $transaction->getTransactionReferralId();
            $payId = $transaction->getPayId();
            $status = $transaction->getStatus();

            if ($transaction->getOrderSlipId()) {
                $orderSlipUsed[] = $transaction->getOrderSlipId();
            }

            if ($status == Axepta2transaction::STATUS_REFUNDED) {
                if (!isset($refunded[$payId])) {
                    $refunded[$payId] = 0;
                }
                $refunded[$payId] += $transaction->getAmount();

                continue;
            }

            if ($status == Axepta2transaction::STATUS_REVERSED) {
                $canceled[] = $transReferralId;

                continue;
            }

            if ($status == Axepta2transaction::STATUS_CAPTURED) {
                $captured[] = $transReferralId;

                continue;
            }

            if ($transaction->getNeedCapture()) {
                $cancelable[] = $transId;
            } else {
                $refundable[$payId] = $transaction->toArray();
            }
        }

        // Calcul du montant remboursable / annullable par transaction
        foreach ($refundable as $key => $refundable_transaction) {
            $refundableAmount = $refundable_transaction['amount'] - ($refunded[$refundable_transaction['payId']] ?? 0);
            if ($refundableAmount == 0) {
                unset($refundable[$key]);

                continue;
            }
            $refundable[$key]['refundable_amount'] = $refundableAmount;
        }

        return [
            'refundable' => $refundable,
            'cancelable' => array_diff($cancelable, $canceled, $refunded),
            'refunded' => $refunded,
            'canceled' => $canceled,
            'captured' => $captured,
            'order_slip_used' => $orderSlipUsed,
        ];
    }

    public static function getTrigramPerMeanType($paymentMeanType)
    {
        switch ($paymentMeanType) {
            case 'CARD' :
                $trigram = 'CVM';

                break;

            default:
                $trigram = null;

                break;
        }

        return $trigram;
    }

    /**
     * Retourne la chaîne PRSHP_<PrestaShopVersion>_WE_<ModuleVersion>
     */
    public static function getModuleVersionTag(string $moduleName): string
    {
        $module = \Module::getInstanceByName($moduleName);
        $moduleVersion = $module ? $module->version : 'unknown';

        return 'PRSHP_' . _PS_VERSION_ . '_WE_' . $moduleVersion;
    }
}
