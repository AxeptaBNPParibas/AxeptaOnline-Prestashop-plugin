<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Form\Configuration;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Axepta2\Entity\Axepta2configurationAccount;
use Axepta2\Repository\Axepta2configurationAccountRepository;
use Axepta2\Repository\Axepta2paymentMethodRepository;
use PrestaShop\PrestaShop\Core\Form\IdentifiableObject\DataProvider\FormDataProviderInterface;

final class ConfigurationFormDataProvider implements FormDataProviderInterface
{
    public $configurationRepository;

    public $paymentMethodRepository;

    public function __construct(Axepta2configurationAccountRepository $configurationRepository, Axepta2paymentMethodRepository $paymentMethodRepository)
    {
        $this->configurationRepository = $configurationRepository;
        $this->paymentMethodRepository = $paymentMethodRepository;
    }

    /**
     * @return array
     */
    public function getData($shopId)
    {
        $data = [];

        $account = $this->configurationRepository->getCurrentConfiguration();

        if ($account !== null) {
            $data = $account->toArray();

            // payment_methods
            foreach ($data['configuration_payment_methods'] as $paymentMethod) {
                $data['payment_methods']['payment_method_' . $paymentMethod['payment_method_id']] = $paymentMethod['active'];
            }

            $front_label_values = [];
            foreach (\Language::getLanguages() as $lang) {
                $front_label_values[$lang['id_lang']] = \Configuration::get(
                    'AXEPTA2_FRONT_LABEL_' . $account->getId(),
                    $lang['id_lang'],
                    null,
                    $shopId,
                    'Pay with'
                );
            }
            $data['front_label'] = $front_label_values;
        }

        return $data;
    }

    /**
     * Get default form data.
     */
    public function getDefaultData()
    {
        return [
            'mode' => Axepta2configurationAccount::MODE_DEMO,
        ];
    }
}
