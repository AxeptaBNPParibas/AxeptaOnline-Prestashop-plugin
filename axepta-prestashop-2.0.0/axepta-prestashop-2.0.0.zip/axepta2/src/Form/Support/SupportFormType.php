<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Form\Support;

if (!defined('_PS_VERSION_')) {
    exit;
}

use PrestaShopBundle\Form\Admin\Type\TranslatorAwareType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Validator\Constraints as Assert;

class SupportFormType extends TranslatorAwareType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name', TextType::class, [
                'label' => $this->trans('Firstname & Lastname', 'Modules.Axepta2.Support'),
                'constraints' => [
                    new Assert\NotBlank(['message' => $this->trans('This field is required.', 'Modules.Axepta2.Support')]),
                ],
            ])
            ->add('email', EmailType::class, [
                'label' => $this->trans('Email', 'Modules.Axepta2.Support'),
                'constraints' => [
                    new Assert\NotBlank(['message' => $this->trans('This field is required.', 'Modules.Axepta2.Support')]),
                    new Assert\Email(['message' => $this->trans('Please enter a valid email address.', 'Modules.Axepta2.Support')]),
                ],
            ])
            ->add('description', TextareaType::class, [
                'label' => $this->trans('Description', 'Modules.Axepta2.Support'),
                'constraints' => [
                    new Assert\NotBlank(['message' => $this->trans('This field is required.', 'Modules.Axepta2.Support')]),
                ],
            ])
        ;
    }
}
