<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Entity;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Table()
 *
 * @ORM\Entity(repositoryClass="Axepta2\Repository\Axepta2transactionRepository")
 */
class Axepta2transaction
{
    /**
     * Clés sensibles à anonymiser partout dans le tableau
     */
    const SENSITIVE_FIELDS = [
        'pseudoCardNumber',
        'first6Digits',
        'expiryDate',
        'customerInfo',
        'billingAddress',
        'shipping',
        'schemeReferenceId',
        'cardHolderName',
    ];

    const RESPONSE_CODE_TIMEOUT_LIST = [
        '0051',
        '0056',
        '0368',
        '0402',
        '0931',
        '2206',
        '4005',
        '9040',
        '110A',
    ];

    const SUCCESS_CODE = '00000000';

    const STATUS_AUTHORIZED = 'AUTHORIZED';

    const STATUS_CAPTURED = 'CAPTURED';

    const STATUS_OK = 'OK';

    const STATUS_FAILED = 'FAILED';

    const STATUS_REFUNDED = 'REFUNDED';

    const STATUS_REVERSED = 'REVERSED';

    /**
     * @ORM\Id
     *
     * @ORM\Column(name="id_axepta2_transaction", type="integer")
     *
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /** @ORM\Column(name="merchant_id", type="string", length=255) */
    private $merchantId;

    /** @ORM\Column(name="order_id", type="integer") */
    private $orderId;

    /** @ORM\Column(name="order_slip_id", type="integer", nullable=true) */
    private $orderSlipId;

    /** @ORM\Column(name="trans_id", type="string", length=255) */
    private $transId;

    /** @ORM\Column(name="transaction_referral_id", type="string", length=255, nullable=true) */
    private $transactionReferralId;

    /** @ORM\Column(name="currency", type="string", length=10) */
    private $currency;

    /** @ORM\Column(name="id_axepta2_configuration_account", type="integer") */
    private $idConfigurationAccount;

    /** @ORM\Column(name="created_at", type="datetime") */
    private $createdAt;

    /** @ORM\Column(name="updated_at", type="datetime") */
    private $updatedAt;

    /** @ORM\Column(name="pay_id", type="string", length=255) */
    private $payId;

    /** @ORM\Column(name="xid", type="string", length=255) */
    private $xid;

    /** @ORM\Column(name="amount", type="decimal", precision=20, scale=2) */
    private $amount;

    /** @ORM\Column(name="transaction_type", type="string", length=255) */
    private $transactionType;

    /** @ORM\Column(name="payment_method", type="string", length=255) */
    private $paymentMethod;

    /** @ORM\Column(name="payment_mean_brand", type="string", length=255) */
    private $paymentMeanBrand;

    /** @ORM\Column(name="payment_mean_type", type="string", length=255) */
    private $paymentMeanType;

    /** @ORM\Column(name="payment_rendering_mode", type="string", length=255) */
    private $paymentRenderingMode;

    /** @ORM\Column(name="response_code", type="string", length=255, nullable=true) */
    private $responseCode;

    /** @ORM\Column(name="pcnr", type="string", length=255, nullable=true) */
    private $pcnr;

    /** @ORM\Column(name="ccexpiry", type="string", length=255, nullable=true) */
    private $ccexpiry;

    /** @ORM\Column(name="status", type="string", length=255, nullable=true) */
    private $status;

    /** @ORM\Column(name="description", type="string", length=255, nullable=true) */
    private $description;

    /** @ORM\Column(name="scheme_reference_id", type="string", length=255, nullable=true) */
    private $schemeReferenceId;

    /** @ORM\Column(name="raw_data", type="text", nullable=true) */
    private $rawData;

    /** @ORM\Column(name="need_capture", type="boolean") */
    private $needCapture = false;

    /** @ORM\Column(name="trigram", type="text") */
    private $trigram;

    public function __construct()
    {
        $this->setCreatedAt(new \DateTime());
        $this->setUpdatedAt(new \DateTime());
    }

    public function getId()
    {
        return $this->id;
    }

    public function setId($id)
    {
        $this->id = $id;

        return $this;
    }

    public function getIdConfigurationAccount()
    {
        return $this->idConfigurationAccount;
    }

    public function setIdConfigurationAccount($idConfigurationAccount)
    {
        $this->idConfigurationAccount = $idConfigurationAccount;

        return $this;
    }

    public function getMerchantId()
    {
        return $this->merchantId;
    }

    public function setMerchantId($merchantId)
    {
        $this->merchantId = $merchantId;

        return $this;
    }

    public function getCreatedAt()
    {
        return $this->createdAt;
    }

    public function setCreatedAt($createdAt)
    {
        $this->createdAt = $createdAt;

        return $this;
    }

    public function getUpdatedAt()
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt($updatedAt)
    {
        $this->updatedAt = $updatedAt;

        return $this;
    }

    public function getOrderId()
    {
        return $this->orderId;
    }

    public function setOrderId($orderId)
    {
        $this->orderId = $orderId;

        return $this;
    }

    public function getOrderSlipId()
    {
        return $this->orderSlipId;
    }

    public function setOrderSlipId($orderSlipId)
    {
        $this->orderSlipId = $orderSlipId;

        return $this;
    }

    public function getTransId()
    {
        return $this->transId;
    }

    public function setTransId($transId)
    {
        $this->transId = $transId;

        return $this;
    }

    public function getTransactionReferralId()
    {
        return $this->transactionReferralId;
    }

    public function setTransactionReferralId($transactionReferralId)
    {
        $this->transactionReferralId = $transactionReferralId;

        return $this;
    }

    public function getCurrency()
    {
        return $this->currency;
    }

    public function setCurrency($currency)
    {
        $this->currency = $currency;

        return $this;
    }

    public function getPayId()
    {
        return $this->payId;
    }

    public function setPayId($payId)
    {
        $this->payId = $payId;

        return $this;
    }

    public function getXid()
    {
        return $this->xid;
    }

    public function setXid($xid)
    {
        $this->xid = $xid;

        return $this;
    }

    public function getAmount()
    {
        return $this->amount;
    }

    public function setAmount($amount)
    {
        $this->amount = $amount;

        return $this;
    }

    public function getTransactionType()
    {
        return $this->transactionType;
    }

    public function setTransactionType($transactionType)
    {
        $this->transactionType = $transactionType;

        return $this;
    }

    public function getPaymentMethod()
    {
        return $this->paymentMethod;
    }

    public function setPaymentMethod($paymentMethod)
    {
        $this->paymentMethod = $paymentMethod;

        return $this;
    }

    public function getPaymentMeanBrand()
    {
        return $this->paymentMeanBrand;
    }

    public function setPaymentMeanBrand($paymentMeanBrand)
    {
        $this->paymentMeanBrand = $paymentMeanBrand;

        return $this;
    }

    public function getPaymentMeanType()
    {
        return $this->paymentMeanType;
    }

    public function setPaymentMeanType($paymentMeanType)
    {
        $this->paymentMeanType = $paymentMeanType;

        return $this;
    }

    public function getPaymentRenderingMode()
    {
        return $this->paymentRenderingMode;
    }

    public function setPaymentRenderingMode($paymentRenderingMode)
    {
        $this->paymentRenderingMode = $paymentRenderingMode;

        return $this;
    }

    public function getResponseCode()
    {
        return $this->responseCode;
    }

    public function setResponseCode($responseCode)
    {
        $this->responseCode = $responseCode;

        return $this;
    }

    public function getPcnr()
    {
        return $this->pcnr;
    }

    public function setPcnr($pcnr)
    {
        $this->pcnr = $pcnr;

        return $this;
    }

    public function getCcexpiry()
    {
        return $this->ccexpiry;
    }

    public function setCcexpiry($ccexpiry)
    {
        $this->ccexpiry = $ccexpiry;

        return $this;
    }

    public function getStatus()
    {
        return $this->status;
    }

    public function setStatus($status)
    {
        $this->status = $status;

        return $this;
    }

    public function getDescription()
    {
        return $this->description;
    }

    public function setDescription($description)
    {
        $this->description = $description;

        return $this;
    }

    public function getSchemeReferenceId()
    {
        return $this->schemeReferenceId;
    }

    public function setSchemeReferenceId($schemeReferenceId)
    {
        $this->schemeReferenceId = $schemeReferenceId;

        return $this;
    }

    public function getRawData()
    {
        return $this->rawData;
    }

    public function setRawData(array $rawData)
    {
        self::anonymizeRecursive($rawData);
        $this->rawData = json_encode($rawData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        return $this;
    }

    public function getNeedCapture()
    {
        return $this->needCapture;
    }

    public function setNeedCapture($needCapture)
    {
        $this->needCapture = $needCapture;

        return $this;
    }

    public function getTrigram()
    {
        return $this->trigram;
    }

    public function setTrigram($trigram)
    {
        $this->trigram = $trigram;

        return $this;
    }

    public function toArray()
    {
        return [
            'id' => $this->getId(),
            'idConfigurationAccount' => $this->getIdConfigurationAccount(),
            'merchantId' => $this->getMerchantId(),
            'createdAt' => $this->getCreatedAt() ? $this->getCreatedAt()->format('Y-m-d H:i:s') : null,
            'updatedAt' => $this->getUpdatedAt() ? $this->getUpdatedAt()->format('Y-m-d H:i:s') : null,
            'orderId' => $this->getOrderId(),
            'orderSlipId' => $this->getOrderSlipId(),
            'transId' => $this->getTransId(),
            'transactionReferralId' => $this->getTransactionReferralId(),
            'currency' => $this->getCurrency(),
            'payId' => $this->getPayId(),
            'xid' => $this->getXid(),
            'amount' => $this->getAmount(),
            'transactionType' => $this->getTransactionType(),
            'paymentMethod' => $this->getPaymentMethod(),
            'paymentMeanBrand' => $this->getPaymentMeanBrand(),
            'paymentMeanType' => $this->getPaymentMeanType(),
            'paymentRenderingMode' => $this->getPaymentRenderingMode(),
            'responseCode' => $this->getResponseCode(),
            'pcnr' => $this->getPcnr(),
            'ccexpiry' => $this->getCcexpiry(),
            'status' => $this->getStatus(),
            'description' => $this->getDescription(),
            'schemeReferenceId' => $this->getSchemeReferenceId(),
            'rawData' => $this->getRawData(),
            'needCapture' => $this->getNeedCapture(),
            'trigram' => $this->getTrigram(),
        ];
    }

    /**
     * Parcours récursif du tableau pour anonymiser les clés sensibles
     *
     * @param array &$array
     */
    public static function anonymizeRecursive(array &$array): void
    {
        foreach ($array as $key => &$value) {
            if (in_array($key, self::SENSITIVE_FIELDS, true)) {
                $value = '******';
            } elseif (is_array($value)) {
                self::anonymizeRecursive($value); // parcourt les sous-tableaux
            }
        }
    }
}
