<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Entity;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Table()
 *
 * @ORM\Entity(repositoryClass="Axepta2\Repository\Axepta2configurationPaymentMethodRepository")
 */
class Axepta2configurationPaymentMethod
{
    /**
     * @ORM\Id
     *
     * @ORM\GeneratedValue
     *
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity="Axepta2\Entity\Axepta2configurationAccount", inversedBy="configurationPaymentMethods", fetch="EAGER")
     *
     * @ORM\JoinColumn(nullable=false, onDelete="CASCADE")
     */
    private $configuration;

    /**
     * @ORM\ManyToOne(targetEntity="Axepta2\Entity\Axepta2paymentMethod", inversedBy="configurationPaymentMethods", fetch="EAGER")
     *
     * @ORM\JoinColumn(nullable=false, onDelete="CASCADE")
     */
    private $paymentMethod;

    /**
     * @ORM\Column(type="boolean", options={"default": false})
     */
    private $active = false;

    public function getConfiguration(): Axepta2configurationAccount
    {
        return $this->configuration;
    }

    public function setConfiguration(Axepta2configurationAccount $configuration): self
    {
        $this->configuration = $configuration;

        return $this;
    }

    public function getPaymentMethod(): Axepta2paymentMethod
    {
        return $this->paymentMethod;
    }

    public function setPaymentMethod(?Axepta2paymentMethod $paymentMethod): self
    {
        $this->paymentMethod = $paymentMethod;

        return $this;
    }

    public function isActive(): bool
    {
        return $this->active;
    }

    public function setActive(bool $active): self
    {
        $this->active = $active;

        return $this;
    }

    public function toArray(): array
    {
        return [
            'configuration_id' => $this->getConfiguration()->getId(), // ID de la configuration associée
            'payment_method_id' => $this->getPaymentMethod()->getId(), // ID du moyen de paiement associé
            'active' => $this->isActive(), // Statut actif (true ou false)
        ];
    }
}
