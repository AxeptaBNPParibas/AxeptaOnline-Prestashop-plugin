<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Grid\Transaction;

if (!defined('_PS_VERSION_')) {
    exit;
}

// Si la nouvelle classe existe, on l'utilise via un alias "DataColumn"
if (class_exists('PrestaShop\PrestaShop\Core\Grid\Column\Type\Common\DataColumn')) {
    class_alias(
        'PrestaShop\PrestaShop\Core\Grid\Column\Type\Common\DataColumn',
        'PrestaShop\PrestaShop\Core\Grid\Column\Type\DataColumn'
    );
}
if (class_exists('PrestaShop\PrestaShop\Core\Grid\Column\Type\Common\ColorColumn')) {
    class_alias(
        'PrestaShop\PrestaShop\Core\Grid\Column\Type\Common\ColorColumn',
        'PrestaShop\PrestaShop\Core\Grid\Column\Type\ColorColumn'
    );
}

use Axepta2\Entity\Axepta2Transaction;
use PrestaShop\PrestaShop\Core\Grid\Action\Row\RowActionCollection;
use PrestaShop\PrestaShop\Core\Grid\Action\Row\Type\SubmitRowAction;
use PrestaShop\PrestaShop\Core\Grid\Column\ColumnCollection;
use PrestaShop\PrestaShop\Core\Grid\Column\Type\ColorColumn;
use PrestaShop\PrestaShop\Core\Grid\Column\Type\Common\ActionColumn;
use PrestaShop\PrestaShop\Core\Grid\Column\Type\Common\LinkColumn;
use PrestaShop\PrestaShop\Core\Grid\Column\Type\DataColumn;
use PrestaShop\PrestaShop\Core\Grid\Definition\Factory\AbstractGridDefinitionFactory;
use PrestaShop\PrestaShop\Core\Grid\Filter\Filter;
use PrestaShop\PrestaShop\Core\Grid\Filter\FilterCollection;
use PrestaShopBundle\Form\Admin\Type\DateRangeType;
use PrestaShopBundle\Form\Admin\Type\SearchAndResetType;
use Symfony\Component\Form\Extension\Core\Type\TextType;

/**
 * Class AdminAxeptaTransactionsGridDefinitionFactory.
 */
final class Axepta2TransactionGridDefinitionFactory extends AbstractGridDefinitionFactory
{
    const GRID_ID = 'admin_axepta2_transactions';

    protected function getId()
    {
        return self::GRID_ID;
    }

    protected function getName()
    {
        return $this->trans('Transactions', [], 'Modules.Axepta2.Transaction');
    }

    protected function getColumns()
    {
        return (new ColumnCollection())
            ->add(
                (new DataColumn('trans_id'))
                ->setName($this->trans('ID transaction', [], 'Modules.Axepta2.Transaction'))
                ->setOptions([
                    'field' => 'trans_id',
                ])
            )
            ->add(
                (new LinkColumn('reference'))
                ->setName($this->trans('Order reference', [], 'Modules.Axepta2.Transaction'))
                ->setOptions([
                    'field' => 'reference',
                    'route' => 'admin_orders_view',
                    'route_param_name' => 'orderId',
                    'route_param_field' => 'order_id',
                ])
            )
            ->add(
                (new DataColumn('pay_id'))
                ->setName($this->trans('Pay id', [], 'Modules.Axepta2.Transaction'))
                ->setOptions([
                    'field' => 'pay_id',
                ])
            )
            ->add(
                (new DataColumn('amount'))
                ->setName($this->trans('Amount', [], 'Modules.Axepta2.Transaction'))
                ->setOptions([
                    'field' => 'amount',
                ])
            )
            ->add(
                (new DataColumn('currency'))
                ->setName($this->trans('Currency', [], 'Modules.Axepta2.Transaction'))
                ->setOptions([
                    'field' => 'currency',
                ])
            )
            ->add(
                (new DataColumn('payment_mean_type'))
                ->setName($this->trans('PM Type', [], 'Modules.Axepta2.Transaction'))
                ->setOptions([
                    'field' => 'payment_mean_type',
                ])
            )
            ->add(
                (new DataColumn('created_at'))
                ->setName($this->trans('Created At', [], 'Modules.Axepta2.Transaction'))
                ->setOptions([
                    'field' => 'created_at',
                ])
            )
            ->add(
                (new DataColumn('transaction_type'))
                ->setName($this->trans('Transaction Type', [], 'Modules.Axepta2.Transaction'))
                ->setOptions([
                    'field' => 'transaction_type',
                ])
            )
            ->add(
                (new DataColumn('response_code'))
                ->setName($this->trans('Response code', [], 'Modules.Axepta2.Transaction'))
                ->setOptions([
                    'field' => 'response_code',
                ])
            )
            ->add(
                (new ColorColumn('status'))
                ->setName($this->trans('Status', [], 'Modules.Axepta2.Transaction'))
                ->setOptions([
                    'field' => 'status',
                    'color_field' => 'status_color',
                    'sortable' => false,
                ])
            )
            ->add(
                (new DataColumn('description'))
                ->setName($this->trans('Description', [], 'Modules.Axepta2.Transaction'))
                ->setOptions([
                    'field' => 'description',
                ])
            )
            ->add(
                (new ActionColumn('actions'))
                ->setName('Actions')
                ->setOptions([
                    'actions' => (new RowActionCollection())
                                    ->add(
                                        (new SubmitRowAction('capture'))
                                            ->setName($this->trans('Capturer', [], 'Modules.Axepta2.Transaction'))
                                            ->setIcon('payment')
                                            ->setOptions([
                                                'route' => 'axepta2_admin_transaction_capture',
                                                'route_param_name' => 'transactionId',
                                                'route_param_field' => 'id_axepta2_transaction',
                                                'accessibility_checker' => function (array $record) {
                                                    return isset($record['need_capture']) && $record['need_capture']
                                                    && isset($record['response_code']) && $record['response_code'] == Axepta2Transaction::SUCCESS_CODE;
                                                },
                                                'confirm_message' => $this->trans(
                                                    'Are you sure you want to capture this transaction?',
                                                    [],
                                                    'Modules.Axepta2.Transaction'
                                                ),
                                            ])
                                    ),
                ])
            )
            ->add(
                (new ActionColumn('search'))
                ->setName('')
                ->setOptions([
                    'actions' => null,
                ])
            )
        ;
    }

    /**
     * {@inheritdoc}
     *
     * Define filters and associate them with columns.
     * Note that you can add filters that are not associated with any column.
     */
    protected function getFilters()
    {
        return (new FilterCollection())
            ->add(
                (new Filter('trans_id', TextType::class))
                ->setTypeOptions([
                    'required' => false,
                ])
                ->setAssociatedColumn('trans_id')
            )
            ->add(
                (new Filter('reference', TextType::class))
                ->setTypeOptions([
                    'required' => false,
                ])
                ->setAssociatedColumn('reference')
            )
            ->add(
                (new Filter('pay_id', TextType::class))
                ->setTypeOptions([
                    'required' => false,
                ])
                ->setAssociatedColumn('pay_id')
            )
            ->add(
                (new Filter('response_code', TextType::class))
                ->setTypeOptions([
                    'required' => false,
                ])
                ->setAssociatedColumn('response_code')
            )
            ->add(
                (new Filter('amount', TextType::class))
                ->setTypeOptions([
                    'required' => false,
                ])
                ->setAssociatedColumn('amount')
            )
            ->add(
                (new Filter('payment_mean_type', TextType::class))
                ->setTypeOptions([
                    'required' => false,
                ])
                ->setAssociatedColumn('payment_mean_type')
            )
            ->add(
                (new Filter('created_at', DateRangeType::class))
                ->setTypeOptions([
                    'required' => false,
                ])
                ->setAssociatedColumn('created_at')
            )
            ->add(
                (new Filter('transaction_type', TextType::class))
                ->setTypeOptions([
                    'required' => false,
                ])
                ->setAssociatedColumn('transaction_type')
            )
            ->add(
                (new Filter('status', TextType::class))
                ->setTypeOptions([
                    'required' => false,
                ])
                ->setAssociatedColumn('status')
            )
            ->add(
                (new Filter('search', SearchAndResetType::class))
                ->setTypeOptions([
                    'reset_route' => 'admin_common_reset_search_by_filter_id',
                    'reset_route_params' => [
                        'filterId' => self::GRID_ID,
                    ],
                    'redirect_route' => 'axepta2_admin_transaction_list',
                ])
                ->setAssociatedColumn('search')
            )
        ;
    }
}
