<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */

namespace Axepta2\Grid\Subscription;

if (!defined('_PS_VERSION_')) {
    exit;
}

use Doctrine\DBAL\Connection;
use Doctrine\DBAL\Query\QueryBuilder;
use PrestaShop\PrestaShop\Core\Grid\Query\AbstractDoctrineQueryBuilder;
use PrestaShop\PrestaShop\Core\Grid\Search\SearchCriteriaInterface;

final class Axepta2SubscriptionGridQueryBuilder extends AbstractDoctrineQueryBuilder
{
    /**
     * @var int
     */
    private $contextLangId;

    /**
     * @var int
     */
    private $contextShopId;

    /**
     * @param string $dbPrefix
     * @param int $contextLangId
     * @param int $contextShopId
     */
    public function __construct(Connection $connection, $dbPrefix, $contextLangId, $contextShopId)
    {
        parent::__construct($connection, $dbPrefix);

        $this->contextLangId = $contextLangId;
        $this->contextShopId = $contextShopId;
    }

    public function getSearchQueryBuilder(SearchCriteriaInterface $searchCriteria)
    {
        $qb = $this->getBaseQuery();

        $select = [
            'rec.id_axepta2_subscription',
            'rec.product_id',
            'pl.name',
            'rec.order_id',
            'o.reference',
            'rec.customer_id',
            'CONCAT(c.lastname, \' \', c.firstname) as customer_fullname',
            'rec.amount_tax_excl',
            'rec.status',
            'rec.periodicity',
            'rec.last_schedule',
            'rec.next_schedule',
        ];

        $qb
            ->select(implode(',', $select))
            ->orderBy(
                $searchCriteria->getOrderBy(),
                $searchCriteria->getOrderWay()
            )
            ->setFirstResult($searchCriteria->getOffset() ?? 0)
            ->setMaxResults($searchCriteria->getLimit())
        ;

        foreach ($searchCriteria->getFilters() as $filterName => $filterValue) {
            if ('active' === $filterName) {
                (bool) $filterValue
                    ? $qb->andWhere('rec.active = 1')
                    : $qb->andWhere('rec.active = 0');

                continue;
            }

            if ('created_at' === $filterName) {
                if ($filterValue) {
                    $qb->andWhere('rec.created_at >= "' . pSQL($filterValue['from']) . ' 00:00:00" AND rec.created_at <= "' . pSQL($filterValue['to']) . ' 23:59:59"');
                }

                continue;
            }

            $qb->andWhere("$filterName LIKE :$filterName");
            $qb->setParameter($filterName, '%' . $filterValue . '%');
        }

        return $qb;
    }

    public function getCountQueryBuilder(SearchCriteriaInterface $searchCriteria)
    {
        $qb = $this->getBaseQuery();
        $qb->select('COUNT(rec.id_axepta2_subscription)');

        return $qb;
    }

    /**
     * Base query is the same for both searching and counting.
     *
     * @return QueryBuilder
     */
    private function getBaseQuery()
    {
        $qb = $this->connection
            ->createQueryBuilder()
            ->from($this->dbPrefix . 'axepta2subscription', 'rec')
            ->leftJoin(
                'rec',
                $this->dbPrefix . 'orders',
                'o',
                'rec.order_id = o.id_order'
            )
            ->leftJoin(
                'rec',
                $this->dbPrefix . 'product_lang',
                'pl',
                'rec.product_id = pl.id_product AND pl.id_lang = :idLang'
            )
            ->leftJoin(
                'rec',
                $this->dbPrefix . 'customer',
                'c',
                'rec.customer_id = c.id_customer'
            )
            ->setParameter('idLang', $this->contextLangId)
            ->groupBy('rec.id_axepta2_subscription'); // clé primaire subscription

        // 🔹 Filtrer par boutique uniquement si on est dans une boutique spécifique
        if ($this->contextShopId !== \Shop::CONTEXT_ALL) {
            $qb->andWhere('o.id_shop = :idShop')
            ->setParameter('idShop', $this->contextShopId);
        }

        return $qb;
    }
}
