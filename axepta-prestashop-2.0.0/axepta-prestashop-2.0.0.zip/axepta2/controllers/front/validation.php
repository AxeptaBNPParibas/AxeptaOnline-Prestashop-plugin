<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

use Axepta2\Entity\Axepta2configurationAccount;
use Axepta2\Entity\Axepta2transaction;
use Axepta2\Exception\ConfigurationNotFoundException;
use Axepta2\Utils\Logger;
use Axepta2\Utils\Utils;
use AxeptaPaygate\Core\AxeptaPaygate;
use AxeptaPaygate\Core\CaptureMode;

class Axepta2ValidationModuleFrontController extends ModuleFrontController
{
    /** @var Axepta2 */
    public $module;

    public function postProcess()
    {
        Logger::info('Validation CALL');

        $payID = Tools::getValue('PayID');

        if (!$payID || !$this->module->active) {
            Logger::info('Module inactive or missing PayID');
            Tools::redirect('index.php');

            exit;
        }

        try {
            $configuration = $this->getConfiguration();
            $paymentDetails = $this->fetchPaymentDetails($configuration, $payID);
            $logs = $paymentDetails;
            Axepta2transaction::anonymizeRecursive($logs);
            Logger::info(json_encode($logs));

            // Variables locales pour éviter répétition
            $cartId = $paymentDetails['metadata']['cartId'] ?? 0;
            $responseCode = $paymentDetails['responseCode'] ?? '';
            $amountValue = (float) ($paymentDetails['amount']['value'] ?? 0);
            $captureMethod = $paymentDetails['metadata']['captureMethod'] ?? '';
            $isIframe = $paymentDetails['metadata']['iframe'] ?? false;

            $cartContext = $this->resolveCartContext($cartId);

            // Vérifications
            $this->checkTransactionExists($payID, $cartContext, $isIframe);
            $this->checkTimeout($responseCode);

            // Calculs
            $amount = $amountValue / 100;
            $success = ($responseCode === Axepta2transaction::SUCCESS_CODE);
            $needCapture = ($captureMethod == CaptureMode::MANUAL);

            // Création de la commande
            $orderStatus = Utils::getOrderStatus($configuration, $success, $needCapture);
            $order = $this->createOrder($cartContext, $amount, $payID, $orderStatus);

            // Enregistrement de la transaction
            $this->recordTransaction($order, $paymentDetails, $configuration, $cartContext['currency'], $needCapture);

            // Redirection centralisée
            $this->redirectTo($cartContext, $order, $success, $isIframe);
        } catch (\Exception $e) {
            Logger::critical($e->getMessage());
            Tools::redirect('index.php');

            exit;
        }
    }

    /** @return Axepta2configurationAccount */
    private function getConfiguration()
    {
        $configurationRepository = $this->get('axepta2.repository.configuration_account');
        $configuration = $configurationRepository->getCurrentConfiguration();

        if (!$configuration) {
            throw new ConfigurationNotFoundException($this->trans('No configuration found', [], 'Modules.Axepta2.Validation'));
        }

        return $configuration;
    }

    private function fetchPaymentDetails($configuration, $payID): array
    {
        $token = Utils::getAccessToken(
            $configuration->getPublicKey(),
            $configuration->getPrivateKey(),
            $configuration->getModeMap()
        );

        AxeptaPaygate::init(['paymentMode' => $configuration->getModeMap()]);
        $paymentDetails = AxeptaPaygate::getPaymentDetails($token, $payID);

        return $paymentDetails;
    }

    private function resolveCartContext($cartId): array
    {
        $cart = new Cart($cartId);
        if (!Validate::isLoadedObject($cart)) {
            throw new Exception($this->trans('Cart not found', [], 'Modules.Axepta2.Validation'));
        }

        $customer = new Customer((int) $cart->id_customer);
        if (!Validate::isLoadedObject($customer)) {
            throw new Exception($this->trans('Customer not found', [], 'Modules.Axepta2.Validation'));
        }

        $currency = new Currency((int) $cart->id_currency);

        return [
            'cart' => $cart,
            'customer' => $customer,
            'currency' => $currency,
            'secureKey' => $customer->secure_key,
        ];
    }

    private function checkTransactionExists($payID, $cartContext, $isIframe)
    {
        $transactionRepository = $this->get('axepta2.repository.transaction');
        $existingTransaction = $transactionRepository->findOneByPayId($payID);

        if ($existingTransaction) {
            Logger::info("Transaction already exists: $payID. Redirecting to confirmation.");
            $this->redirectTo($cartContext, new Order($existingTransaction->getOrderId()), $existingTransaction->getStatus() === 'OK', $isIframe);

            exit; // sécurité pour s'assurer qu'on ne continue pas
        }
    }

    private function checkTimeout($responseCode)
    {
        $last4 = substr($responseCode, -4);
        if (in_array($last4, Axepta2transaction::RESPONSE_CODE_TIMEOUT_LIST)) {
            Logger::info("Transaction timeout detected (code: $responseCode). Processing stopped.");

            exit; // aucune commande ni redirection
        }
    }

    private function createOrder(array $cartContext, float $amount, string $payID, int $orderStatus): Order
    {
        $message = $this->trans('Payment success - Transaction : ', [], 'Modules.Axepta2.Validation') . $payID;

        $this->module->validateOrder(
            (int) $cartContext['cart']->id,
            $orderStatus,
            $amount,
            $this->module->displayName,
            $message,
            ['transaction_id' => $payID],
            (int) $cartContext['currency']->id,
            false,
            $cartContext['secureKey']
        );

        $order = new Order($this->module->currentOrder);
        Logger::info('Order created : ' . $order->reference);

        return $order;
    }

    private function recordTransaction(Order $order, array $paymentDetails, $configuration, Currency $currency, $needCapture): void
    {
        $paymentMethodType = $paymentDetails['paymentMethods']['type'] ?? null;
        $paymentMeanInfo = $paymentDetails['paymentMethods'][strtolower($paymentMethodType)] ?? [];

        $transaction = new Axepta2transaction();
        $transaction->setIdConfigurationAccount($configuration->getId());
        $transaction->setMerchantId($configuration->getPublicKey());
        $transaction->setOrderId((int) $order->id);
        $transaction->setTransId($paymentDetails['transId']);
        $transaction->setCurrency($currency->iso_code);
        $transaction->setPayId($paymentDetails['payId'] ?? null);
        $transaction->setXid($paymentDetails['xId'] ?? null);
        $transaction->setAmount((float) $paymentDetails['amount']['value'] / 100);
        $transaction->setTransactionType($paymentDetails['metadata']['operationType'] ?? null);
        $transaction->setPaymentMethod($paymentDetails['metadata']['paymentMode'] ?? null);
        $transaction->setPaymentMeanBrand($paymentMeanInfo['brand'] ?? null);
        $transaction->setPaymentMeanType($paymentMethodType);
        $transaction->setPaymentRenderingMode($paymentDetails['metadata']['paymentRenderingMode'] ?? null);
        $transaction->setResponseCode($paymentDetails['responseCode'] ?? null);
        $transaction->setDescription($paymentDetails['responseDescription'] ?? null);
        $transaction->setStatus($paymentDetails['status'] ?? null);
        $transaction->setNeedCapture($needCapture);
        $transaction->setTrigram($paymentDetails['metadata']['trigram'] ?? null);

        if ($paymentDetails['metadata']['saveCard'] ?? false) {
            $transaction->setPcnr($paymentMeanInfo['pseudoCardNumber'] ?? null);
            $transaction->setCcexpiry($paymentMeanInfo['expiryDate'] ?? null);
            $transaction->setSchemeReferenceId($paymentMeanInfo['schemeReferenceId'] ?? null);
        }

        $transaction->setRawData($paymentDetails);

        $em = $this->get('doctrine.orm.entity_manager');
        $em->persist($transaction);
        $em->flush();

        Logger::info('Transaction created : ' . $transaction->getId());
    }

    private function redirectTo(array $cartContext, Order $order, bool $success, bool $isIframe)
    {
        $customer = $cartContext['customer'];
        $url = '';

        if ($success) {
            // OK → order-confirmation
            $url = $this->context->link->getPageLink(
                'order-confirmation',
                true,
                $customer->id_lang,
                [
                    'id_cart' => (int) $cartContext['cart']->id,
                    'id_module' => (int) $this->module->id,
                    'id_order' => (int) $order->id,
                    'key' => $customer->secure_key,
                ],
                false,
                $this->context->shop->id
            );
        } else {
            // Échec → order-detail ou guest-tracking
            if ($customer->is_guest) {
                $url = $this->context->link->getPageLink(
                    'guest-tracking',
                    true,
                    $customer->id_lang,
                    [
                        'id_order' => (int) $order->id,
                        'email' => $customer->email,
                    ]
                );
            } else {
                $url = $this->context->link->getPageLink(
                    'order-detail',
                    true,
                    $customer->id_lang,
                    ['id_order' => (int) $order->id]
                );
            }
        }

        if ($isIframe) {
            $this->context->smarty->assign([
               'url' => $url,
               'success' => $success,
            ]);

            return $this->setTemplate('module:axepta2/views/templates/front/validation-iframe.tpl');
        }

        Tools::redirect($url);

        exit;
    }
}
