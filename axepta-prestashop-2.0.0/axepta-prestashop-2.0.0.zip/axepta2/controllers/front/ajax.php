<?php
/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */
if (!defined('_PS_VERSION_')) {
    exit;
}

use Axepta2\Entity\Axepta2configurationAccount;
use Axepta2\Exception\Axepta2Exception;
use Axepta2\Exception\ConfigurationNotFoundException;
use Axepta2\Exception\RedirectLinkException;
use Axepta2\Utils\Logger;
use Axepta2\Utils\Utils;
use AxeptaPaygate\Core\AxeptaPaygate;
use AxeptaPaygate\Core\OperationType;

class Axepta2AjaxModuleFrontController extends ModuleFrontController
{
    /** @var bool If set to true, will be redirected to authentication page */
    public $auth = false;

    public $trigram;

    public $save_card;

    public $is_recurring;

    const AUTHORIZED_ACTIONS = [
        'getIframeParams',
    ];

    public function __construct()
    {
        parent::__construct();
        $this->ssl = true;
        $this->ajax = true;
        $this->json = true;
    }

    public function displayAjax()
    {
        $respondeCode = '200';

        try {
            $this->validate();

            $repositoryIC = $this->get('axepta2.repository.iso_country');
            $configurationRepository = $this->get('axepta2.repository.configuration_account');

            /** @var Axepta2configurationAccount|null $configuration */
            $configuration = $configurationRepository->getCurrentConfiguration();

            if (!$configuration) {
                throw new ConfigurationNotFoundException();
            }

            $params = Utils::buildAxeptaParams(
                $this->trigram,
                $this->is_recurring ? OperationType::RECURRING_PAYMENT_SUBSCRIPTION : OperationType::SIMPLE_PAYMENT,
                $this->context->cart,
                $configuration,
                $this->context,
                $repositoryIC
            );
            AxeptaPaygate::init($params['args']);
            $operation = AxeptaPaygate::buildOperation();
            $request = $operation['request'];
            $response = $request->call();
            $json = json_decode($response, true);

            if (!isset($json['_links']['redirect']['href'])) {
                Logger::debug(print_r($json, true));

                throw new RedirectLinkException();
            }

            $message = json_encode(['src' => $json['_links']['redirect']['href']]);
        } catch (Axepta2Exception $ce) {
            $respondeCode = 400;
            Logger::critical($ce->getMessage());

            $message = $this->module->getTranslator()->trans($ce->getMessage(), [], 'Modules.Axepta2.Exception');
        } catch (Exception $e) {
            $respondeCode = 500;
            Logger::critical($e->getMessage());
            $message = $this->module->getTranslator()->trans('An error occurred during the payment process. Please try again.', [], 'Modules.Axepta2.Exception');
        }

        header('Content-Type: application/json', true, $respondeCode);

        return $this->ajaxRender($message);
    }

    private function validate()
    {
        // Check Http Call
        if ('cli' === php_sapi_name()) {
            throw new Axepta2Exception('Forbidden call.');
        }

        if (!Tools::getIsset('action')) {
            throw new Axepta2Exception('Action is required.');
        }

        $action = Tools::getValue('action');
        if (!in_array($action, self::AUTHORIZED_ACTIONS)) {
            throw new Axepta2Exception('Action not found.');
        }

        // Check requirements
        switch ($action) {
            case 'getIframeParams':
                if (
                    !Tools::getIsset('trigram')
                    || !Tools::getIsset('save_card')
                    // || !Tools::getIsset('is_recurring')
                ) {
                    throw new Axepta2Exception('Missing parameter (trigram / save_card / is_recurring).');
                }

                $this->trigram = substr(Tools::getValue('trigram'), 0, 3);

                // Check params type
                if (!in_array(Tools::getValue('save_card'), ['true', 'false', true, false])) {
                    throw new Axepta2Exception('Parameter `save_card` is incorrect.');
                }
                $this->save_card = boolval(Tools::getValue('save_card'));

                // if (!in_array(Tools::getValue('is_recurring'), ['', '1'])) {
                //     throw new Axepta2Exception('Parameter `is_recurring` is incorrect.');
                // }
                // $this->is_recurring = boolval(Tools::getValue('is_recurring'));

                break;
        }
    }
}
