/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */
$(document).ready(function () {
    window.prestashop.component.initComponents(['TranslatableField']);

    initModeEvent();
    initPaymentMethods();
    initToggleField('configuration_form[show_logo]', '#configuration_form_logo_url');
    initToggleField('configuration_form[show_custom_title]', '#configuration_form_custom_title');
    initToggleField('configuration_form[show_custom_text]', '#configuration_form_custom_text');
    initSelectToggleSection('#configuration_form_payment_method_organization', '#configuration_form_display_method', '0' /* value:GROUPED */);
    initFormErrorScroll();
    initToggleLanguageSelection();
    initModalSupport();
});

function initModeEvent() {
    const $modeSelect = $('#configuration_form_mode');

    function toggleKeys() {
        const mode = $modeSelect.val();

        const $publicKeyProd = $('#configuration_form_public_key_prod');
        const $privateKeyProd = $('#configuration_form_private_key_prod');
        const $publicKeyTest = $('#configuration_form_public_key_test');
        const $privateKeyTest = $('#configuration_form_private_key_test');

        const $publicKeyProdGroup = $publicKeyProd.closest('.form-group.row');
        const $privateKeyProdGroup = $privateKeyProd.closest('.form-group.row');
        const $publicKeyTestGroup = $publicKeyTest.closest('.form-group.row');
        const $privateKeyTestGroup = $privateKeyTest.closest('.form-group.row');

        // Stocker l'état initial des required au premier appel
        if (!$publicKeyProd.data('initial-required')) {
            $publicKeyProd.data('initial-required', $publicKeyProd.prop('required'));
            $privateKeyProd.data('initial-required', $privateKeyProd.prop('required'));
            $publicKeyTest.data('initial-required', $publicKeyTest.prop('required'));
            $privateKeyTest.data('initial-required', $privateKeyTest.prop('required'));
        }

        // Masquer tous les champs et retirer required
        $publicKeyProdGroup.hide(); $publicKeyProd.prop('required', false);
        $privateKeyProdGroup.hide(); $privateKeyProd.prop('required', false);
        $publicKeyTestGroup.hide(); $publicKeyTest.prop('required', false);
        $privateKeyTestGroup.hide(); $privateKeyTest.prop('required', false);

        // Help message pour Demo
        let helpText = '';

        if (mode === '1') { // Production
            $publicKeyProdGroup.show();
            $privateKeyProdGroup.show();
            // Rétablir le required original
            $publicKeyProd.prop('required', $publicKeyProd.data('initial-required'));
            $privateKeyProd.prop('required', $privateKeyProd.data('initial-required'));
        } else if (mode === '2') { // Test
            $publicKeyTestGroup.show();
            $privateKeyTestGroup.show();
            $publicKeyTest.prop('required', $publicKeyTest.data('initial-required'));
            $privateKeyTest.prop('required', $privateKeyTest.data('initial-required'));
        } else if (mode === '0') { // Demo
            helpText = $modeSelect.data('demo-help');
        }

        // Ajouter / mettre à jour le petit message d’aide
        let $help = $('.mode-demo-help');
        if ($help.length === 0) {
            $help = $('<small class="form-text mode-demo-help"></small>');
            $modeSelect.closest('div').append($help);
        }
        $help.text(helpText).toggle(!!helpText);
    }

    // Bind l'événement change
    $modeSelect.on('change', toggleKeys);

    // Initialisation au chargement
    toggleKeys();
}

function initPaymentMethods() {
    // Boucle sur toutes les méthodes principales
    $('.axepta2-payment-method').each(function() {
        var $method = $(this);
        var parentId = $method.data('id'); // On suppose que chaque méthode principale a data-id="{{ id }}"

        if (!parentId) {
            return; // Ignore les sous-méthodes
        }

        // Trouver les radios "on/off" du switch
        var $switchOn = $method.find('input[value="1"]');
        var $switchOff = $method.find('input[value="0"]');

        function updateSubMethods() {
            var isOn = $switchOn.is(':checked');
            // Cacher/afficher toutes les sous-méthodes qui ont data-parent = parentId
            $('.sub-payment[data-parent="' + parentId + '"]').each(function() {
                if (isOn) {
                    $(this).show(500);
                } else {
                    $(this).hide(500);
                    // Décoche les sous-méthodes
                    $(this).find('input[type="radio"]').prop('checked', false);
                }
            });
        }

        // Événement au changement
        $switchOn.add($switchOff).change(updateSubMethods);

        // Déclenchement initial
        updateSubMethods();
    });
}

function initFormErrorScroll()
{
    var $invalidField = $('.is-invalid').first(); // On prend le premier élément invalide
    if ($invalidField.length) {
        // Scroll jusqu'à l'élément avec animation
        $('html, body').animate({
            scrollTop: $invalidField.offset().top - 200
        }, 500); // 500ms pour l'animation
    }
}

function initModalSupport()
{
    $('#axepta2-modal-support').on('hidden.bs.modal', function () {
        modalHideMessageAndDisplayBody($(this));
    })
}
