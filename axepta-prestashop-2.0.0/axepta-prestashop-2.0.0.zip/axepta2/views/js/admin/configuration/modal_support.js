/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */
$(document).ready(function () {
    $(document).on('click', '#axepta2-modal-support .js-submit-support-demand', function () {
        $('form[name="axepta2SupportForm"]').submit();
    });

    $(document).on('submit', 'form[name="axepta2SupportForm"]', function (e) {
        e.preventDefault();

        if (this.checkValidity()) {
            let url = $(this).attr('action');
            let modalId = '#axepta2-modal-support'
            let modalLoading = $(modalId).find('.loading-screen');
            let modalBodyContent = $(modalId).find('.modal-body-content');
            let modalBodyResponseMessage = $(modalId).find('.response-message');
            let modalFooter = $(modalId).find('.modal-footer');

            modalBodyContent.hide();
            modalLoading.show();
            modalFooter.hide();

            $.ajax({
                url: url,
                method: 'POST',
                data: $(this).serialize(),
                headers: { 'X-Requested-With': 'XMLHttpRequest' },
                success: function (response) {
                    setTimeout(function () {
                        modalLoading.hide();
                        modalBodyResponseMessage.html('<div class="alert alert-success">'+response.success+'</div>');
                        modalBodyResponseMessage.show();
                    }, 500);
                },
                error: function (response) {
                    setTimeout(function () {
                        modalLoading.hide();
                        let errorMsg = response.responseJSON?.error
                            ?? response.responseText
                            ?? 'An error occured.';

                        modalBodyResponseMessage.html('<div class="alert alert-danger">'+errorMsg+'</div>');
                        modalBodyResponseMessage.show();
                    }, 500);
                }
            });
        } else {
            this.reportValidity();
        }
    });
});
