/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */
function ensureAxeptaLoader() {
	let $loader = $('#axepta2-loader');

	if ($loader.length === 0) {
		const loaderHtml = `
			<div id="axepta2-loader" class="axepta2-loader hidden">
				<div class="axepta2-loader-inner">
					<div class="axepta2-spinner"></div>
					<p class="axepta2-loader-text" data-translate="redirecting_text">
						${typeof redirect_loader_text !== 'undefined' ? redirect_loader_text : 'Redirecting to payment page...'}
					</p>
				</div>
			</div>
		`;

		$('body').append(loaderHtml);
		$loader = $('#axepta2-loader');
	}

	return $loader;
}

function showAxeptaLoader($loader) {
	$loader.fadeIn(200);
}
