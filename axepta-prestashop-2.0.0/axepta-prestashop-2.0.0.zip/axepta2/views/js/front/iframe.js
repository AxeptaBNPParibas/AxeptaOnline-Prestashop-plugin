/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */
$(document).ready(function () {
	const binariesContainer = $('#axepta2-binaries-container');

	if (binariesContainer.length === 0) {
		return; // No Iframe container detected. We stop here
	}

	initPaymentMethodSelection(binariesContainer);
});

/**
 * Initialise la gestion de l’iFrame Axepta2
 * @param {jQuery} binariesContainer
 */
function initPaymentMethodSelection(binariesContainer) {
	const $container = $('.axepta2-payment-groups-container');
	if ($container.length === 0) return;

	const cgvCheckbox = $("input[id^='conditions_to_approve']");
	const spinner = $('#axepta2-iframe-spinner');
	const iframe = $('#axepta2-iframe');
	const messageBox = $('.axepta2-iframe-message');

	/**
	 * Active ou désactive l’iFrame selon l’état de la case CGV
	 */
	cgvCheckbox.on('change', function () {
		if ($(this).is(':checked')) {
			binariesContainer.removeClass('cgv_disabled');
		} else {
			binariesContainer.addClass('cgv_disabled');
		}
	});

	/**
	 * Quand on clique sur une icône de paiement
	 */
	$container.on('click', '.payment-icon', function () {
		const trigram = $(this).data('trigram') || null;

		if (!trigram) {
			console.error('Axepta2: no trigram found on clicked payment icon');
			return;
		}

		console.log(`Axepta2: loading iframe for ${trigram}`);
		displayIframe(trigram, false, true); // force le rechargement
	});

	/**
	 * Affiche et recharge l’iFrame avec les bons paramètres
	 */
	function displayIframe(trigram, saveCard = false, forceLoad = false) {
		if (binariesContainer.length === 0) {
			console.error('Axepta2: iFrame container not found.');
			return;
		}

		binariesContainer.removeClass('disabled');

		// CGV non cochées
		if (cgvCheckbox.length && !cgvCheckbox.is(':checked')) {
			binariesContainer.addClass('cgv_disabled');
		} else {
			binariesContainer.removeClass('cgv_disabled');
		}

		// Évite le rechargement inutile
		if (!forceLoad && trigram === binariesContainer.data('trigram')) {
			iframe.removeClass('disabled');
			return;
		}

		// On vide le message et cache l’iframe avant le nouveau chargement
		hideMessage();
		iframe.hide();

		binariesContainer.data('trigram', trigram);

		loadIframeParams(trigram, saveCard);
	}

	/**
	 * Charge les paramètres de l’iFrame via AJAX et met à jour le `src`
	 */
	function loadIframeParams(trigram, saveCard) {
		spinner.show();

		$.ajax({
			type: 'POST',
			dataType: 'json',
			url: ajaxUrl, // injecté depuis PHP via Media::addJsDef
			data: {
				action: 'getIframeParams',
				trigram: trigram,
				save_card: saveCard || false,
			},
			success: function (response) {
				if (response && response.src) {
					iframe.attr('src', response.src).show();
				} else if (response && response.error) {
					console.error('Axepta2: server error:', response.error);
					showMessage(response.error, 'error');
					iframe.hide(); // on garde l'iframe masquée
				} else {
					console.error('Axepta2: invalid iframe response', response);
					showMessage($iframe_unexpected_response_err_msg, 'error');
					iframe.hide();
				}
			},
			error: function (xhr, status, error) {
				console.error('Axepta2: AJAX error', error);
				console.log('Response text:', xhr.responseText);
				showMessage($iframe_generating_payment_err_msg, 'error');
				iframe.hide();
			},
			complete: function () {
				spinner.hide();
			}
		});
	}

	/**
	 * Affiche un message d’erreur ou d’information dans la div .axepta2-iframe-message
	 */
	function showMessage(text, type = 'info') {
		messageBox.show().removeClass('alert-info alert-danger');

		if (type === 'error') {
			messageBox.addClass('alert-danger');
		} else {
			messageBox.addClass('alert-info');
		}

		messageBox.text(text);
	}

	/**
	 * Cache et vide le message d’erreur
	 */
	function hideMessage() {
		messageBox.hide().text('').removeClass('alert-danger alert-info');
	}
}
