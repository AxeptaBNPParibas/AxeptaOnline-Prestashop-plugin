/**
 * MIT License
 *
 * Copyright (c) Since 2025 PayXpert
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.
 *
 * @author     We+
 * @copyright  Since 2025 PayXpert
 * @license    MIT https://spdx.org/licenses/MIT
 */
function modalHideMessageAndDisplayBody($e)
{
    $e.find('.response-message').hide();
    $e.find('.modal-body-content, .modal-footer').show();
}

function initToggleField(switchName, fieldSelector)
{
    var $field = $(fieldSelector).closest('.form-group');
    var $input = $(fieldSelector);

    function updateVisibility() {
        var value = $('input[name="' + switchName + '"]:checked').val();
        if (value === '1') {
            $field.show();
            $input.prop('required', true);
        } else {
            $field.hide();
            $input.prop('required', false);

            // Optionnel : retirer l'état invalide si présent
            $input.removeClass('is-invalid');
            $input.closest('.form-group').find('.invalid-feedback').remove();
        }
    }

    // Initial
    updateVisibility();

    // Au changement du switch
    $('input[name="' + switchName + '"]').on('change', updateVisibility);
}

/**
 * Affiche ou masque une section en fonction de la valeur d’un <select>.
 * @param {string} selectSelector - Sélecteur du <select>
 * @param {string} fieldSelector - Sélecteur du bloc/section à afficher
 * @param {array|string} showValues - Valeur(s) du select qui doivent afficher la section
 */
function initSelectToggleSection(selectSelector, fieldSelector, showValues) {
    var $select = $(selectSelector);
    var $section = $(fieldSelector).closest('.form-group');

    // Convertir en tableau si une seule valeur
    if (!Array.isArray(showValues)) {
        showValues = [showValues];
    }

    function updateVisibility() {
        var value = $select.val();

        if (showValues.includes(value)) {
            $section.show();
            // Marquer les champs internes comme requis, si besoin
            $section.find('input, select, textarea').prop('required', true);
        } else {
            $section.hide();
            $section.find('input, select, textarea').prop('required', false);

            // Optionnel : nettoyage de validation
            $section.find('.is-invalid').removeClass('is-invalid');
            $section.find('.invalid-feedback').remove();
        }
    }

    // Initial
    updateVisibility();

    // Sur changement du select
    $select.on('change', updateVisibility);
}

function initToggleLanguageSelection() {
    $(document).on('click', '.js-locale-item', function () {
        let selectedLang = $(this).data('locale');
        let group = $(this).closest('.js-locale-input-group');

        group.find('.js-locale-input').addClass('d-none');
        group.find('.js-locale-input.js-locale-' + selectedLang).removeClass('d-none');

        let button = group.find('.js-locale-btn');
        button.text(selectedLang.toUpperCase());
    });
}
